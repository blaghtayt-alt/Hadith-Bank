from review_helpers import decision, save_batch, source_rows, source

specs = [
('805','A','Quraibah','other'),
('867','S','Ayyub As-Sakhtiyani','successor'),
('870','O',None,'unresolved',{'note':'The recommendation is attributed to Ja’far’s father in this English field; his personal name is not supplied.'}),
('871','C','Ali','companion'),
('872','A','Zaid bin Uthai','other',{'end_before':'and this is more correct'}),
('884','C','Aishah','companion'),
('942','H',None,'unresolved',{'note':'The reported father is not personally named in this English field; no name is supplied from another language.'}),
('958','C','Ali','companion'),
('985','A','Abdullah','unresolved',{'note':'The source explicitly says this was not narrated in marfu form, despite the preceding parenthesis. Both source qualifications are retained.'}),
('1027','C','Ibn Abbas','companion'),
('1047','H',None,'unresolved',{'note':'Ja’far’s father gives this burial account; his personal name is not supplied in this field.'}),
('1048','C','Ibn Abbas','companion'),
('1055','C','Aishah','companion',{'note':'The reported poetic lines are retained as Aishah’s quoted speech within the historical account, not Prophetic speech.'}),
('1096','A','Anas','companion'),
('1104','A',"Sa'eed bin Abi Arubah",'other',{'end_before':', and this is more correct','note':'The source explicitly says this chain was not narrated in marfu form.'}),
('1122','C','Ibn Abbas','companion'),
('1137','C','Jabir bin Abdullah','companion'),
('1149','C','Ibn Abbas','companion',{'note':'The source’s pronoun “She said” is preserved, although the preceding attribution names Ibn Abbas; it has not been silently corrected.'}),
('1156','C','Ibn Abbas','companion'),
('1412','C',"'Ali",'companion'),
('1424.2','A',"Muhammad bin Rabi'ah",'other',{'note':'The source explicitly says this was not narrated in marfu form; the decimal provider identity remains unchanged.'}),
('1452','A',"An-Nu'man bin Bashir",'companion'),
('1466','C',"Jabir bin 'Abdullah",'companion'),
('1598','C',"Al-Bara'",'companion',{'end_before':'[He said:]'}),
('1743','C',[('Al-Hasan','companion'),('Al-Husain','companion')],'companion',{'end_before':'This Hadith is Hasan Sahih','note':'The report describes the two named Companions’ practice, not a saying assigned to the Prophet.'}),
('1778','C',"'Aishah",'companion',{'end_before':'This is more correct.'}),
('1782','C','Abu Kabshah Al-Anmari','companion',{'end_before':"[Abu 'Eisa said:]"}),
('1808','C',"'Ali",'companion'),
('1811','S',"Abu Al-'Aliyah",'successor',{'end_before':"Abu Khaldah's name"}),
('1873','C',"'Umar",'companion'),
('1874','C',"'Umar bin Al-Khattab",'companion',{'end_before':'[After mentioning this, he said:]'}),
('1880','C',"Ibn 'Umar",'companion',{'end_before':"[Abu 'Eisa said:]"}),
('2005','O',"'Abdullah bin Al-Mubarak",'other'),
('2069','C','Abu Hurairah','companion'),
('2070','C','Abu Hurairah','companion',{'end_before':'Qatadah said: "One takes','note':'Qatadah’s subsequent explanatory regimen is retained separately in Comments.'}),
('2198','S','Al-Hasan','successor',{'note':'Hisham transmits Al-Hasan’s explanation of a cited hadith; the interpretation remains attributed to Al-Hasan and is not relabelled as Prophetic speech.'}),
('2203','H',None,'unresolved',{'note':'The quoted first-person account is attributed to the narrator’s father; its kinship descriptions and unresolved personal attribution are retained exactly.'}),
('2239','C','Anas bin Malik','companion'),
('2296','A','Malik','other'),
('2365','C',"Sa'd Bin Abi Waqqas",'companion'),
('2367','C','Abu Hurarirah','companion',{'end_before':'(sahih)','note':'The source’s spelling variants for Abu Hurairah are preserved unchanged.'}),
('2447','C','Anas bin Malik','companion',{'end_before':'Other chains report similar narrations'}),
('2471','C','Aishah','companion'),
('2480','S',"Ibrahim An-Nakha'i",'successor'),
('2565','S','Yahya bin Abi Kathir','successor',{'end_before':'And the meaning of listening','note':'The Quran citation is retained within the transmitted exegetical answer; the following compiler explanation is separate.'}),
('2622','H',"Abdullah bin Shaqiq Al-'Uqayli",'other'),
('2743.3','A',"Shu'bah",'other',{'end_before':'(A chain to support that)'}),
('2743.4','A',"'Abdur-Rahman bin Mahdi",'other',{'end_before':'(A chain to support that)'}),
('2787.2','A',None,'unresolved'),
('2855.2','A',None,'unresolved'),
('2884','C',"'Abdullah bin Mas'ud",'companion',{'end_before':'Sufyan said:'}),
('2935','C',"Abu Sa'eed",'companion'),
('2963','C',"Ibn 'Umar",'companion',{'note':'The supplied wording is a short report fragment; its preceding context is not reconstructed.'}),
('2966','C','Anas bin Malik','companion',{'note':'The incomplete printed Quran-reference suffix is retained as supplied; no absent verse number is filled in.'}),
('2978','C','Jabir','companion',{'note':'The incomplete printed Quran-reference suffix is retained as supplied; no absent verse number is filled in.'}),
]
out=[]
for n,k,name,role,*options in specs:
    out.append(decision('tirmidhi',n,k,name,role,**(options[0] if options else {})))

t=source_rows('tirmidhi')['2680']['source_versions']['eng'][0]['row']['text']
a=t.index('(meaning that');b=t.index(')',a)+1
out.append(decision('tirmidhi','2680','C','Abu Hurairah','companion',spans=[[0,a],[b,len(t)]],note='The intervening parenthetical explanation is retained in Comments, with the two surviving passages grouped as one source report.'))

t=source_rows('tirmidhi')['2534']['source_versions']['eng'][0]['row']['text']
spans=[[0,t.index('And this is more correct')],[t.index('[Qutaibah'),t.index('The companions of')]]
d=decision('tirmidhi','2534','A',"'Abdullah bin Mas'ud",'companion',spans=spans,note='Two separately supplied transmission components remain distinct; the intervening and final compiler assessments are Comments. Both explicit non-marfu qualifications remain available in the exact source.')
d['source_report_count']=2;d['source_report_groups']=[[spans[0]],[spans[1]]]
d['report_component_classifications']=[]
for span,name,role in [(spans[0],"'Abdullah bin Mas'ud",'companion'),(spans[1],'Qutaibah','other')]:
    start=t.index(name,span[0],span[1])
    d['report_component_classifications'].append({'spans':[span],'report_type':'abbreviated_transmission','reported_speakers':[{'name_as_supplied':name,'role':role,'source_spans':[[start,start+len(name)]]}]})
source.apply_reviewed_span(t,d);out.append(d)
save_batch('tirmidhi-reviewed-batch02.json',out)
