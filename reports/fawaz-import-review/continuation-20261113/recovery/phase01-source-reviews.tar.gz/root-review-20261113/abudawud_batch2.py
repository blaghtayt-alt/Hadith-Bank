from review_helpers import decision,grouped,save_batch,source_rows
specs=[
('833','C','Jabir b. ‘Abd Allah','companion'),('834','S','Al-Hasan','successor'),('849','O','‘Amir','unresolved'),
('859','A','Rifa’ah b. Rafi','companion'),('867','H',None,'unresolved'),('937','C','Bilal','companion'),
('942','O','‘Isa b. Ayyub','other'),('949','C','Zaid b. Arqam','companion'),('958','C',"Abdullah bin 'Umar",'companion'),
('959','A',"'Abdullah bin 'Umar",'companion'),('960','A','Yahya','other'),('961','A','Al-Qasim bin Muhammad','successor'),
('967','A',None,'unresolved'),('981','A','‘Uqbah b. ‘Amr','companion'),('986','C',"Abdullah ibn Mas'ud",'companion'),
('993','C','Ibn ‘Umar','companion'),('994','C','Ibn ‘Umar','companion'),('1003','C','Ibn Abbas','companion'),
('1012','A','Abu Hurairah','companion'),('1016','A','Abu Hurairah','companion'),
('1021','A','‘Abd Allah (b. Mas’ud)','companion',{'end_before':'Abu Dawud said:'}),
('1031','A','Muhammad b. Muslim','other'),('1032','A','Muhammad b. Muslim al-Zuhr','other'),
('1055','C','‘A’ishah','companion'),('1058','A','Abu al-Malih','other',{'note':'This source supplies only a temporal clarification of an otherwise unstated incident; its absent context is not reconstructed.'}),
('1066','C','Ibn ‘Abbas','companion'),('1069','C',"Ka'b ibn Malik",'companion'),
('1071','C','Ibn Abbas','companion'),('1072','H','‘Ata’','successor'),('1075','A',None,'unresolved'),
('1086','C',"Sahl b. Sa'd",'companion'),('1087','C',"Al-Sa'ib b. Yazid",'companion'),
('1103','A',None,'unresolved',{'note':'The two sisters are both supplied as Umrah in this field; their names are retained without silent correction or identity inference.'}),
('1133','C','Ibn Umar','companion',{'end_before':'AbuDawud said:'}),('1135','C','Abdullah ibn Busr','companion'),
('1138','A',"Umm 'Atiyyah",'companion'),('1150','A','Ibn Shihab','other'),
('1163','A','Muhammad b. Muslim','other'),('1186','A','Qabisah al Hilali','companion'),
('1198','C','Aisha','companion'),('1200','A',"'Abd Allah b. Abi 'Ammar",'other',{'end_before':'Abu Dawud said:'}),
('1213','A',None,'unresolved'),('1216','H',"Hisham b. Sa'd",'other'),
('1228','C','Aisha','companion',{'end_before':"Muhammad ibn Shu'ayb said:"}),
('1284','C',"Ibn 'Umar",'companion',{'end_before':'Abu Dawud said:'}),
('1304','C','Abdullah Ibn Abbas','companion',{'note':'This is Ibn Abbas’s transmitted exegesis, including quoted Quran wording and explanations; it is not relabelled as Prophetic speech.'}),
('1305','C',"Ibn 'Abbas",'companion'),('1322','C','Anas','companion'),
('1324','A','Abu Hurairah','companion',{'end_before':'Abu Dawud said:','note':'The following compiler discussion explicitly records mauquf versions; it remains in Comments and is not overridden by a Prophetic label.'}),
('1344','A',"Yahya b. Sa'id",'other'),('1345','A',"Sa'id",'unresolved'),
('1349','A',"'Aishah",'companion',{'end_before':'But the tradition narrated'}),
('1354','A','Husain','unresolved',{'end_before':'Abu Dawud said:'}),
('1428','C',"Ubayy b. Ka'b",'companion'),('1429','C',"Ubayy ibn Ka'b",'companion',{'end_before':'Abu Dawud said:'}),
('1472','O',[("Waki'",'other'),("Ibn 'Uyainah",'other')],'other'),('1476','S','Al-Zuhri','successor'),
('1489','C','Ibn Abbas','companion'),('1490','A',"Ibn 'Abbas",'companion'),
('1507','A',"'Abd Allah b. al-Zubair",'companion'),
('1511','A',"'Amr b. Murrah",'other',{'end_before':'Abu Dawud said:'}),('1553','A','Abu al-Yusr','companion'),
('1557','A','Abu Bakr','companion'),('1560','O','Ibrahim','unresolved'),
('1569','A','Sufyan bin Husain','other'),
('1571','O','Malik','other',{'note':'This numbered entry explicitly transmits Malik’s explanation of Umar’s statement. The legal explanation remains attributed to Malik, not the Prophet.'}),
('1592','O','Muhammad bin Ishaq','other',{'note':'This numbered source entry explicitly attributes the explanation to Muhammad bin Ishaq. The source’s affirmative “should do so” is preserved as printed and not silently corrected.'}),
('1602','A','‘Amr bin Shu’aib','other'),('1604','A','Ibn Shihab','other'),
('1615','C',"Abd’ Allah(b. 'Umar)",'companion'),
('1616','C','Abu sa’id al-khudri','companion',{'end_before':'Abu Dawud said :','note':'The source’s wheat wording is preserved; the compiler’s objection to that version remains in Comments.'}),
('1617','A','Abu Sa’id','companion',{'end_before':'But this is a misunderstanding','note':'The compiler explicitly disputes the half-sa wording; that caution is retained in Comments, not silently removed.'}),
('1618','C',"Abu Sa'id al-Khudri",'companion',{'end_before':'The narrator Hamid','note':'Sufyan’s flour variant remains as supplied. The narrator’s withdrawal account and compiler criticism are retained in Comments.'}),
('1625','C','Imran ibn Husayn','companion'),('1654','A','Ibn Abbas','companion'),
('1657','C',"Abdullah ibn Mas'ud",'companion'),('1674','A','Ibn Ishaq','other'),
('1688','C','Abu Hurairah','companion',{'end_before':'Abu Dawud said'}),
('1702','A','Shu’bah','other',{'note':'The source’s explicit uncertainty between one and three years is retained.'}),
('1703','A','Salamah. Bin Kuhail','other',{'end_before':'Abu Dawud said :'}),
('1705','A','Malik','other',{'end_before':'Abu Dawud said :'}),('1711','A','‘Amr bin Shu’aib','other'),
('1715','C','Ali ibn Abu Talib','companion'),('1730','C','Ibn `Abbas','companion'),
('1731','C','Ibn Abbas','companion'),('1734','C','Ibn Abbas','companion'),('1735','A','Abd Allah bin `Abbas','companion'),
('1807','C','Abu Dharr','companion'),('1845','S','Sa’id bin Al Musayyib','successor'),
('1855','O','Ka’ab','unresolved'),('1861','A',"Ka'b bin Ujrah",'companion'),
('1875','C','Ibn Umar','companion',{'note':'Ibn Umar’s own explicit inference and uncertainty remain part of his reported statement; they are not a separate bank-verified Prophetic attribution.'}),
('1887','C','Umar ibn al-Khattab','companion'),('1896','C','Aisha','companion'),
('1908','A','Hafs bin Ghiyath','other'),('1909','A','Jabir','companion'),('1918','A','Al ‘Adda bin Khalid','unresolved'),
('1927','A','Al Zuhri','successor'),('1928','A','Al Zuhri','successor'),
('1930','H','Sa’id bin Jubair','successor'),('1943','C',"Asma'",'companion'),('1946','C','Abu Hurairah','companion'),
('1961','H','Uthman','companion'),('1962','H','Uthman','companion'),('1963','H','Uthman','companion'),
]
out=[]
for n,k,name,role,*opts in specs:out.append(decision('abudawud',n,k,name,role,**(opts[0] if opts else {})))
rows=source_rows('abudawud')
def txt(n):return rows[n]['source_versions']['eng'][0]['row']['text']
def c(a,b,k,name,role):return {'spans':[[a,b]],'kind':k,'name':name,'role':role}
t=txt('1035');b=t.index('Abu Dawud said:');e=t.index('This is the opinion')
out.append(grouped('abudawud','1035',[c(0,b,'A','al-Zuhri','successor'),c(b,e,'C','Ibn-Zubair','companion')],note='The abbreviated transmission and separately attributed Ibn-Zubair practice remain two source components. The concluding compiler statement about al-Zuhri’s opinion remains Comments.'))
t=txt('1111');a=t.index(', i.e.');b=t.index(', while the imam');e=t.index('Abu Dawud said:')
out.append(decision('abudawud','1111','H',"Ya'la b. Shaddad b. Aws",'other',spans=[[0,a],[b,e]],note='The inserted definition of ihtiba and following compiler discussion are preserved in Comments; the witness’s two exact passages remain one historical report.'))
t=txt('1321');b=t.index('Al-Hasan used to say:')
out.append(grouped('abudawud','1321',[c(0,b,'C','Anas b. Malik','companion'),c(b,len(t),'S','Al-Hasan','successor')],note='The separately attributed exegetical statements of Anas and Al-Hasan remain two distinct source components, not Prophetic speech. The embedded Quran citation remains as supplied.'))
t=txt('1566');b=t.index('Sufyan, a narrator, was asked')
out.append(grouped('abudawud','1566',[c(0,b,'A','‘Umar bin Ya’la','other'),c(b,len(t),'O','Sufyan','other')],note='The abbreviated transmission and separately reported question to Sufyan retain distinct attribution and exact source spans. The legal response is not assigned to the Prophet.'))
t=txt('1598');b=t.index('Ibn Al Aswad said')
out.append(grouped('abudawud','1598',[c(0,b,'O','Waki’','other'),c(b,len(t),'O','Abu Iyas al Asadi','other')],note='The source separately attributes one lexical answer to Waki and another reported answer to Abu Iyas. Both remain named scholarly statements, not Prophetic wording.'))
save_batch('abudawud-reviewed-batch02.json',out)
