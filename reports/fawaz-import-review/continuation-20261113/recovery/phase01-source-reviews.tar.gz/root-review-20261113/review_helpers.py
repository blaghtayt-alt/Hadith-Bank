import gzip
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts'))
import import_fawaz_bulk as source

TYPES = {'A': 'abbreviated_transmission', 'C': 'companion_report',
         'S': 'successor_report', 'H': 'historical_report',
         'O': 'attributed_saying', 'P': 'prophetic_report'}

def source_rows(book):
    path = ROOT / '.work/recovery-20261113/residual-source-rows' / (book + '.jsonl.gz')
    with gzip.open(path, 'rt', encoding='utf-8') as handle:
        return {r['typed_hadithnumber']: r for r in map(json.loads, handle)}

def decision(book, number, kind, name=None, role='unresolved', *, prefix='eng',
             end_before=None, spans=None, note=None, hold_reason=None):
    row = source_rows(book)[str(number)]
    items = row['source_versions'][prefix]
    assert len(items) == 1
    item = items[0]
    text = item['row']['text']
    assert text.strip(), (book, number, prefix, 'empty')
    d = {'provider_book': book, 'provider_edition': prefix + '-' + book,
         'typed_hadithnumber': str(number),
         'source_text_sha256': source.sha(text.encode()),
         'source_raw_sha256': item['source_sha256'], 'source_path': item['source_path'],
         'source_position': item['position'], 'json_pointer': '/hadiths/' + str(item['position']) + '/text',
         'source_language': prefix, 'provider_url': source.provider_url('editions/' + prefix + '-' + book + '.json'),
         'reference_as_supplied': item['row']['reference'],
         'actual_reviewed_languages': [prefix],
         'review_scope': 'complete_own_language_source_field_report_attribution_and_boundaries',
         'reviewer': 'assistant root source rereview after checkpoint recovery',
         'reviewed_on_japan': '2026-11-13', 'canonical_identity_inferred': False,
         'translation_equivalence_verified': False, 'independent_authenticity_assessment': False}
    if hold_reason:
        d.update(action='source_attribution_pending', reason=hold_reason,
                 decision_note=hold_reason)
        source.apply_reviewed_span(text, d)
        return d
    if spans is None:
        end = text.index(end_before) if end_before is not None else len(text)
        spans = [[0, end]]
    notes = []
    cursor = 0
    for a, b in spans:
        if a > cursor: notes.append([cursor, a])
        cursor = b
    if cursor < len(text): notes.append([cursor, len(text)])
    speakers = []
    if name is None:
        speakers = [{'name_as_supplied': None, 'role': 'unresolved', 'source_spans': []}]
    else:
        for n, r in (name if isinstance(name, list) else [(name, role)]):
            start = text.index(n)
            assert any(a <= start < start + len(n) <= b for a, b in spans)
            speakers.append({'name_as_supplied': n, 'role': r, 'source_spans': [[start, start + len(n)]]})
    label = {
        'A': 'This numbered source entry supplies an abbreviated transmission or variant. Its wording and stated attribution are retained without reconstructing the omitted report or inferring a cross-edition number.',
        'C': 'This numbered source entry reports a Companion statement, action, or account under the attribution actually supplied. It is not relabelled as direct Prophetic speech.',
        'S': 'This numbered source entry preserves a Successor report under its supplied attribution, not direct Prophetic speech.',
        'H': 'This numbered source entry preserves a transmitted historical or narrator account. Its own speaker and source wording are retained; no direct Prophetic speech is inferred.',
        'O': 'This numbered source entry preserves an attributed saying or transmitted exchange under its supplied speaker. No Prophetic attribution is added.',
        'P': 'The selected source wording explicitly supplies a Prophetic report. Its wording and boundaries are retained as supplied without filling omissions.'}[kind]
    if note: label += ' ' + note
    d.update(quotation_spans=spans, notes_spans=notes,
             quotation_sha256=source.sha(''.join(text[a:b] for a,b in spans).encode()),
             quotation_kind='source_numbered_attributed_report', classification='source_numbered_attributed_report',
             report_type=TYPES[kind], reported_speakers=speakers,
             report_classification_note=label, decision_note=label)
    if len(spans) > 1:
        d.update(source_report_count=1, source_report_groups=[spans],
                 report_component_classifications=[{'spans': spans, 'report_type': TYPES[kind],
                                                    'reported_speakers': speakers}])
    source.apply_reviewed_span(text, d)
    return d

def grouped(book, number, components, *, prefix='eng', note):
    text=source_rows(book)[str(number)]['source_versions'][prefix][0]['row']['text']
    all_spans=[span for component in components for span in component['spans']]
    first=components[0]
    d=decision(book,number,first['kind'],first.get('name'),first.get('role','unresolved'),
               prefix=prefix,spans=all_spans,note=note)
    groups=[]; classifications=[]; all_speakers=[]
    for c in components:
        spans=c['spans'];name=c.get('name');role=c.get('role','unresolved')
        if name is None:
            speakers=[{'name_as_supplied':None,'role':'unresolved','source_spans':[]}]
        else:
            matches=[(a,text.find(name,a,b)) for a,b in spans if text.find(name,a,b)>=0]
            assert matches,(book,number,name,spans)
            start=matches[0][1]
            speakers=[{'name_as_supplied':name,'role':role,'source_spans':[[start,start+len(name)]]}]
        groups.append(spans);all_speakers.extend(speakers)
        classifications.append({'spans':spans,'report_type':TYPES[c['kind']],'reported_speakers':speakers})
    kinds={c['kind'] for c in components}
    d.update(source_report_count=len(groups),source_report_groups=groups,
             report_type=TYPES[first['kind']] if len(kinds)==1 else 'mixed_attributed_reports',
             reported_speakers=all_speakers,report_component_classifications=classifications,
             report_classification_note=note,decision_note=note)
    source.apply_reviewed_span(text,d)
    return d

def save_batch(filename, decisions):
    output = ROOT / '.work/root-review-20261113' / filename
    result = {'schema': 'hadith-bank-fawaz-reviewed-spans-v1', 'repository': source.REPOSITORY,
              'revision': source.REVISION, 'decisions': decisions,
              'review_scope': 'Fresh complete own-language source readings; sibling fields remain independently qualified.'}
    raw = (json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode()
    output.write_bytes(raw)
    print(json.dumps({'path': str(output), 'decisions': len(decisions),
                      'positive_ids': len({(d['provider_book'],d['typed_hadithnumber']) for d in decisions if not d.get('action')}),
                      'sha256': hashlib.sha256(raw).hexdigest()}))
