from review_helpers import decision,grouped,save_batch,source_rows

# Full English source fields were read in source order, followed by all eight
# ambiguous scholarly explanations in the original Arabic.
specs=[
('5','A','Anas','companion'),('11','C','Ibn Umar','companion'),
('37','A',"'Abd Allaah b. 'Amr",'companion',{'end_before':'Abu Dawud said:'}),
('72','A','Abu Hurairah','companion',{'note':'The source explicitly attributes this version to Abu Hurairah himself, not to the Prophet.'}),
('80','C',"'Abd Allaah b. 'Umar",'companion'),('85','C',"'Abd Allaah b Mas'ud",'companion'),
('86','S',"'Ata",'successor'),('87','S',"Abu'l-'Aliyah",'successor'),
('112','C','‘All','companion',{'note':'The source prints the name as “All”; that spelling is retained rather than silently corrected.'}),
('113','C','‘Ali','companion'),('119','A','‘Abd Allah b. Zaid b. ‘Asim','companion'),
('123','A',None,'unresolved'),('125','A',None,'unresolved'),('127','A','Ibn ‘Uqail','other'),
('183','A','Qais b. Talq','other'),
('253','C','Aishah','companion'),('254','C','Aishah','companion'),('262','C','‘A’ishah','companion'),
('263','A','‘A’ishah','companion',{'note':'The source says “were commanded” for both fast and prayer; its apparent wording discrepancy is retained without correction.'}),
('265','C','Ibn ‘Abbas','companion'),('271','C','Aisha','companion'),
('275','A','Umm Salamah','companion'),('276','A',None,'unresolved'),('277','A',None,'unresolved'),
('289','A',"'Aishah",'companion'),
('290','A',"'Aishah",'companion',{'end_before':'Abu Dawud said:','note':'The compiler’s following multiple-chain comparison and the explicit warning that the Prophet did not command this bath are retained in Comments; no such command is inferred.'}),
('299','C','Aishah','companion'),('302','C','Ali ibn AbuTalib','companion'),
('303','S','al-Qasim b. Muhammad','successor'),
('309','H','Umm Habibah','companion',{'end_before':'Abu Dawud said:'}),
('310','C','Hamnah daughter of Jahsh','companion'),('311','C','Umm Salamah','companion'),
('319','A',None,'unresolved'),
('335','A',"'Amr b. al-'As",'companion',{'end_before':'Abu Dawud said:','note':'The compiler’s additional chain and tayammum variant remain available in Comments; the selected source variant explicitly omits tayammum.'}),
('339','A','Ata b. Yasar','successor'),
('349','O','Makhul','other',{'note':'The original Arabic separately transmits the question and Makhul’s lexical answer through its own isnad. It is retained as that scholar’s saying, not as the Prophet’s wording.'}),
('350','O',"Sa'id (b. 'Abd al-'Aziz)",'other',{'note':'The original Arabic separately transmits this named scholarly explanation through its own isnad; it is not labelled as Prophetic speech.'}),
('352','C','Aishah','companion'),('357','C',"'Aishah",'companion'),('358','C','Aishah','companion'),
('359','C','Umm Salamah','companion'),('364','C','Aishah','companion'),
('377','C','Ali ibn AbuTalib','companion'),('379','C','Umm Salamah','companion'),
('382','C',"Ibn 'Umar",'companion'),('403','H','Bilal','companion'),
('405','S','Al-Zuhri','successor',{'note':'This geographical observation is independently transmitted through an explicit Arabic isnad in its own numbered entry. It remains Al-Zuhri’s observation with the narrator’s uncertainty, not Prophetic speech.'}),
('406','O','Khaythamah','other',{'note':'The Arabic independently transmits this named lexical explanation through its own isnad; the wording is retained as that attributed saying.'}),
('415','O',"Al-Awza'i",'other',{'note':'The Arabic independently transmits this named explanation through its own isnad. It is a scholarly saying, not a Prophetic quotation.'}),
('446','A','Dhu Mikhbar','companion'),('459','O',None,'unresolved'),
('463','A',"'Umar b. al-Khattab",'companion',{'end_before':'and that is more correct'}),
('464','C','‘Umar b. al-Khattab','companion'),('483','A',None,'unresolved'),('491','A','Abu Salih','other'),
('496','A','Dawud b. Sawar al-Muzani','other',{'end_before':'Abu Dawud said:'}),
('508','C','Anas','companion'),('509','A','Anas','companion'),
('510','C','Abdullah ibn Umar','companion',{'end_before':"Shu'bah said:"}),
('511','A','Ibn ‘Umar','companion'),('513','A',None,'unresolved'),
('519','H',None,'unresolved',{'note':'The reporting woman is identified by her tribe only; her personal name is not supplied.'}),
('533','A','‘Umar','companion',{'end_before':'Abu Dawud said:','note':'The compiler’s separately preserved chain gives Mas’ud rather than Masruh; both supplied name variants remain in the source, without silent harmonization.'}),
('536','C','Abu Hurairah','companion'),('538','C','Ibn Umar','companion'),
('540','A',None,'unresolved',{'end_before':'Abu dawud said:'}),('546','A','‘Ali b. Abi Talib','companion'),
('550','C','Abd Allah b. Mas’ud','companion'),('586','A','‘Amr b. Salamah','companion'),
('588','C','Ibn ‘Umar','companion'),('597','C','Hudhaifah','companion'),('611','A','Ibn ‘Abbas','companion'),
('639','C','Umm Salamah','companion'),
('644','H','Ibn Juraij','other',{'end_before':'Abu Dawud said:'}),('673','C','Anas ibn Malik','companion'),
('686','O','Ata','other',{'note':'The original Arabic supplies a separate isnad for this named measurement statement. It is retained as an attributed saying, not a Prophetic instruction.'}),
('691','H',"Sufyan b. 'Uyainah",'other',{'end_before':', that is, for saying'}),
('710','C','Aisha','companion',{'end_before':'Abu Dawud said:','note':'Shu’bah’s explicit uncertainty about menstruation remains in the selected report. The compiler’s comparison with versions omitting it remains in Comments.'}),
('717','A',None,'unresolved'),('732','A','Muhammad b. ‘Amr b. ‘Ata’','other'),
('733','A',None,'unresolved',{'note':'The first transmitter is supplied with an explicit alternative name, Abbas or Ayyash; no alternative is silently chosen.'}),
('742','C','‘Abd Allah b. ‘Umar','companion',{'end_before':'Abu Dawud said:'}),
('751','A','Sufyan','other',{'end_before':'Abu Dawud said:','note':'Sufyan’s explicit account that the additional wording was received later remains in the report; the following compiler comparison remains Comments.'}),
('754','C','Ibn al-Zubair','companion'),('756','C','Ali ibn AbuTalib','companion'),
('757','C','Ali','companion',{'end_before':'Abu Dawud said:','note':'The compiler’s above/below-navel variants and grading remain in Comments; they are not harmonized with the selected report.'}),
('758','C','AbuHurayrah','companion',{'end_before':'Abu Dawud said:'}),
('762','O',[('Ibn al-Munkadir','other'),('Ibn Abi Farwah','other')],'other'),
('768','A','‘Ikramah','other'),
('769','O','Malik','other',{'note':'Abu Dawud’s original Arabic separately transmits this named opinion via al-Qa’nabi from Malik in its own numbered entry. It remains Malik’s attributed saying, not Prophetic speech.'}),
('777','C','Samurah ibn Jundub','companion',{'end_before':'Abu Dawud said:'}),
('799','A','Abu Qatadah','companion'),('800','C','Abu Qatadah','companion'),
('813','H',None,'unresolved',{'end_before':'Abu Dawud said:','note':'The source’s supplied parenthetical name “Umrah” is retained; no correction or cross-language identity is silently substituted.'}),
('815','C','Ibn mas’ud','companion'),('818','C','Abu sa’id','companion'),
('825','A',"'Ubadah b. al-samit",'companion',{'end_before':'This version adds:','note':'The following statement about Makhul’s recitation practice and explanatory instruction remains separately available in Comments.'}),
]
out=[]
for n,k,name,role,*options in specs:
    out.append(decision('abudawud',n,k,name,role,**(options[0] if options else {})))
rows=source_rows('abudawud')
def txt(n):return rows[n]['source_versions']['eng'][0]['row']['text']
def comp(a,b,k,name=None,role='unresolved'):return {'spans':[[a,b]],'kind':k,'name':name,'role':role}
t=txt('204');b=t.index('Abu Dawud said:')
out.append(grouped('abudawud','204',[comp(0,b,'C',"Abdullah ibn Mas'ud",'companion'),comp(b,len(t),'A',"'Abd Allah (b. Mas'ud)",'companion')],note='The Companion statement and the compiler’s explicit additional transmission routes remain two source components. No omitted matn or Prophet attribution is supplied.'))
t=txt('301');b=t.index('Abu Dawud said:');c=t.index('This tradition has also');d=t.index('This is the view');e=t.index('It has also been reported by Miswar')
out.append(grouped('abudawud','301',[comp(0,b,'S',"Sa'id b. al-Musayyab",'successor'),comp(b,c,'A',"Ibn 'Umar",'companion'),comp(c,d,'A',"'Aishah",'companion'),comp(e,len(t),'A','Miswar','other')],note='Four separately supplied attributed/transmission components retain their own spans. The compiler’s comparison and Malik’s proposed correction remain Comments; the source’s explicit zuhr/tuhur wording uncertainty is not silently repaired.'))
save_batch('abudawud-reviewed-batch01.json',out)
