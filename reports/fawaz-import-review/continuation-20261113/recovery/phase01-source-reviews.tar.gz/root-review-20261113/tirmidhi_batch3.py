from review_helpers import decision, grouped, save_batch, source_rows

specs=[
('2981','C',"Ma'qil bin Yasar",'companion',{'end_before':"[Abu 'Eisa said:]"}),
('2987','C','Al-Bara','companion'),
('2990','C',"'Ali",'companion',{'end_before':'(Its meaning is recorded','note':'The anonymous intervening transmitter and source wording remain unchanged; the appended cross-reference and chain assessment are Comments.'}),
('3007','C','Abu Talhah','companion'),
('3008','C','Abu Talhah','companion'),
('3009','C',"Ibn 'Abbas",'companion'),
('3016','C',"Abu Sa'eed Al-Khudri",'companion'),
('3022','C','Umm Salamah','companion',{'end_before':'Mujahid said:','note':'The following narrator explanation and biographical comment remain separately preserved.'}),
('3026','C',"'Ali bin Abi Talib",'companion'),
('3037','C',"'Ali bin Abi Talib",'companion'),
('3041','C','Al-Bara','companion'),
('3043','C',"'Umar bin Al-Khattab",'companion'),
('3044','C','Ibn Abbas','companion'),
('3050','C','Al-Bara','companion'),
('3063','C',"'Abdullah bin 'Amr",'companion'),
('3080','C',"Ibn 'Abbas",'companion'),
('3089','C',"'Ali",'companion'),
('3140','C',"Ibn 'Abbas",'companion'),
('3162','C','Khabbab bin Al-Aratt','companion'),
('3189','C',"Sa'd",'companion'),
('3192','C',"Abu Sa'eed",'companion'),
('3194','C','Niyar bin Mukram Al-Aslami','companion'),
('3196','C','Anas bin Malik','companion'),
('3209','C',"Ibn 'Umar",'companion'),
('3210','S',"Ash-Sha'bi",'successor'),
('3213','C','Zainab bint Jahsh','companion'),
('3248','C',"Ibn Mas'ud",'companion'),
('3268','H','Abu Jubairah bin Ad-Dahhak','other'),
('3269','C',"Abu Sa'eed Al-Khudri",'companion'),
('3281','C',"Ibn 'Abbas",'companion'),
('3289','C',"Jubair bin Mut'im",'companion'),
('3303','C','Ibn Abbas','companion'),
('3304','C','Abu Hurairah','companion'),
('3317','C','Ibn Abbas','companion'),
('3347','C','Abu Hurairah','companion',{'note':'The source’s unusual surah wording “At-Tim and Az-Zamzam” is retained without correction; it is a source-text uncertainty, not a bank-supplied Quran title.'}),
('3355','C','Ali','companion'),
('3415','H','Maslamah bin `Amr','other'),
('3472','S','Az-Zuhri','successor'),
('3488','S','Al-Hasan','successor'),
('3582','S','Safwan bin Sulaim','successor'),
('3617','C',"'Abdullah bin Salam",'companion',{'end_before':'(One of the narrators)','note':'The following narrator’s burial-space observation is preserved in Comments; the source’s claim is not an independent verification by the bank.'}),
('3656','C',"'Umar bin Al-Khattab",'companion'),
('3667','C','Abu Bakr','companion'),
('3685','S','Muhammad bin Sirin','successor'),
('3707','C',"Ibn 'Umar",'companion'),
('3717','C','ابو سعید خدری','companion',{'prefix':'urd','end_before':'امام ترمذی کہتے ہیں'}),
('3734','C',"Ibn 'Abbas",'companion'),
('3746','C','Az-Zubair','companion'),
('3750','H',"'Abdur-Rahman bin 'Awf",'companion'),
('3764','C','Abu Hurairah','companion'),
('3767','C','Abu Hurairah','companion'),
('3780','H',"'Umarah bin 'Umair",'other'),
('3794','C','Anas bin Malik','companion'),
('3806','C','Abu Musa','companion'),
('3814','C',"Ibn 'Umar",'companion'),
('3836','C',"Ibn 'Umar",'companion'),
('3840','C','Abu Hurairah','companion'),
('3883','C','Abu Musa','companion'),
('3884','S','Musa bin Talhah','successor'),
('3888','C',"'Ammar bin Yasir",'companion'),
('3889','C',"'Ammar bin Yasir",'companion',{'end_before':'- meaning:'}),
('3938','C','Anas','companion'),
]
out=[]
for n,k,name,role,*options in specs:
    options=options[0] if options else {}
    options['note']=(options.get('note','')+' Quran citations, source spelling, attribution and any incomplete source-reference suffix are preserved as supplied.').strip()
    out.append(decision('tirmidhi',n,k,name,role,**options))

rows=source_rows('tirmidhi')
def txt(n,p='eng'):return rows[str(n)]['source_versions'][p][0]['row']['text']
def comp(a,b,k,name=None,role='unresolved'):return {'spans':[[a,b]],'kind':k,'name':name,'role':role}

t=txt('2986');b=t.index('(Another chain)')
out.append(grouped('tirmidhi','2986',[comp(0,b,'C','Zaid bin Arqam','companion'),comp(b,len(t),'A')],note='The Companion’s reported prayer practice and a separately supplied abbreviated chain variant are two source components. The variant’s unnamed transmitter remains unresolved; no missing matn is reconstructed.'))
t=txt('3011');b=t.index("AbU 'Ubaidah");e=t.index("(Da'if)")
out.append(grouped('tirmidhi','3011',[comp(0,b,'C',"'Abdullah",'companion'),comp(b,e,'A',"Ibn Mas'ud",'companion')],note='The initial Companion account and separately named additional transmission retain two source components. The source does not identify the person answering the initial question; no Prophetic speaker is added. The final printed grading is Comments.'))
t=txt('3049');b=t.index('Abü Maisarah narrated')
out.append(grouped('tirmidhi','3049',[comp(0,b,'C',"'Umar bin Al-Khattab",'companion'),comp(b,len(t),'A',"'Umar bin Al-Khattab",'companion')],note='The full reported account and a separately supplied abbreviated transmission of Umar’s invocation remain distinct source components; Quran quotations within the account remain as printed.'))
t=txt('3092');end=t.index("[Abu 'Eisa said:]");a=t.index('(Another chain)');b=t.index('(Another chain)',a+1);e=t.index("[Abu 'Eisa said:]",b)
out.append(grouped('tirmidhi','3092',[comp(0,end,'C',"'Ali",'companion'),comp(a,b,'A',"'Ali",'companion'),comp(b,e,'A',"'Ali",'companion')],note='Ali’s report and two separately supplied chain variants retain three exact source components. Compiler assessments, narrator-name corrections and cross-references remain Comments; the two variant name spellings are not silently standardized.'))
t=txt('3735');b=t.index("'Amr bin Murrah said:")
out.append(grouped('tirmidhi','3735',[comp(0,b,'C','Zaid bin Al-Arqam','companion'),comp(b,len(t),'S',"Ibrahim An-Nakha'i",'successor')],note='The Companion statement and the separately transmitted Successor response remain two differently attributed source reports. Their explicit disagreement is preserved without choosing or inventing a bank verdict.'))
t=txt('3807');a=t.index('(guarded by');b=t.index(')',a)+1;c=t.index('(a nickname');e=t.index(')',c)+1
out.append(decision('tirmidhi','3807','C','Hudhaifah','companion',spans=[[0,a],[b,c],[e,len(t)]],note='The two inserted explanatory parentheticals are retained as Comments; the three selected passages belong to one report.'))
t=txt('3837');a=t.index('- meaning:');b=t.index(' -',a+1)+2
out.append(decision('tirmidhi','3837','C',"Talhah bin 'Ubaidullah",'companion',spans=[[0,a],[b,len(t)]],note='The inserted identification gloss is retained as Comments while the transmitted question and answer remain one report.'))

# All four actual source fields of the numbered chain-only entry were read.
t=txt('162','ara');b=t.index('وَوَجَدْتُ')
out.append(grouped('tirmidhi','162',[comp(0,b,'A','أُمِّ سَلَمَةَ','companion'),comp(b,len(t),'A','عَلِيُّ بْنُ حُجْرٍ','other')],prefix='ara',note='The source explicitly records a similar transmission through Umm Salamah and then a separately found chain in the compiler’s book. These are numbered abbreviated transmission components; no absent matn is supplied.'))
out.append(decision('tirmidhi','162','A','Ali bin Hujr','other',note='This English field contains only the book’s transmission-chain annotation. No complete matn is supplied or inferred from another language.'))
t=txt('162','urd');b=t.index('اور مجھے')
out.append(grouped('tirmidhi','162',[comp(0,b,'A','أم سلمة','companion'),comp(b,len(t),'A','علی بن حجر','other')],prefix='urd',note='The Urdu source records one similar transmission and a separately found chain. The two exact components retain their own supplied transmitter names; no omitted matn is reconstructed.'))
out.append(decision('tirmidhi','162','A','আলী ইবনু হুজর','other',prefix='ben',note='This field contains a numbered transmission-chain annotation only; no full matn or cross-language equivalent is manufactured.'))
save_batch('tirmidhi-reviewed-batch03.json',out)
