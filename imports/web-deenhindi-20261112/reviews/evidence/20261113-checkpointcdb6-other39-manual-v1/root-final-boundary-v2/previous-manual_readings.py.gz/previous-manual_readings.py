"""Complete own-field readings, including source-bound independent boundary refinements."""

READINGS = {'abudawud:763': {'hi': {'type': 'mixed_attributed_reports',
                         'speaker': 'Anas ibn Malik reports the Prophet’s prayer dialogue; a separate instruction is supplied as '
                                    'Humayd’s additional variant.',
                         'segments': [{'id': 'report-1',
                                       'start': None,
                                       'end': 'हुमैद ने अपनी रिवायत',
                                       'type': 'prophetic_report',
                                       'speaker': 'Anas ibn Malik recounting the prayer scene and the Prophet’s response.'},
                                      {'id': 'report-2',
                                       'start': 'जब तुम में से कोई आए',
                                       'end': None,
                                       'type': 'attributed_narration_fragment',
                                       'speaker': 'The actual additional instruction in Humayd’s variant; this addition does not '
                                                  'independently name its ultimate speaker.'}],
                         'context': ['(इतमिनान-ओ-सुकून से)'],
                         'note': 'Read the complete Hindi field. The man’s breathless arrival, actual praise formula, the '
                                 'Prophet’s question and reassurance, the man’s answer, and the twelve angels form the first '
                                 'narrated scene. Humayd’s final addition supplies a real instruction about ordinary walking and '
                                 'completing missed prayer units; retain it separately without borrowing an unstated ultimate '
                                 'speaker. Its transmission bridge is context. Retain the parenthetic said-it predicate as '
                                 'actual completion of the man’s answer; the separate calm-walking explanation is redundant with '
                                 'the ordinary-pace instruction and stays context. All actual formula words and actions remain '
                                 'unchanged.'},
                  'ur': {'type': 'mixed_attributed_reports',
                         'speaker': 'Anas ibn Malik’s Prophetic dialogue and the separately supplied Humayd variant instruction.',
                         'segments': [{'id': 'report-1',
                                       'start': None,
                                       'end': 'حمید نے اپنی روایت',
                                       'type': 'prophetic_report',
                                       'speaker': 'Anas ibn Malik reporting the prayer scene and the Prophet’s words.'},
                                      {'id': 'report-2',
                                       'start': 'جب تم میں سے کوئی آئے',
                                       'end': None,
                                       'type': 'attributed_narration_fragment',
                                       'speaker': 'The additional finite instruction quoted in Humayd’s transmission; its '
                                                  'ultimate speaker is not separately named here.'}],
                         'context': ['( اطمینان و سکون سے )'],
                         'note': 'Read the entire Urdu field independently. Preserve both the Arabic praise formula and its '
                                 'supplied Urdu meaning as part of the narrated supplication, together with the breathless man’s '
                                 'dialogue and the twelve-angels response. Select Humayd’s actual arrival/prayer-completion '
                                 'instruction as a separate component, leaving its variant-introduction bridge as context. '
                                 'Retain the parenthetic said-it predicate as actual answer content. Move only the separate '
                                 'calm-walking gloss to context; do not remove the supplied formula translation or merge '
                                 'speakers.'}},
 'abudawud:804': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Abu Saeed Khudri reporting the group’s estimate of the Prophet’s standing in Zuhr and Asr.',
                         'note': 'Read the complete source-labelled Hindi field, which is actually printed in Latin-script '
                                 'wording. It gives a coherent estimate of the Prophet’s standing: thirty verses/the named surah '
                                 'in the first Zuhr pair, half that later, and corresponding shorter Asr pairs. The named surah '
                                 'is the report’s own duration comparison, not an external verse locator. Retain the whole field '
                                 'exactly in its printed script and do not relabel, translate or convert an estimate into a '
                                 'claim of exact recitation.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Abu Saeed Khudri and the observing group estimating the Prophet’s prayer standing.',
                         'note': 'Read the complete Urdu field. It independently supplies the Zuhr/Asr duration estimates, their '
                                 'halves and the named-surah comparison. That comparison is part of the reported estimate, not '
                                 'compiler citation apparatus. No separate commentary tail is present; preserve the entire '
                                 'report and its estimation wording.'}},
 'abudawud:820': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Abu Hurayra reporting the Prophet’s command that he announce the recitation requirement.',
                         'note': 'Read all Hindi text. It explicitly reports the Prophet commanding Abu Hurayra to announce the '
                                 'requirement to recite Fatiha and another surah. The surah names are the actual content of the '
                                 'announcement, with no footnote locator or compiler tail. Preserve the source spellings, '
                                 'original final punctuation and the whole attributed report.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Abu Hurayra describing the announcement he was commanded by the Prophet to make.',
                         'note': 'Read the full Urdu field independently. This is a complete commanded-announcement report '
                                 'concerning Fatiha and another surah. There is no omitted-body pointer or explanatory tail. '
                                 'Retain every word under its printed Prophetic attribution while narrator metadata remains '
                                 'unchanged.'}},
 'tirmidhi:754': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Hakam’s question to Ibn Abbas and Ibn Abbas’s affirmative description of Muhammad’s fasting '
                                    'practice.',
                         'context': ['(इसी तरह रखते थे)'],
                         'note': 'Read the whole Hindi field. The Zamzam/cushion scene, the question about Ashura, Ibn Abbas’s '
                                 'instruction to count from the Muharram crescent and fast on the ninth, and his affirmative '
                                 'answer about Muhammad’s practice form one actual dialogue. Retain the unusual printed wording '
                                 'and source date. The parenthesis merely repeats what the final yes already affirms, so '
                                 'preserve it as explanatory context rather than supplying new narration.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Hakam ibn Araj’s dialogue with Ibn Abbas, who affirms the named Prophet’s practice.',
                         'context': ['( اسی طرح رکھتے تھے)'],
                         'note': 'Read the complete Urdu field independently. Its own dialogue supplies the ninth-day '
                                 'instruction and the explicit question and affirmative answer about Muhammad. Select the '
                                 'narrative scene and actual answer; the final parenthetic restatement of yes is context. No '
                                 'date is harmonized with another occurrence.'}},
 'tirmidhi:755': {'hi': {'type': 'mixed_attributed_reports',
                         'speaker': 'Ibn Abbas’s Prophetic tenth-day command report and a separately attributed Ibn Abbas '
                                    'ninth-and-tenth-day saying.',
                         'segments': [{'id': 'report-1',
                                       'start': None,
                                       'end': 'इमाम तिरमिधि कहते हैं:',
                                       'type': 'prophetic_report',
                                       'speaker': 'Abdullah ibn Abbas reporting the Prophet’s tenth-day Ashura command.'},
                                      {'id': 'report-2',
                                       'start': 'इब्न अब्बास से मरवी है',
                                       'end': 'शफी रहयह',
                                       'type': 'companion_statement',
                                       'speaker': 'Ibn Abbas in the explicitly attributed saying about the ninth and tenth '
                                                  'days.'}],
                         'note': 'Read the complete Hindi field. The initial tenth-day Prophetic command is a supplied report. '
                                 'The compiler’s grade and discussion of differing day identifications remain context, but the '
                                 'tail also quotes a finite separately attributed Ibn Abbas instruction to fast the ninth and '
                                 'tenth and differ from the Jews; retain that as a distinct Companion saying. The subsequent '
                                 'juristic attribution is compiler context. Preserve the source’s unusual spellings and do not '
                                 'reconcile the two reports or change the grade.'},
                  'ur': {'type': 'mixed_attributed_reports',
                         'speaker': 'Ibn Abbas reporting the Prophet’s command, followed by the separately quoted Ibn Abbas '
                                    'saying.',
                         'segments': [{'id': 'report-1',
                                       'start': None,
                                       'end': 'امام ترمذی کہتے ہیں:',
                                       'type': 'prophetic_report',
                                       'speaker': 'Abdullah ibn Abbas reporting the Prophet’s tenth-day command.'},
                                      {'id': 'report-2',
                                       'start': 'ابن عباس سے مروی ہے',
                                       'end': 'شافعی،',
                                       'type': 'companion_statement',
                                       'speaker': 'Ibn Abbas as the actual speaker attributed in the ninth-and-tenth-day '
                                                  'instruction.'}],
                         'note': 'Read all Urdu text independently. Separate the initial Prophetic command and the later '
                                 'explicitly quoted Ibn Abbas instruction as two report components. Tirmidhi’s grading, the date '
                                 'disagreement, its footnote marker and the final legal-school summary remain source context. '
                                 'The Companion’s words are not relabelled as Prophetic speech, and neither date nor supplied '
                                 'metadata is corrected.'}},
 'tirmidhi:760': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Abu Hurayra reporting the three commitments the Prophet required of him.',
                         'context': ['(सलात-उद-दुहा)'],
                         'note': 'Read the complete Hindi field. All three numbered commitments—witr before sleep, three monthly '
                                 'fasts and the forenoon prayer—are actual report content. Keep the enumeration and source '
                                 'wording. The parenthetic Arabic prayer-name synonym after the already named Chasht prayer is '
                                 'lexical explanation and remains context.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Abu Hurayra reporting the Prophet’s threefold commitment.',
                         'context': ['( صلاۃ الضحیٰ )'],
                         'note': 'Read the full Urdu field independently. Its numbered three-part pledge supplies a complete '
                                 'Prophetic report. Retain all clauses and numerals; move only the redundant parenthetic name of '
                                 'the already identified forenoon prayer to context, without treating the enumeration digits as '
                                 'footnote markers.'}},
 'tirmidhi:767': {'hi': {'type': 'mixed_attributed_reports',
                         'speaker': 'Abu Qatada’s direct report and the separate finite Prophetic prohibition quoted by Tirmidhi '
                                    'through the stated Ahmad and Ishaq attribution.',
                         'segments': [{'start': None,
                                       'end': 'इमाम तिर्मिज़ी कहते हैं:',
                                       'id': 'report-1',
                                       'type': 'prophetic_report',
                                       'speaker': 'Abu Qatada recounting the question and the Prophet’s double-negative answer.'},
                                      {'id': 'report-2',
                                       'start': 'उन दोनों का कहना है के',
                                       'end': 'बाक़िया दिनों में',
                                       'type': 'prophetic_report',
                                       'speaker': 'The Prophet’s five-day prohibition as expressly reported in the compiler’s '
                                                  'quoted Ahmad/Ishaq statement; those two reporters are identified in the '
                                                  'immediately preceding source context.'}],
                         'context': ['(पूरे साल रोज़े)'],
                         'note': 'Read the complete Hindi field, including the entire legal tail. Select the initial question '
                                 'and double-negative Prophetic answer, then separately the actual finite statement attributed '
                                 'through the named Ahmad and Ishaq that the Prophet prohibited fasting on the five specified '
                                 'days. Its source attribution is preserved without claiming an independently verified chain. '
                                 'The sawm-al-dahr definition is lexical context; grading, route names, competing legal '
                                 'definitions and the subsequent remaining-days inference stay context. The independent second '
                                 'reading identified this actual embedded report inside the broader legal discussion, so the '
                                 'initial broad tail cut was narrowed.'},
                  'ur': {'type': 'mixed_attributed_reports',
                         'speaker': 'Abu Qatada’s direct report and the separate finite Prophetic prohibition quoted by Tirmidhi '
                                    'through the stated Ahmad and Ishaq attribution.',
                         'segments': [{'start': None,
                                       'end': 'امام ترمذی کہتے ہیں:',
                                       'id': 'report-1',
                                       'type': 'prophetic_report',
                                       'speaker': 'Abu Qatada recounting the question and the Prophet’s double-negative answer.'},
                                      {'id': 'report-2',
                                       'start': 'ان دونوں کا کہنا ہے کہ',
                                       'end': 'بقیہ دنوں میں',
                                       'type': 'prophetic_report',
                                       'speaker': 'The Prophet’s five-day prohibition as expressly reported in the compiler’s '
                                                  'quoted Ahmad/Ishaq statement; those two reporters are identified in the '
                                                  'immediately preceding source context.'}],
                         'context': ['( پورے سال روزے )', '۱؎'],
                         'note': 'Read the entire Urdu field independently. Retain the initial question and complete '
                                 'double-negative answer, and separately the expressly supplied five-day Prophetic prohibition '
                                 'in Ahmad/Ishaq’s quoted statement. Keep the stated attribution limits and all named days. The '
                                 'annual-fast gloss and footnote are apparatus; the grade, route list, legal definitions and '
                                 'remaining-days ruling are context. After the independent reading, the actual embedded '
                                 'prohibition is retained while its surrounding legal commentary remains excluded from '
                                 'quotation.'}},
 'tirmidhi:768': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Aisha answering Abdullah ibn Shaqiq about the Prophet’s fasting practice.',
                         'segments': [{'start': None, 'end': 'इमाम तिर्मिज़ी कहते हैं:'}],
                         'note': 'Read the complete Hindi field. Abdullah’s question and Aisha’s detailed description of '
                                 'sustained fasting, pauses and the complete month being Ramadan form a finite attributed '
                                 'practice report. Preserve the full-month qualification and all framing. Tirmidhi’s grade and '
                                 'names of other reporting Companions are compiler context.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Aisha’s answer to Abdullah ibn Shaqiq concerning the Prophet’s fasts.',
                         'segments': [{'start': None, 'end': 'امام ترمذی کہتے ہیں:'}],
                         'context': ['۱؎'],
                         'note': 'Read the whole Urdu field independently. Select Aisha’s complete answer and question framing, '
                                 'including the Ramadan-only full-month qualification. Remove only the numeric footnote glyph '
                                 'from the report; the compiler grade and other-route names remain context. The source’s '
                                 'grammatical wording is unchanged.'}},
 'tirmidhi:769': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Anas ibn Malik answering the question about the Prophet’s fasting and night practice.',
                         'segments': [{'start': None, 'end': 'इमाम तिर्मिज़ी कहते हैं:'}],
                         'note': 'Read all Hindi text. Anas’s reply contains both the alternation of prolonged fasts and pauses '
                                 'and the observation of prayer or sleep at different night portions. Both are actual supplied '
                                 'narration and stay together under Anas’s attribution. Only the final Tirmidhi grading '
                                 'statement is compiler context.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Anas ibn Malik describing the Prophet’s fasting, prayer and sleep.',
                         'segments': [{'start': None, 'end': 'امام ترمذی کہتے ہیں:'}],
                         'note': 'Read the complete Urdu field independently. Its answer supplies the observers’ impressions '
                                 'about fasting and the nighttime prayer/sleep observation. Retain every actual clause, '
                                 'including the impressions rather than asserting an unprinted fixed schedule. The final '
                                 'compiler grade is context.'}},
 'tirmidhi:772': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Abu Saeed Khudri reporting the Prophet’s prohibition of the two named fasts.',
                         'segments': [{'start': None, 'end': 'इमाम तिर्मिज़ी कहते हैं:'}],
                         'context': ['(बक़र ईद)', '(ईद)'],
                         'note': 'Read the whole Hindi field. Select the two-fasts prohibition with the printed names of the '
                                 'Adha and Fitr days. Their parenthetic vernacular synonyms are lexical context. The grading, '
                                 'other Companion routes, scholarly-practice summary and narrator-identification/reliability '
                                 'tail are compiler apparatus and remain context with all source spellings intact.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Abu Saeed Khudri relating the Prophet’s two-day fasting prohibition.',
                         'segments': [{'start': None, 'end': 'امام ترمذی کہتے ہیں:'}],
                         'context': ['( بقر عید )', '( عید )'],
                         'note': 'Read every Urdu word independently. The opening is an actual two-day prohibition, while the '
                                 'rest explicitly gives Tirmidhi’s grading, parallel-source names, legal-practice notice and '
                                 'transmitter identification. Retain the actual day names; the parenthetic alternate names are '
                                 'explanatory context. Do not repair the unusual printed transmitter identification from outside '
                                 'knowledge.'}},
 'tirmidhi:775': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Abdullah ibn Abbas reporting the Prophet being cupped while in ihram and fasting.',
                         'segments': [{'start': None, 'end': 'इमाम तिर्मिज़ी कहते हैं:'}],
                         'note': 'Read the complete Hindi field. The first sentence supplies the actual cupping report with both '
                                 'ihram and fasting conditions. Tirmidhi’s correctness label, route comparison and the stated '
                                 'mursal version omitting Ibn Abbas are transmission criticism in context. Keep that criticism '
                                 'beside the report without resolving the chain dispute or changing the source grade.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Abdullah ibn Abbas in the supplied cupping report.',
                         'segments': [{'start': None, 'end': 'امام ترمذی کہتے ہیں:'}],
                         'note': 'Read the entire Urdu field independently. Select the Prophet’s cupping action and both printed '
                                 'circumstances. The remaining text compares transmission routes and explicitly notes Ikrima’s '
                                 'omission of Ibn Abbas; preserve it as compiler/transmission context. The supplied marfu report '
                                 'is not silently replaced with the compiler’s mursal description.'}},
 'tirmidhi:783': {'hi': {'type': 'companion_statement',
                         'speaker': 'Aisha describing her own practice of making up missed Ramadan fasts.',
                         'segments': [{'start': None, 'end': 'इमाम तिरमिधि कहते हैं:'}],
                         'note': 'Read the complete Hindi field. Aisha reports her own delayed make-up fasts in Shaban, with the '
                                 'printed until-the-Prophet’s-death qualification. This is her own attributed practice, not '
                                 'direct Prophetic speech. Retain the whole finite statement and its unusual source spellings; '
                                 'Tirmidhi’s final grade remains context.'},
                  'ur': {'type': 'companion_statement',
                         'speaker': 'Aisha speaking about her own missed-fast make-up practice.',
                         'segments': [{'start': None, 'end': 'امام ترمذی کہتے ہیں:'}],
                         'note': 'Read the complete Urdu field independently. The subject is Aisha’s own Ramadan make-up fasts '
                                 'in Shaban and the source’s temporal qualification ending with the Prophet’s death. Preserve '
                                 'that statement under her voice and do not infer a new Prophetic instruction. The separate '
                                 'Tirmidhi grade is context.'}},
 'tirmidhi:787': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Aisha reporting the Prophet’s instructions after menstruation.',
                         'segments': [{'start': None, 'end': 'इमाम तिर्मिज़ी कहते हैं:'}],
                         'note': 'Read the complete Hindi field. Aisha explicitly attributes to the Prophet the instruction to '
                                 'make up fasts and the absence of an instruction to make up prayers. Preserve both clauses and '
                                 'their contrast in the actual report. The following grade, Muadha route and juristic agreement '
                                 'statement are compiler context, not new narration.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Aisha describing the Prophet’s fast and prayer make-up instructions.',
                         'segments': [{'start': None, 'end': 'امام ترمذی کہتے ہیں:'}],
                         'note': 'Read the whole Urdu field independently. Its opening supplies Aisha’s period/purification '
                                 'setting and the Prophet’s affirmative fast instruction together with the negative prayer '
                                 'instruction. Keep the complete contrast. Tirmidhi’s grade, alternate chain and legal-practice '
                                 'discussion remain context.'}},
 'tirmidhi:788': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Laqit ibn Sabra reporting his wudu question and the Prophet’s answer.',
                         'segments': [{'start': None, 'end': 'इमाम तिर्मिज़ी कहते हैं:'}],
                         'note': 'Read all Hindi text. The question and the three actual purification instructions form the '
                                 'supplied report. The unless-you-are-fasting exception is essential limiting content and '
                                 'remains selected. Tirmidhi’s grade and subsequent legal explanation about swallowing '
                                 'water/fast validity and corroborating reports are context.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Laqit ibn Sabra’s dialogue with the Prophet.',
                         'segments': [{'start': None, 'end': 'امام ترمذی کہتے ہیں:'}],
                         'note': 'Read the entire Urdu field independently. Retain the full wudu answer, inter-finger action, '
                                 'source wording about water in the nose, and the explicit fasting exception. Do not repair the '
                                 'printed lexical wording. The final compiler grading and legal rationale remain in exact '
                                 'context.'}},
 'tirmidhi:793': {'hi': {'type': 'mixed_attributed_reports',
                         'speaker': 'Ubay ibn Kaab’s reply to Zirr, followed by the separate Zirr statement identified in the '
                                    'source parenthesis.',
                         'segments': [{'id': 'report-1',
                                       'start': None,
                                       'end': '(ज़रर कहते हैं)',
                                       'type': 'companion_statement',
                                       'speaker': 'Ubay ibn Kaab replying to Zirr; this Hindi field does not itself print the '
                                                  'Urdu field’s explicit Prophetic attribution.'},
                                      {'id': 'report-2',
                                       'start': 'अल्लाह की क़सम!',
                                       'end': 'इमाम तिरमिधि कहते हैं:',
                                       'type': 'attributed_statement',
                                       'speaker': 'Zirr, as identified by the immediately preceding source parenthesis, stating '
                                                  'what Ibn Masud knew and why he did not disclose it.'}],
                         'context': ['(किरण)', '(इसे मुसलमानों!)'],
                         'note': 'Read the complete Hindi field. It gives Zirr’s question, Ubay’s finite answer about the '
                                 'twenty-seventh night and rayless sunrise, but omits the explicit Prophet-told-us clause '
                                 'present in Urdu. Preserve that omission and the damaged remembered-wording; do not import a '
                                 'Prophetic speaker into Hindi. The separately identified Zirr oath about Ibn Masud’s knowledge '
                                 'and reason for withholding it is a distinct attributed statement. Keep the '
                                 'narrator-identification parenthesis, ray synonym, added addressee gloss and final compiler '
                                 'grade as context.'},
                  'ur': {'type': 'mixed_attributed_reports',
                         'speaker': 'Ubay explicitly reporting the Prophet’s information to Zirr, followed by the separately '
                                    'identified Zirr oath.',
                         'segments': [{'id': 'report-1',
                                       'start': None,
                                       'end': '( زرّ کہتے ہیں )',
                                       'type': 'prophetic_report',
                                       'speaker': 'Ubay ibn Kaab, who expressly says in this Urdu field that the Prophet '
                                                  'informed them of the rayless-sunrise sign.'},
                                      {'id': 'report-2',
                                       'start': 'اللہ کی قسم!',
                                       'end': 'امام ترمذی کہتے ہیں:',
                                       'type': 'attributed_statement',
                                       'speaker': 'Zirr, identified by the adjacent printed parenthesis, speaking about Ibn '
                                                  'Masud’s knowledge and nondisclosure.'}],
                         'context': ['( اسے مسلمانو! )'],
                         'note': 'Read all Urdu text independently. Unlike Hindi, this field explicitly names the Prophet as '
                                 'informing them of the sign, and supplies counting/remembering wording; select that actual '
                                 'local report under its printed attribution. Preserve the separate Zirr statement about Ibn '
                                 'Masud without merging speakers. The source’s Zirr-identification parenthesis, editorial '
                                 'addressee and final Tirmidhi grade stay context; keep the original unbalanced quotation '
                                 'punctuation.'}},
 'tirmidhi:794': {'hi': {'type': 'mixed_attributed_reports',
                         'speaker': 'Abu Bakra’s quoted Prophetic instruction and the separate account of Abu Bakra’s own '
                                    'Ramadan prayer practice, through Uyayna’s father.',
                         'segments': [{'id': 'report-1',
                                       'start': None,
                                       'end': 'अबू बकरा (रज़ियल्लाहु अन्हु) रमज़ान',
                                       'type': 'prophetic_report',
                                       'speaker': 'Abu Bakra quoting what he heard the Prophet say, as reported by Uyayna’s '
                                                  'father.'},
                                      {'id': 'report-2',
                                       'start': 'अबू बकरा (रज़ियल्लाहु अन्हु) रमज़ान',
                                       'end': 'इमाम तिर्मिज़ी कहते हैं:',
                                       'type': 'companion_report',
                                       'speaker': 'The narrator’s report of Abu Bakra’s own prayer effort in Ramadan.'}],
                         'context': ['(महीना पूरा होने में)'],
                         'note': 'Read the whole Hindi field. Retain Abu Bakra’s stated reason for seeking the last ten nights '
                                 'and the actual remaining-nine/seven/five/three instruction, followed separately by the '
                                 'narrator’s account of Abu Bakra’s heightened worship. The month-completion parenthesis '
                                 'explains the already framed remaining-day count and is context; all count values, the last-ten '
                                 'restriction and Abu Bakra’s own practice stay selected. Tirmidhi’s grade remains context.'},
                  'ur': {'type': 'mixed_attributed_reports',
                         'speaker': 'Abu Bakra’s Prophetic quotation and the separate narrator’s description of Abu Bakra’s '
                                    'Ramadan practice.',
                         'segments': [{'id': 'report-1',
                                       'start': None,
                                       'end': 'ابوبکرہ رضی الله عنہ رمضان کے بیس دن',
                                       'type': 'prophetic_report',
                                       'speaker': 'Abu Bakra’s expressly heard Prophetic instruction through Uyayna’s father.'},
                                      {'id': 'report-2',
                                       'start': 'ابوبکرہ رضی الله عنہ رمضان کے بیس دن',
                                       'end': 'امام ترمذی کہتے ہیں:',
                                       'type': 'companion_report',
                                       'speaker': 'The narrator describing Abu Bakra’s own twenty-day and last-ten prayer '
                                                  'practice.'}],
                         'context': ['( مہینہ پورا ہونے میں )'],
                         'note': 'Read the complete Urdu field independently. The actual Prophetic remaining-day instruction and '
                                 'Abu Bakra’s own later practice have different actors and remain separate components. Preserve '
                                 'the last-ten setting, all numbers and the full practice contrast. The parenthetic expansion of '
                                 'what the remaining days count toward and the final compiler grade are context.'}},
 'tirmidhi:798': {'hi': {'type': 'companion_report',
                         'speaker': 'Salama ibn al-Akwa describing the revelation, the group’s fasting/fidya practice and the '
                                    'subsequent change.',
                         'segments': [{'start': None, 'end': 'इमाम तिर्मिज़ी कहते हैं:'}],
                         'context': ['(अल-बक़राह: 184)'],
                         'note': 'Read the complete Hindi field. This is Salama’s historical account of revelation and the '
                                 'group’s practice, including the actual recited verse wording and its supplied full '
                                 'Hindi/Urdu-style meaning. Keep that recitation and translation, including the long '
                                 'parenthesis, as source report content. Move only the explicit surah-and-verse locator and '
                                 'final compiler grade to context. Preserve Salama’s own statement of abrogation without '
                                 'presenting it as a new independent ruling or repairing the verse translation.'},
                  'ur': {'type': 'companion_report',
                         'speaker': 'Salama ibn al-Akwa reporting the revelation and the Companions’ described practice change.',
                         'segments': [{'start': None, 'end': 'امام ترمذی کہتے ہیں:'}],
                         'context': ['( البقرہ: ۱۸۴ )', '۱؎', '۲؎'],
                         'note': 'Read all Urdu text independently. Retain the actual Arabic verse quotation, its supplied Urdu '
                                 'meaning and the narrator’s description of paying fidya until the following verse changed the '
                                 'practice. The numbered surah locator and two numeric footnote glyphs are citation apparatus; '
                                 'Tirmidhi’s final grade is compiler context. No subsequent verse text is filled in from outside '
                                 'this field.'}},
 'tirmidhi:799': {'hi': {'type': 'companion_report',
                         'speaker': 'Muhammad ibn Kaab observing Anas ibn Malik, with Anas’s own answer that the practice is '
                                    'Sunnah.',
                         'note': 'Read the complete Hindi field. Muhammad describes Anas preparing for travel in Ramadan, eating '
                                 'after the mount and clothes were ready, answering the Sunnah question and then mounting. This '
                                 'finite Companion action and dialogue is fully supplied. Retain the whole field; the word '
                                 'Sunnah does not justify inventing an unprinted direct Prophetic quotation.'},
                  'ur': {'type': 'companion_report',
                         'speaker': 'Muhammad ibn Kaab narrating Anas’s travel preparation, meal and own Sunnah affirmation.',
                         'note': 'Read the whole Urdu field independently. Its own narrative contains the prepared saddle, '
                                 'travel clothing, meal, question and affirmative answer before departure. There is no compiler '
                                 'tail. Select all source words under Anas’s actual Companion action and answer, without adding '
                                 'a Prophetic speaker or external canonical identity.'}},
 'tirmidhi:800': {'hi': {'type': 'attributed_narration_fragment',
                         'speaker': 'Muhammad ibn Kaab explicitly reporting his own Ramadan visit to Anas ibn Malik.',
                         'segments': [{'start': 'मुहम्मद बिन कअब से रिवायत है के', 'end': 'फिर उन्होंने इसी तरह ज़िक्र किया।'}],
                         'note': 'Read the complete Hindi field. Although the later account is omitted behind a same-as-before '
                                 'pointer, the field actually supplies Muhammad ibn Kaab’s finite first-person report that he '
                                 'visited Anas during Ramadan. Retain only that source-bound event fragment and its own '
                                 'attribution, without borrowing the meal, departure or Sunnah dialogue from another occurrence. '
                                 'The relative-chain prefix, omitted-body pointer, narrator criticism and legal commentary '
                                 'remain complete context.'},
                  'ur': {'type': 'attributed_narration_fragment',
                         'speaker': 'Muhammad ibn Kaab, who supplies the actual first-person Ramadan visit clause.',
                         'segments': [{'start': 'محمد بن کعب سے روایت ہے کہ', 'end': 'پھر انہوں نے اسی طرح ذکر کیا۔'}],
                         'note': 'Read all Urdu text independently. It is not only a bare chain: the first-person arrival at '
                                 'Anas in Ramadan is explicitly supplied and may remain as that limited narrated-event fragment. '
                                 'Nothing beyond the subsequent similarly-mentioned pointer is reconstructed. Separate the '
                                 'relative introduction and all remaining compiler biographical, reliability and travel-law '
                                 'discussion as source context.'}},
 'tirmidhi:806': {'hi': {'type': 'mixed_attributed_reports',
                         'speaker': 'Abu Dharr’s Prophetic Ramadan prayer report and the separately supplied narrator’s '
                                    'question/answer about Falah.',
                         'segments': [{'id': 'report-1',
                                       'start': None,
                                       'end': '(रावी कहते हैं)',
                                       'type': 'prophetic_report',
                                       'speaker': 'Abu Dharr narrating the Prophet’s prayer nights, response and gathering of '
                                                  'his household.'},
                                      {'id': 'report-2',
                                       'start': 'मैंने पूछा: फ़लाह क्या चीज़ है?',
                                       'end': None,
                                       'type': 'attributed_dialogue',
                                       'speaker': 'The unnamed questioner identified as narrator, and the respondent in the '
                                                  'appended source dialogue; no additional chain identity is supplied.'}],
                         'context': ['(तरावही)', '(यानी तहज्जुद पढ़ी)'],
                         'note': 'Read the complete Hindi field. Preserve the full Ramadan night sequence, the actual '
                                 'imam-until-completion saying, the household gathering and the source’s literal 27th नाइट '
                                 'wording. The parenthetic prayer-name definitions are lexical context. The final explicitly '
                                 'narrated question and answer about Falah are a separate finite dialogue; preserve their actual '
                                 'words and limited speaker identification, while the parenthetic narrator label stays context. '
                                 'No longer Urdu compiler discussion is supplied to Hindi.'},
                  'ur': {'type': 'mixed_attributed_reports',
                         'speaker': 'Abu Dharr’s Prophetic prayer account, the separate Falah dialogue, and al-Shafii’s own '
                                    'Mecca observation quoted later in the compiler discussion.',
                         'segments': [{'id': 'report-1',
                                       'start': None,
                                       'end': '( راوی کہتے ہیں )',
                                       'type': 'prophetic_report',
                                       'speaker': 'Abu Dharr reporting the Prophet’s prayer nights and actual answer to the '
                                                  'group.'},
                                      {'id': 'report-2',
                                       'start': 'میں نے پوچھا: فلاح کیا چیز ہے؟',
                                       'end': 'امام ترمذی کہتے ہیں:',
                                       'type': 'attributed_dialogue',
                                       'speaker': 'The source-labelled but unnamed narrator asking, and the respondent in the '
                                                  'actual appended dialogue.'},
                                      {'id': 'report-3',
                                       'start': 'اور شافعی کہتے ہیں:',
                                       'end': '۵- احمد کہتے ہیں:',
                                       'type': 'attributed_historical_statement',
                                       'speaker': 'Al-Shafii’s own reported observation that people in his city Mecca prayed '
                                                  'twenty units, as explicitly quoted by Tirmidhi.'}],
                         'context': ['( تراویح )', '( یعنی تہجد نہیں پڑھی )', '( تو بہتر ہوتا )'],
                         'context_repeated': [{'text': '( یعنی تہجد پڑھی )', 'count': 2}],
                         'note': 'Read the entire Urdu field independently, including all juristic discussion. Select the '
                                 'narrated night sequence, imam-completion answer and household scene; separately retain the '
                                 'actual Falah question/answer with its limited speaker identification. Also retain the explicit '
                                 'Shafii first-person observation of people praying twenty units in his city Mecca as a distinct '
                                 'historical statement, not as Prophetic speech or a legal preference. The independent reading '
                                 'identified that actual embedded observation within the broader tail, so the initial broad cut '
                                 'was narrowed. Both repeated Tahajjud glosses, other prayer-name explanations, the redundant '
                                 'completion of the group’s wish, and the parenthetic narrator label remain context. Grade, '
                                 'route names, numerical legal preferences, later arguments and their marker remain exact '
                                 'compiler context.'}},
 'tirmidhi:809': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Abu Shurayh reporting to Amr ibn Saeed what he personally heard the Prophet say after the '
                                    'conquest of Mecca.',
                         'note': 'Read the complete Hindi field. It supplies Abu Shurayh’s request to relate the witnessed '
                                 'sermon and the actual Mecca sanctity, bloodshed, tree-cutting, temporary permission and '
                                 'transmit-to-the-absent clauses. This Hindi field ends with the sermon and lacks the longer '
                                 'Urdu reply and compiler commentary; retain only its exact whole text, without importing those '
                                 'additions.'},
                  'ur': {'type': 'mixed_attributed_reports',
                         'speaker': 'Abu Shurayh’s Prophetic sermon report and Amr ibn Saeed’s separate reply related by Abu '
                                    'Shurayh.',
                         'segments': [{'id': 'report-1',
                                       'start': None,
                                       'end': 'ابوشریح سے پوچھا گیا:',
                                       'type': 'prophetic_report',
                                       'speaker': 'Abu Shurayh recounting the Prophet’s sermon with the scene of his own address '
                                                  'to Amr ibn Saeed.'},
                                      {'id': 'report-2',
                                       'start': 'ابوشریح سے پوچھا گیا:',
                                       'end': 'امام ترمذی کہتے ہیں:',
                                       'type': 'historical_dialogue',
                                       'speaker': 'Amr ibn Saeed’s own reply, reported by Abu Shurayh in answer to an unnamed '
                                                  'questioner; it is not the Prophet’s statement.'}],
                         'context': ['۲؎', '( عبداللہ بن زبیر سے قتال کے لیے )', '( قتال کا )'],
                         'note': 'Read all Urdu text independently. Keep the historical army-dispatch framing, the witnessed '
                                 'Prophetic sermon and the subsequent Amr reply as distinct components. The footnote, added '
                                 'identification of the expedition’s target and redundant repetition of combat are apparatus. '
                                 'Retain the parenthesis limiting the Mecca prohibition to fighting and the reply’s rebel '
                                 'qualification: removing either would broaden the selected assertion. The entire Tirmidhi '
                                 'grading, narrator identification and lexical/legal tail remain context; Amr’s disputed '
                                 'response is never attributed to the Prophet.'}},
 'tirmidhi:814': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Ali ibn Abi Talib reporting the revelation and the Prophet’s response, in the defective '
                                    'wording actually supplied by the Hindi field.',
                         'note': 'Read the complete Hindi field. It contains Ali’s narrated revelation, the Prophet’s silence, '
                                 'the repeated every-year question, a damaged response and the subsequent quoted divine '
                                 'instruction. Retain all supplied words, including the genuine translated Quranic wording, but '
                                 'do not restore the omitted first question or the broken if-I-said-yes clause from Urdu. Its '
                                 'defects and omissions remain explicit in this reading note; no outside canonical '
                                 'reconstruction is made.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Ali ibn Abi Talib narrating the revelation and the Prophet’s answer about yearly Hajj.',
                         'segments': [{'start': None, 'end': 'امام ترمذی کہتے ہیں:'}],
                         'note': 'Read the whole Urdu field independently. Preserve the complete Hajj-revelation dialogue and '
                                 'both genuine translated divine quotations. Both the obligatory predicate in the question and '
                                 'the every-year qualifier in the conditional answer are actual scope-bearing speech content; '
                                 'retain both parentheses. Removing them would weaken the stated question or annual consequence. '
                                 'The source’s final grade, Abu al-Bakhtari identification and parallel-route list remain '
                                 'compiler context. The independent reading confirmed these predicates should not be treated as '
                                 'dispensable lexical labels.'}},
 'tirmidhi:817': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Jabir ibn Abdullah describing the Prophet’s Hajj announcement and departure to Bayda.',
                         'segments': [{'start': None, 'end': 'इमाम तिर्मिज़ी कहते हैं:'}],
                         'note': 'Read the complete Hindi field. The announcement, gathering of people, movement from the '
                                 'earlier place to Bayda and entering ihram are actual narrated events. Retain the parenthetic '
                                 'movement clause because it supplies a narrative transition rather than a lexical synonym. The '
                                 'final compiler grade and alternate Companion routes are context.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Jabir ibn Abdullah recounting the Prophet’s Hajj announcement, journey and ihram.',
                         'segments': [{'start': None, 'end': 'امام ترمذی کہتے ہیں:'}],
                         'context': ['( مدینہ میں )', '۱؎'],
                         'note': 'Read the whole Urdu field independently. Retain the announcement, gathering, actual '
                                 'departure/movement clause in parentheses and arrival at Bayda with ihram. The parenthetic '
                                 'Medina place-identification label and footnote glyph are apparatus. Tirmidhi’s final grade and '
                                 'other-route names remain context; no location or timing is harmonized with the next '
                                 'occurrence.'}},
 'tirmidhi:818': {'hi': {'type': 'companion_statement',
                         'speaker': 'Abdullah ibn Umar giving the printed rebuttal and abbreviated talbiyah-location statement; '
                                    'missing Urdu clauses are not supplied.',
                         'segments': [{'start': None, 'end': 'इमाम तिरमिधि कहते हैं:'}],
                         'note': 'Read the complete Hindi field. Preserve Ibn Umar’s denial of the Bayda attribution together '
                                 'with its parenthetic content and the defective affirmative tree/talbiyah location fragment. '
                                 'The false-attribution content must remain under the printed lie/rebuttal framing, and the '
                                 'Dhul-Hulayfa parenthesis is the sole named location in the affirmative fragment, so both are '
                                 'substantive report content. This Hindi version omits the Urdu oath, explicit affirmative '
                                 'Prophetic subject and mosque noun; do not reconstruct them. The final grade is context.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Abdullah ibn Umar rejecting the Bayda attribution and expressly reporting the Prophet’s '
                                    'talbiyah by the named mosque/tree.',
                         'segments': [{'start': None, 'end': 'امام ترمذی کہتے ہیں:'}],
                         'context': ['۱؎', '۲؎'],
                         'note': 'Read all Urdu text independently. Keep the complete corrective contrast: the alleged Bayda '
                                 'action is explicitly called false, while the oath introduces the positive Prophetic talbiyah '
                                 'report near the Dhul-Hulayfa mosque and tree. The parentheses provide the rejected claim’s '
                                 'content and the specific location needed by that contrast; retain them rather than isolating a '
                                 'false affirmation or losing the location. Only footnote glyphs and the final compiler grade '
                                 'become context.'}},
 'tirmidhi:822': {'hi': {'type': 'mixed_attributed_reports',
                         'speaker': 'Ibn Abbas describing the Prophet’s tamattu practice, the separately named Companions’ '
                                    'practice and Muawiya’s later prohibition.',
                         'segments': [{'start': None, 'end': 'इमाम तिर्मिज़ी कहते हैं:'}],
                         'note': 'Read the complete Hindi field. This single connected historical statement has explicitly '
                                 'different actors: the Prophet, Abu Bakr/Umar/Uthman, and Muawiya. Preserve the whole source '
                                 'sentence under Ibn Abbas’s attribution and a mixed-report classification; do not label the '
                                 'Companions’ actions or the later prohibition as Prophetic speech. Tirmidhi’s final grading '
                                 'statement is context.'},
                  'ur': {'type': 'mixed_attributed_reports',
                         'speaker': 'Ibn Abbas relating the distinct tamattu practice and prohibition claims about the named '
                                    'actors.',
                         'segments': [{'start': None, 'end': 'امام ترمذی کہتے ہیں:'}],
                         'context': ['۱؎', '۲؎', '۳؎'],
                         'note': 'Read the full Urdu field independently. The report expressly distinguishes the Prophet’s '
                                 'action, the three named Companions’ matching practice and Muawiya’s subsequent prohibition. '
                                 'Retain the connected historical account with those actual actors. The three numeric footnote '
                                 'glyphs and the final compiler grade are context; no modern authenticity or legal verdict is '
                                 'added.'}},
 'ibnmajah:749': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Abdullah ibn Amr ibn al-As reporting the Prophet’s mosque prohibition.',
                         'note': 'Read all Hindi text. The field supplies a finite Prophetic prohibition of commerce and the '
                                 'specified nonreligious poetry in the mosque. Retain the parenthetic nonreligious restriction '
                                 'because it limits which poetry the supplied translation prohibits; removing it would broaden '
                                 'the assertion. Preserve the source’s unusual trade-word spelling and final punctuation.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Abdullah ibn Amr ibn al-As reporting the Prophet’s prohibition.',
                         'context': ['۱؎'],
                         'note': 'Read the complete Urdu field independently. Preserve the commerce prohibition and the '
                                 'parenthetic nonreligious qualification on poetry as substantive limiting content. Cut only the '
                                 'final numeric footnote glyph. The selected statement must not become a broader prohibition of '
                                 'every kind of poetry by removing that qualification.'}},
 'ibnmajah:753': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Abu Dharr Ghifari questioning the Prophet about the first mosques and reporting his '
                                    'answers.',
                         'note': 'Read the complete Hindi field. It supplies the successive mosque questions, Haram/Aqsa '
                                 'answers, forty-year interval and the instruction that prayer can be performed on the earth '
                                 'where its time arrives. Preserve the entire dialogue with its actual number and names; there '
                                 'is no compiler or citation tail.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Abu Dharr Ghifari in the narrated first-mosques dialogue with the Prophet.',
                         'context': ['۱؎'],
                         'note': 'Read the entire Urdu field independently. Its own complete question/answer sequence supplies '
                                 'the two mosque names, interval and concluding prayer-place instruction. Retain all narration '
                                 'and remove only the final footnote glyph into context. No external chronology or geographical '
                                 'inference is added.'}},
 'ibnmajah:755': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Abu Hurayra recounting the unnamed blind Ansari’s request and the Prophet’s visit.',
                         'note': 'Read the complete Hindi field. An unnamed Ansari asks the Prophet to mark a prayer space in '
                                 'his house because he has become blind; the Prophet visits and fulfils that request. Select the '
                                 'whole finite report. Do not identify the unnamed man with a person in a parallel occurrence or '
                                 'supply a canonical cross-edition number.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Abu Hurayra reporting the unnamed Ansari’s message and the Prophet’s response in action.',
                         'context': ['۱؎'],
                         'note': 'Read all Urdu text independently. It contains the same field’s own request, blindness '
                                 'explanation and completed visit/action, without naming the Ansari. Preserve every narrated '
                                 'detail and the actual anonymity. Only the final footnote glyph is source apparatus.'}},
 'ibnmajah:759': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Aisha reporting the Prophet’s commands concerning neighbourhood mosques.',
                         'note': 'Read the entire Hindi field. The actual commands to establish neighbourhood mosques, keep them '
                                 'clean and apply fragrance are all supplied directly under the Prophet’s attribution. There is '
                                 'no separate compiler tail, citation marker or dispensable lexical parenthesis; retain the '
                                 'complete field.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Aisha relating the Prophet’s mosque-building, cleanliness and fragrance instructions.',
                         'note': 'Read the full Urdu field independently. Preserve its complete three-part instruction and '
                                 'original whitespace/punctuation. The field contains actual report content throughout; no '
                                 'unprinted conditions or external legal conclusions are added.'}},
 'ibnmajah:777': {'hi': {'type': 'attributed_report',
                         'speaker': 'This Hindi field expressly prints an Ibn Masud-to-Prophet attribution, while its Arabic and '
                                    'English siblings expressly quote Abdullah directly; preserve the source disagreement and '
                                    'the unmarked first-person voice.',
                         'context': ['(अहद-ए-नबवी सल्लल्लाहु अलैहि वसल्लम में)'],
                         'note': 'Read the complete Hindi field. It explicitly introduces Messenger-said wording, then includes '
                                 'your-Prophet language, the collective observation of attendance, a supported man entering the '
                                 'row and the walking-to-prayer reward. Preserve that complete supplied wording and its '
                                 'unresolved internal voice shift. Arabic/English were separately read and attribute the '
                                 'statement to Abdullah; that does not authorize correcting this Hindi attribution. The '
                                 'parenthetic Prophetic-era identification is editorial context. Registration here is an actual '
                                 'source-attributed report with the field disagreement stated, not a harmonized canonical '
                                 'Prophetic quotation.'},
                  'ur': {'type': 'attributed_report',
                         'speaker': 'The Urdu field’s explicit Messenger-said attribution via Ibn Masud is retained; the same '
                                    'source occurrence’s Arabic and English instead quote Abdullah directly.',
                         'context': ['( عہد نبوی صلی اللہ علیہ وسلم میں )', '۱؎'],
                         'note': 'Read the entire Urdu field independently. Keep the actual raised introduction, five-prayer '
                                 'exhortation, the unchanged your-Prophet and we-observed voices, the supported worshipper and '
                                 'the final walking reward. The Arabic/English disagreement is recorded rather than silently '
                                 'used to replace Urdu’s printed speaker. Only the historical-era parenthesis and footnote glyph '
                                 'are context; no source word, grade or canonical identity is repaired.'},
                  'ar': {'type': 'attributed_statement',
                         'speaker': 'Abdullah, expressly named as the speaker by the Arabic chain and qala; this field does not '
                                    'print the translations’ Messenger-said introduction.',
                         'segments': [{'start': 'عَنْ عَبْدِ اللَّهِ، قَالَ', 'end': None}],
                         'note': 'Read the complete Arabic field, including every transmitter in its opening chain. Its final '
                                 'chain attribution is to Abdullah, who gives the prayer exhortation, your-Prophet wording, '
                                 'first-person observations and walking reward. Select the actual Abdullah attribution and full '
                                 'statement; the earlier chain remains exact context. Do not add the Prophetic-said introduction '
                                 'printed by Hindi/Urdu/Roman, and do not expand the Arabic source’s Abdullah name from another '
                                 'language.'},
                  'en': {'type': 'attributed_statement',
                         'speaker': 'Abdullah, explicitly introduced as the speaker in the English field.',
                         'context': ['(i.e. on the Day of Judgment)', '(daily)', '(of worshippers)'],
                         'note': 'Read the complete English field independently. It explicitly quotes Abdullah and supplies the '
                                 'five-prayer exhortation, first-person attendance/assisted-man recollection and reward '
                                 'statement. Preserve the defective I have a man coming wording and the unclosed ending exactly. '
                                 'The Day-of-Judgment explanation, daily synonym and row-of-worshippers gloss are lexical '
                                 'context. Do not insert a Prophetic speaker to harmonize with the Hindi/Urdu/Roman fields.'},
                  'ur-Latn': {'type': 'attributed_report',
                              'speaker': 'The Roman Urdu field explicitly prints the Messenger-said attribution via Abdullah bin '
                                         'Masood; its Arabic and English siblings instead attribute the complete statement to '
                                         'Abdullah.',
                              'context': ['(Ahd-e-Nabwi Sallallahu Alaihi Wasallam mein)'],
                              'note': 'Read the complete Roman Urdu field. It repeats the explicit raised introduction together '
                                      'with the later unmarked collective voice, attendance recollection and walking reward. '
                                      'Preserve its exact wording and note the independently observed Arabic/English attribution '
                                      'difference. Only the Prophetic-era gloss is context. This language is admitted from its '
                                      'own full reading, with no canonical correction of the printed attribution.'}},
 'ibnmajah:784': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Anas ibn Malik recounting Banu Salama’s relocation plan and the Prophet’s response.',
                         'note': 'Read all Hindi text. The report gives the proposed move from distant homes, the Prophet’s '
                                 'concern about depopulation, his actual footsteps/reward question and the group’s decision to '
                                 'stay. Retain the whole narrated cause-and-response sequence with the original wording; there '
                                 'is no separate compiler apparatus.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Anas ibn Malik describing the Banu Salama event and the Prophet’s question.',
                         'note': 'Read the complete Urdu field independently. Preserve the intended move, the stated concern, '
                                 'the reward question and the actual staying outcome, including the source’s punctuation. The '
                                 'field supplies an actual coherent report throughout; no outside location or speaker is '
                                 'added.'}},
 'ibnmajah:792': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Abdullah ibn Umm Maktum giving his request and the Prophet’s reply.',
                         'note': 'Read the full Hindi field. It supplies the age/blindness/distance/guide circumstances, the '
                                 'request, the hearing-the-call question, affirmative answer and final response. Keep the '
                                 'parenthetic congregation-absence qualification because it defines the concession being sought; '
                                 'removing it would broaden the request and answer. Preserve all source wording without '
                                 'extending the report into general advice.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Abdullah ibn Umm Maktum’s reported dialogue with the Prophet.',
                         'context': ['۱؎'],
                         'note': 'Read the complete Urdu field independently. Retain every circumstance and the entire '
                                 'question/answer exchange. The congregation-absence parenthesis is essential scope, so it stays '
                                 'in the report; only the numeric footnote glyph becomes context. No wider disability or legal '
                                 'conclusion is inferred.'}},
 'ibnmajah:801': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Abdullah ibn Amr recounting the Prophet’s return and his report of the divine address to '
                                    'angels.',
                         'note': 'Read the complete Hindi field. The Maghrib setting, people remaining, the Prophet’s hurried '
                                 'return and exposed knees, the good-news statement and the embedded divine address are actual '
                                 'narrated content. Retain the whole field and the distinct speech levels as the source presents '
                                 'them; no compiler explanation is present.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Abdullah ibn Amr reporting the Prophet’s announcement, including its quoted divine address.',
                         'context': ['۱؎'],
                         'note': 'Read all Urdu text independently. Preserve the full prayer-waiting scene, the Prophet’s '
                                 'physical arrival details, the announcement and the explicitly embedded divine speech about the '
                                 'waiting servants. Remove only the final footnote glyph. Do not flatten the embedded speech '
                                 'into Abdullah’s own words.'}},
 'ibnmajah:811': {'hi': {'type': 'prophetic_report',
                         'speaker': 'Abdullah ibn Masud recounting the Prophet’s correction of his hand placement.',
                         'note': 'Read the complete Hindi field. The initial left-over-right position, the Prophet passing him '
                                 'and the actual right-over-left correction form one coherent action report. Preserve both '
                                 'positions and their sequence; the entire field is narration.'},
                  'ur': {'type': 'prophetic_report',
                         'speaker': 'Abdullah ibn Masud describing the Prophet moving his right hand over his left.',
                         'note': 'Read the full Urdu field independently. Keep the initial position and subsequent correction '
                                 'together so the initial position is not mistaken for the endorsed outcome. There is no '
                                 'compiler tail or apparatus, and the source’s lack of terminal punctuation remains unchanged.'}},
 'ibnmajah:815': {'hi': {'type': 'companion_statement',
                         'speaker': 'Abdullah ibn Mughaffal advising his son and recounting his own experience with the Prophet '
                                    'and the three named caliphs; the son remains unnamed beyond the source wording.',
                         'note': 'Read the complete Hindi field. The son’s observation about his father, the audible basmala, '
                                 'the father’s warning and his first-person report of what he did not hear are supplied '
                                 'narrative and speech. Retain the voice/aloud parenthesis because audibility limits the '
                                 'statement; this must not become a ban on saying the formula at all. Keep both actual recited '
                                 'formulas and the father’s final instruction under the father’s voice, not as a direct '
                                 'Prophetic command.'},
                  'ur': {'type': 'companion_statement',
                         'speaker': 'Abdullah ibn Mughaffal’s advice and reported experience, related by his son as named only '
                                    'generically in this field.',
                         'note': 'Read every Urdu word independently. It contains the son’s characterization, the father’s '
                                 'hearing of the basmala aloud, his warning, the quoted experience with the Prophet/Abu '
                                 'Bakr/Umar/Uthman and his own recitation instruction. Preserve the actual Arabic formulas and '
                                 'the audibility parenthesis, which is substantive scope. The father’s legal advice is an actual '
                                 'numbered Companion statement, and it is not relabelled as Prophetic speech.'}},
 'malik:754': {'hi': {'type': 'mixed_attributed_reports',
                      'speaker': 'Amra reports Ziyad’s letter containing the disputed Ibn Abbas claim, then Aisha’s corrective '
                                 'reply and Prophetic-action evidence.',
                      'segments': [{'id': 'report-1',
                                    'start': None,
                                    'end': 'उमराह ने कहा आयशा बोलीं:',
                                    'type': 'historical_report',
                                    'speaker': 'Ziyad ibn Abi Sufyan’s letter as reported by Amra; its Ibn Abbas claim is '
                                               'subsequently expressly disputed by Aisha.'},
                                   {'id': 'report-2',
                                    'start': 'उमराह ने कहा आयशा बोलीं:',
                                    'end': None,
                                    'type': 'prophetic_report',
                                    'speaker': 'Aisha’s explicit denial and her first-person account of the Prophet’s '
                                               'sacrificial-animal preparation and unchanged permissions.'}],
                      'context': ['(कुरबानी का जानवर)'],
                      'note': 'Read the complete Hindi field. Preserve the letter/request and its attributed but disputed Ibn '
                              'Abbas position, then Aisha’s full not-as-he-says response and her own concrete Prophetic-action '
                              'evidence as a separate component. Keep every negation and the until-slaughter limit; the letter’s '
                              'claim is not independently affirmed. Only the lexical explanation of hady is context. The father '
                              'mentioned by Aisha is left as her own printed relational wording.'},
               'ur': {'type': 'mixed_attributed_reports',
                      'speaker': 'Amra’s report of Ziyad’s letter and Aisha’s corrective answer with her own Prophetic-action '
                                 'account.',
                      'segments': [{'id': 'report-1',
                                    'start': None,
                                    'end': 'عمرہ نے کہا عائشہ بولیں',
                                    'type': 'historical_report',
                                    'speaker': 'Ziyad’s quoted letter and request, including the Ibn Abbas claim challenged by '
                                               'the following reply.'},
                                   {'id': 'report-2',
                                    'start': 'عمرہ نے کہا عائشہ بولیں',
                                    'end': None,
                                    'type': 'prophetic_report',
                                    'speaker': 'Aisha expressly rejecting the claimed rule and describing what she and the '
                                               'Prophet actually did.'}],
                      'note': 'Read the entire Urdu field independently. The letter’s reported position and Aisha’s rebuttal '
                              'must remain in their distinct attributed components. Retain the complete corrective negation and '
                              'the account of braiding, attaching, sending and the absence of new prohibitions until slaughter. '
                              'No words are removed from this field; the source’s own relational names and spelling remain '
                              'exact.'}},
 'malik:760': {'hi': {'type': 'prophetic_report',
                      'speaker': 'Saeed ibn al-Musayyab answering an unnamed questioner by reporting the Prophet’s umra before '
                                 'Hajj, through Abdur Rahman ibn Harmala.',
                      'note': 'Read the complete Hindi field. The named transmitter reports an actual question and affirmative '
                              'answer, followed by an explicit finite statement of the Prophet’s umra before Hajj. Keep the '
                              'entire dialogue and its actual indirect attribution. Do not turn Saeed into a direct eyewitness '
                              'or invent an omitted connecting chain.'},
               'ur': {'type': 'prophetic_report',
                      'speaker': 'Saeed ibn al-Musayyab’s answer and reported Prophetic practice, as transmitted by Abdur Rahman '
                                 'ibn Harmala.',
                      'note': 'Read the complete Urdu field independently. The actual unnamed man’s question and Saeed’s answer '
                              'are fully supplied and include the finite Prophetic-practice statement. Preserve the indirect '
                              'transmission and the whole text, without a claimed canonical mapping or repaired chain.'}},
 'malik:797': {'hi': {'type': 'prophetic_report',
                      'speaker': 'Abdullah ibn Abbas recounting Fadl, the unnamed woman’s Hajj question and the Prophet’s '
                                 'actions and answer.',
                      'note': 'Read the full Hindi field. Preserve Fadl’s riding position, the reciprocal looking, the Prophet '
                              'turning his face, the woman’s elderly-father/camel limitation, the affirmative Hajj answer and '
                              'the Farewell-Hajj setting. All are actual supplied narrative details; do not name the woman or '
                              'merge this source identity with another occurrence.'},
               'ur': {'type': 'prophetic_report',
                      'speaker': 'Abdullah ibn Abbas reporting the Fadl-and-woman scene and the Prophet’s answer during the '
                                 'Farewell Hajj.',
                      'note': 'Read all Urdu text independently. Keep the whole action/dialogue sequence and its temporal '
                              'setting. Preserve the source’s unusual tribe spelling exactly instead of correcting it from Hindi '
                              'or outside knowledge; the unnamed woman remains unnamed and all restrictions in her question '
                              'remain intact.'}},
 'malik:807': {'hi': {'type': 'attributed_historical_statement',
                      'speaker': 'An unnamed learned person heard by Ibn Shihab, transmitted through Malik and Yahya as '
                                 'explicitly printed.',
                      'context': ['(हिज्र)'],
                      'note': 'Read the complete Hindi field. The numbered record transmits a finite historical-purpose '
                              'statement from an explicitly unnamed learned person: the enclosure makes people pass outside it '
                              'so circumambulation encompasses the original Kaaba. Retain that actual attributed statement and '
                              'transmission framing; it is not a Prophetic report and not a newly asserted historical fact by '
                              'this reviewer. The alternate place-name synonym is lexical context, and the source’s defective '
                              'phrasing remains unchanged.'},
               'ur': {'type': 'attributed_historical_statement',
                      'speaker': 'The unnamed ahl-e-ilm whose statement Ibn Shihab says he heard, through the printed '
                                 'Malik/Yahya transmission.',
                      'context': ['(حجر)'],
                      'note': 'Read the whole Urdu field independently. It supplies an actual reported causal statement about '
                              'the enclosure and circumambulation route under a transmitted, unnamed scholar attribution. '
                              'Preserve its anonymity and historical-statement type rather than attributing it to the Prophet or '
                              'to Malik’s own opinion. Only the duplicate Hijr name gloss is context; the entire substantive '
                              'purpose clause remains selected.'}}}
