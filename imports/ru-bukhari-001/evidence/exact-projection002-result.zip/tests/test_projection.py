"""Offline, standard-library regression suite for ONE private Bukhari1 Russian projection.
Run after extracting result ZIP: python tests/test_projection.py
No repository/network/browser required for these standard-library checks.
"""
from __future__ import annotations
import hashlib
import io
import json
import re
import unittest
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
sha = lambda b: hashlib.sha256(b).hexdigest()
enc = lambda s: s.encode('utf-8')

class HadithOnlyOneRecordTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.c = json.loads((HERE/'candidate.json').read_bytes())
        cls.m = json.loads((HERE/'source-display-map.json').read_bytes())
        cls.api_bytes = (HERE/'evidence'/'api-entry1-field.raw.utf8').read_bytes()
        cls.raw = cls.api_bytes.decode('utf-8')
        cls.html = (HERE/'evidence'/'isnad-1.html').read_bytes()
        cls.original_zip_bytes = (HERE/'evidence'/'original-pinned-source-packet.zip').read_bytes()
        cls.original_zip = zipfile.ZipFile(io.BytesIO(cls.original_zip_bytes))
        cls.display = cls.c['display']['foreign_hadith_text']

    def test_01_complete_pinned_evidence_and_original_manifest(self):
        self.assertEqual(sha(self.original_zip_bytes), '56054af50afb4a144ebbb8f6245afa51aa05a4c98418e8c65553d29a6b0cf250')
        self.assertIsNone(self.original_zip.testzip())
        manifest = json.loads(self.original_zip.read('manifest.json'))
        self.assertEqual(len(manifest),23)
        for name, claim in manifest.items():
            b=self.original_zip.read(name)
            self.assertEqual(len(b),claim['bytes'],name)
            self.assertEqual(sha(b),claim['sha256'],name)
        self.assertEqual(self.html,self.original_zip.read('existing-packet/isnad-1.html'))

    def test_02_exact_upstream_row_and_literal_escaped_newline(self):
        rows=json.loads(self.original_zip.read('existing-packet/exact-russian-source-rows.json'))
        self.assertEqual([r['hadithnumber'] for r in rows], [1,2,3])
        self.assertEqual(rows[0]['text'],self.raw)
        self.assertEqual(self.c['source']['raw_api_text_exact'],self.raw)
        self.assertEqual(self.c['source']['raw_api_text_sha256'],sha(self.api_bytes))
        self.assertEqual(sha(self.api_bytes),'135937267729f06952b5ff3e42896daf0fdc7ec784cbf69dfd1673357ef2b86a')
        self.assertEqual(len(self.api_bytes),776)
        self.assertEqual(self.raw.count('\\n'),1)
        self.assertEqual(self.raw.count('\n'),0)
        self.assertEqual(self.raw.count('[1]'),1)
        self.assertEqual(self.raw.count('[2]'),1)
        self.assertEqual(self.raw.count('[3]'),1)

    def test_03_exact_display_hash_and_no_unrequested_rewrite(self):
        self.assertEqual(sha(enc(self.display)),self.c['display']['foreign_hadith_text_sha256'])
        self.assertEqual(sha(enc(self.display)),self.m['display_text_sha256'])
        self.assertEqual(sha(enc(self.display)),'1b36b7d0a1d29b0bc47701568e76ab5f110cd79c14f205cca99593084a73a3b4')
        self.assertEqual(len(enc(self.display)),766)
        self.assertEqual(len(self.display),426)
        self.assertEqual(self.display.count('\n'),1)
        self.assertNotIn('\\n',self.display)
        expected=self.raw.replace('\\n','\n')
        for i in range(1,4):expected=expected.replace(f'[{i}]','')
        self.assertEqual(self.display,expected)
        self.assertNotIn('1 — ',self.display[:8])
        self.assertFalse(self.display.endswith('.'))
        self.assertTrue(self.display.endswith('»'))
        for i in range(1,4):self.assertNotIn(f'[{i}]',self.display)

    def test_04_no_gaps_overlaps_or_untracked_span_changes(self):
        rawcp=disp_cp=rawbyte=disp_byte=0
        reconstructed_raw=reconstructed_display=''
        changes=[]
        for j,s in enumerate(self.m['segments'],1):
            self.assertEqual(s['sequence'],j)
            src=s['source_codepoints'];dst=s['display_codepoints']
            bs=s['source_utf8_bytes'];bd=s['display_utf8_bytes']
            self.assertEqual((src['start'],bs['start']),(rawcp,rawbyte))
            self.assertEqual((dst['start'],bd['start']),(disp_cp,disp_byte))
            self.assertEqual(self.raw[src['start']:src['end_exclusive']],s['before'])
            self.assertEqual(self.api_bytes[bs['start']:bs['end_exclusive']],enc(s['before']))
            self.assertEqual(s['before_utf8_sha256'],sha(enc(s['before'])))
            self.assertEqual(s['after_utf8_sha256'],sha(enc(s['after'])))
            self.assertEqual(src['end_exclusive']-src['start'],len(s['before']))
            self.assertEqual(dst['end_exclusive']-dst['start'],len(s['after']))
            self.assertEqual(bs['end_exclusive']-bs['start'],len(enc(s['before'])))
            self.assertEqual(bd['end_exclusive']-bd['start'],len(enc(s['after'])))
            if s['action']=='copy':self.assertEqual(s['before'],s['after'])
            elif s['action']=='literal_escape_to_real_line_break':
                self.assertEqual((s['before'],s['after']),('\\n','\n'))
                changes.append(s)
            elif s['action']=='exclude_source_verified_commentary_marker':
                self.assertRegex(s['before'],r'^\[[123]\]$')
                self.assertEqual(s['after'],'')
                changes.append(s)
            else:self.fail('Unapproved map operation')
            reconstructed_raw+=s['before'];reconstructed_display+=s['after']
            rawcp=src['end_exclusive'];rawbyte=bs['end_exclusive']
            disp_cp=dst['end_exclusive'];disp_byte=bd['end_exclusive']
        self.assertEqual(reconstructed_raw,self.raw)
        self.assertEqual(reconstructed_display,self.display)
        self.assertEqual((rawcp,rawbyte),(436,776))
        self.assertEqual((disp_cp,disp_byte),(426,766))
        self.assertEqual(len(changes),4)
        self.assertEqual([(x['action'],x['source_codepoints']['start']) for x in changes],
                         [('literal_escape_to_real_line_break',99),
                          ('exclude_source_verified_commentary_marker',303),
                          ('exclude_source_verified_commentary_marker',379),
                          ('exclude_source_verified_commentary_marker',432)])

    def test_05_original_html_two_narration_paragraphs_bound_exactly(self):
        self.assertEqual(self.m['html_source_sha256'],sha(self.html))
        self.assertEqual(len(self.html),25988)
        b=self.m['source_html_narration_boundaries']
        self.assertEqual(len(b),2)
        self.assertIn('p:nth-of-type(5)',b[0]['selector'])
        self.assertIn('p:nth-of-type(6)',b[1]['selector'])
        for x in b:
            h=x['html_russian_hadith_only_utf8'];r=x['api_raw_cp_span']
            self.assertEqual(self.html[h['byte_start']:h['byte_end_exclusive']],enc(self.raw[r['start']:r['end_exclusive']]))
            full=x['html_text_full_utf8']
            self.assertEqual(sha(self.html[full['byte_start']:full['byte_end_exclusive']]),full['utf8_sha256'])
        text1=self.html[b[0]['html_text_full_utf8']['byte_start']:b[0]['html_text_full_utf8']['byte_end_exclusive']]
        text2=self.html[b[1]['html_text_full_utf8']['byte_start']:b[1]['html_text_full_utf8']['byte_end_exclusive']]
        self.assertTrue(text1.startswith(enc('1 — ')))
        self.assertTrue(text2.endswith(enc('».')))
        self.assertNotIn(enc('1 — '),self.api_bytes[:8])
        self.assertTrue(self.html.find(enc('Комментарии А. Ниршы'))>b[1]['html_text_full_utf8']['byte_end_exclusive'])

    def test_06_exact_three_archived_note_anchors_not_matn(self):
        anchors=self.m['archival_commentary_anchors']
        self.assertEqual(len(anchors),3)
        note_heading_at=self.html.index(enc('Комментарии А. Ниршы'))
        for i,a in enumerate(anchors,1):
            self.assertEqual(a['id'],str(i))
            self.assertEqual(a['heading_original'],'Комментарии А. Ниршы')
            h=a['html_text_span_utf8'];m=a['html_marker_span_utf8']
            v=self.html[h['byte_start']:h['byte_end_exclusive']]
            self.assertTrue(note_heading_at<h['byte_start'])
            self.assertTrue(v.startswith(enc(f'[{i}] ')))
            self.assertEqual(len(v),a['note_text_utf8_bytes'])
            self.assertEqual(sha(v),a['note_text_sha256'])
            self.assertEqual(self.html[m['byte_start']:m['byte_end_exclusive']],enc(f'[{i}]'))
            marker_spans=[x for x in self.m['segments'] if x.get('archive_commentary_note_id')==str(i)]
            self.assertEqual(len(marker_spans),1)
            s=marker_spans[0];bs=s['source_marker_site_html_byte_start'];be=s['source_marker_site_html_byte_end_exclusive']
            self.assertEqual(self.html[bs:be],enc(f'[{i}]'))
            self.assertLess(bs,note_heading_at)
        self.assertTrue(self.c['source_archival_only']['notes_not_readings_or_standalone_display_targets'])
        # The entire unmodified original HTML, including all notes, is archived.
        self.assertIn(enc('Комментарии А. Ниршы'),self.html)
        self.assertIn(enc('Полезные выводы'),self.html)

    def test_07_exact_identity_and_separated_gates(self):
        gap=json.loads(self.original_zip.read('existing-packet/exact-gap-targets.json'))[0]
        self.assertEqual(gap['hadithnumber'],1)
        self.assertEqual(self.c['stable_existing_bank_record_id'],gap['existing_bank_id'])
        self.assertEqual(self.c['stable_existing_bank_record_id'],self.m['stable_target_record_id'])
        self.assertEqual(self.c['provider_entry_number'],1)
        self.assertEqual(self.c['source_identity']['source_path'],'Fawaz Ahmed Hadith API → Isnad.link (Daura)')
        self.assertFalse(self.c['source_identity']['api_full_original_body_supplied'])
        self.assertEqual(self.c['source_identity']['api_source_body_hash_pinned_not_independently_recomputed'],gap['source_body_sha256'])
        self.assertEqual(self.c['source_metadata_not_hadith_text']['ai_translation_status'],'unknown')
        self.assertIsNone(self.c['arabic'])
        self.assertIsNone(self.c['cross_collection_counterpart'])
        self.assertEqual(self.c['editorial_status']['publication'],'NOT_AUTHORIZED')
        self.assertEqual(self.c['editorial_status']['independent_final_adapter_QC'],'PENDING')
        self.assertEqual(self.c['editorial_status']['global_overlap_and_live_reconciliation'],'NOT_CHECKED')
        self.assertIn('not',self.c['target_characterization'])
        self.assertEqual(sha((HERE/'source-display-map.json').read_bytes()),self.c['source_and_display_map']['sha256'])

    def test_08_fixture_is_single_record_and_no_note_commentary_in_visible_fields(self):
        f=(HERE/'reader'/'private-reader-fixture.html').read_text(encoding='utf-8')
        self.assertIn('type="application/json"',f)
        self.assertIn('white-space:pre-wrap',f)
        self.assertIn('document.getElementById(\'hadith-text\').textContent=display',f)
        self.assertIn('document.body.dataset.fixtureStatus=\'pass\'',f)
        self.assertNotIn('Речь идёт не только о хиджре',f)
        self.assertNotIn('Поводом для этого высказывания Пророка',f)
        self.assertNotIn('Это значит, что человек, сделавший',f)
        self.assertIn('No commentary or Arabic reading displayed',f)
        self.assertIn('Private test fixture',f)

if __name__ == '__main__':
    unittest.main(verbosity=2)
