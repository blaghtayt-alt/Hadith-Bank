"""Optional real Chromium smoke test; uses Playwright, no network, no repository.
Usage: python tests/test_reader_browser.py
Original capture is never fetched. Reads only the frozen self-contained private HTML fixture.
"""
import hashlib,json
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent.parent
HTML=(ROOT/'reader'/'private-reader-fixture.html').read_text(encoding='utf-8')
c=json.loads((ROOT/'candidate.json').read_bytes())
assert 'type="application/json"' in HTML

def main():
 output={'test_run':'actual offline Chromium render (page.set_content, no network)',
         'fixture_file':'reader/private-reader-fixture.html',
         'fixture_sha256':hashlib.sha256(HTML.encode()).hexdigest(),
         'script_execution':'pending','tests':[], 'publication':False}
 with sync_playwright() as playwright:
  browser=playwright.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  try:
   page=browser.new_page(viewport={'width':940,'height':700})
   errors=[];page.on('pageerror',lambda exc:errors.append(str(exc)))
   page.set_content(HTML,wait_until='load',timeout=15000)
   actual=page.locator('#hadith-text').text_content()
   checks={
    'source-derived rendering, exact foreign Hadith body':actual==c['display']['foreign_hadith_text'],
    'fixture adapter guards passed':page.locator('body').get_attribute('data-fixture-status')=='pass',
    'no JavaScript exceptions':errors==[],
    'preserved real single line break':actual.count('\n')==1 and '\\n' not in actual,
    'all 3 note markers absent from rendered Hadith':all(f'[{i}]' not in actual for i in (1,2,3)),
    'correct source/project visible outside narration':page.locator('#source-chain').text_content()==c['source_identity']['source_path'],
    'separate collection-level attribution':page.locator('#attribution').text_content()==c['source_metadata_not_hadith_text']['translator_provenance'],
    'target ID matches candidate':page.locator('#record-id').text_content()==c['stable_existing_bank_record_id'],
    'line breaks rendered via CSS':page.locator('#hadith-text').evaluate('(e) => getComputedStyle(e).whiteSpace')=='pre-wrap',
    'no inserted Arabic reading or explanatory commentary in rendered body':actual.startswith('Сообщается от ') and 'Речь идёт не только о хиджре' not in actual and '﴿' not in actual,
    'private fixture label visible':page.locator('.private').is_visible(),
    'no optional separate notes/commentary UI':page.locator('aside.metadata').count()==1 and page.locator('section.comment').count()==0
   }
   for key,val in checks.items():
    assert val,key
    output['tests'].append({'name':key,'status':'PASS'})
   output['script_execution']='PASS'
   # Intentional mutation 1: a stored raw character is changed but immutable source map isn't.
   altered=HTML.replace('Сообщается от ‘Умара', 'Сообщается за ‘Умара',1)
   assert altered!=HTML
   q=browser.new_page();qerrs=[];q.on('pageerror',lambda exc:qerrs.append(str(exc)))
   q.set_content(altered,wait_until='load',timeout=15000)
   assert q.locator('body').get_attribute('data-fixture-status')!='pass'
   assert any('raw span mismatch' in e for e in qerrs)
   assert q.locator('#hadith-text').text_content()==''
   output['tests'].append({'name':'fail-closed on mutated raw API field','status':'PASS'})
   q.close()
   # Intentional mutation 2: displayed words edited without corresponding source-map operation.
   altered=HTML.replace('"foreign_hadith_text":"Сообщается от', '"foreign_hadith_text":"Изменено: Сообщается от',1)
   assert altered!=HTML
   q=browser.new_page();qerrs=[];q.on('pageerror',lambda exc:qerrs.append(str(exc)))
   q.set_content(altered,wait_until='load',timeout=15000)
   assert q.locator('body').get_attribute('data-fixture-status')!='pass'
   assert any('result mismatch' in e for e in qerrs)
   assert q.locator('#hadith-text').text_content()==''
   output['tests'].append({'name':'fail-closed on unauthorized projected text change','status':'PASS'})
   q.close()
  finally:browser.close()
 output['total_pass']=len(output['tests']);output['total_fail']=0
 (ROOT/'tests'/'browser-smoke-results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(output,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
