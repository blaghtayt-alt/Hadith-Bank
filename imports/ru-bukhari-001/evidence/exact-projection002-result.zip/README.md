# RU-BUKHARI-001-HADITH-ONLY-PROJECTION-002 — private producer handoff

**Scope:** exactly one Russian Bukhari provider entry 1. This is a display/data projection, not a new translation, semantic re-review of entries 1–3, duplicate lookup, canonical Arabic match, repository patch, release, or certification. The earlier independent 1–3 and separate 67-case reviews remain closed. No new source acquisition, GitHub change, worker, or publication occurred.

## Frozen result

- Candidate ID: `ru-bukhari-001-foreign-hadith-only-p002`
- **Existing same-provider target ID**: `fawaz:df57907be352:bukhari:1` — stable target identity, not a new global narration identity.
- **Producer projection judgment**: `READY_FOR_EXACT_FINAL_INDEPENDENT_ADAPTER_QC (PRIVATE)`. In this one-record display boundary there is no unseparated source word or narration boundary requiring a new producer HOLD. This does not lift historical holds or replace independent QC.
- Provider path: `Fawaz Ahmed Hadith API → Isnad.link (Daura)`. Translators: collection-level human attribution to Abdullah Nirsha and the Daura editorial team; no per-entry translator invented; AI assistance status remains **unknown**, not false.
- Russian chain begins at Umar. The captured Arabic source has earlier transmitters; no additions or harmonization were made. Arabic reading, commentary, front matter and canonical counterpart are not in the candidate's foreign-Hadith display.

## Hashes (SHA-256)

| Evidence | UTF-8 size | SHA-256 |
|---|---:|---|
| exact API `text` field, untouched (one literal backslash-n; three note markers) | 776 B | `135937267729f06952b5ff3e42896daf0fdc7ec784cbf69dfd1673357ef2b86a` |
| exact Russian Hadith-only display, one real LF, markers excluded | 766 B | `1b36b7d0a1d29b0bc47701568e76ab5f110cd79c14f205cca99593084a73a3b4` |
| original captured `isnad-1.html` (complete, including original notes) | 25,988 B | `e471a93e4b173291863a0d8eb4589bf99dd16bbc0470b831babfafa7e800be00` |
| original pinned source packet (complete original 23-payload manifest) | 63,218 B | `56054af50afb4a144ebbb8f6245afa51aa05a4c98418e8c65553d29a6b0cf250` |
| source/display span ledger JSON file | 14944 B | `30c51f576fdfcaccda431cccda9a27cac47079894e54fce4f9ad7ce6249dd237` |

**Important limitation:** upstream full API response body is not supplied in the embedded packet. The previously recorded body hash `8120582acfcf6b860b336c1aba7ffa8f79a108066f4556e7d482f40923c0bbd5` is an *unverified upstream-body metadata claim*; the exact locally supplied `/0/text` field is independently hashed and verified against the pinned source row.

## Exact reversible source-to-display changes

`source-display-map.json` contains all nine contiguous source→display segments, with half-open Unicode codepoint and UTF-8 byte positions, exact `before`/`after` strings and SHA-256 fingerprints. Unchanged copied spans are included, so concatenating all `before` strings restores the entire raw field without loss.

| Change | Source CP offsets [start,end) | Source UTF-8 byte offsets | Display CP offset | Literal change |
|---|---|---|---|---|
| paragraph break | [99,101) | [178,180) | 99 | 2 literal chars `\\n` → real U+000A newline (original source HTML has two `<p>` elements) |
| archived note reference [1] | [303,306) | [544,547) | 302 | exact `[1]` → empty display span; source and archived note retained |
| archived note reference [2] | [379,382) | [680,683) | 375 | exact `[2]` → empty display span; source and archived note retained |
| archived note reference [3] | [432,435) | [771,774) | 425 | exact `[3]` → empty display span; source and archived note retained |

No other words, characters, punctuation, chain, or source reading were changed. The captured website adds a printed `1 —` before the first paragraph and a final `.` after the closing quote in the second paragraph; neither appears in the raw API field and neither was inserted into its display. The page's initial chapter introduction and Qur'an quotation are not narration content in this projection.

## Exact HTML boundaries

All coordinates are zero-based UTF-8 byte positions in the **unmodified** captured `evidence/isnad-1.html`, with end-exclusive ranges:

- `main.reader .parallel-reader__column--ru article.text-content > p:nth-of-type(5)` → Russian Hadith-bearing substring bytes **[8148,8326)**. HTML paragraph content after printed prefix equals API text before literal escaped newline, byte-for-byte.
- `main.reader .parallel-reader__column--ru article.text-content > p:nth-of-type(6)` → Russian Hadith-bearing substring bytes **[8333,8929)**. HTML paragraph without its website-only final period equals API text after literal escaped newline, byte-for-byte.

The three excluded marker occurrences are independently anchored to source-page commentary text under the exact heading `Комментарии А. Ниршы`, not to the Prophetic narration. Commentary paragraphs remain byte-for-byte in the archived HTML and the original packet; they have **no separate displayed note reading** or transcription in this adapter.

- Note **[1]**: exact archived HTML note text bytes **[11871,12318)**, SHA-256 `1794c7b537ef23f21a2516f2829b32ca9ece6a55716b43c1173c7ad5b6544a34`, begins with marker at [11871,11874); independently tied to narration marker by `source-display-map.json`.
- Note **[2]**: exact archived HTML note text bytes **[12325,14029)**, SHA-256 `103e86bb4e074ecd8513d403e0dfcee48be45927ecfb08412fcd10d1b1607c54`, begins with marker at [12325,12328); independently tied to narration marker by `source-display-map.json`.
- Note **[3]**: exact archived HTML note text bytes **[14036,14489)**, SHA-256 `96e527a812f1eeca7f957c4f927d21a5f2b84730e9608c6823368b3fe5a5d5ac`, begins with marker at [14036,14039); independently tied to narration marker by `source-display-map.json`.

## Tests and fixture

- `tests/test_projection.py`: **8/8 PASS**, exact original packet manifest and source bytes; raw field, note anchors, adjacent text, UTF-8/Unicode offset map and reconstruction, identity and release-scope checks.
- `reader/private-reader-fixture.html`: self-contained offline private reader/data fixture. It replays the entire span ledger against the raw API field, fails closed on a mismatched span, renders by `textContent` with actual line breaks and keeps source/provenance separate.
- `tests/test_reader_browser.py`: **14/14 PASS** in actual headless Chromium using `page.set_content` (offline; no network). Includes display parity, rendered newline and all three note omissions; two intentional corruptions prove fail-closed behavior. Reports are in `tests/python-check-results.txt` and `tests/browser-smoke-results.json`.

## Remaining gates — kept distinct from this producer work

1. **Exact final adapter reviewer** of the frozen candidate/map and source bindings is pending; producer tests are not independent approval.
2. The old **entry 1 source/QC HOLD** remains recorded as history. Its concrete *presentation* concern is addressed by this private projection, but no unilateral release gate is cleared.
3. Same-provider Bank gap is from a pinned older audit; global current-main/live overlap, version identity and integration mapping are **not checked**.
4. Per-entry translator and AI-process certainty remain unresolved despite collection-level human attribution. Site commentary is attributable to A. Nirsha separately from narration.
5. Canonical narration equivalence, Arabic linking, release ownership, publication and deployment are **not authorized/established**.

No source or record changes are made beyond the private candidate and its display projection. No editorial `(OCR wasn’t clear)` placeholder was inserted because no source narration word or boundary is uncertain in this exact scoped projection. Entry 4 from the captured page and entries 2–3 are never adopted or reviewed here.
