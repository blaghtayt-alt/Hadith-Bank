# Russian Bukhari 1 — independent final-adapter projection QC

Task: `RU-BUKHARI-001-PROJECTION002-INDEPENDENT-FINAL-ADAPTER-QC-001`  
Scope: **ONE private entry1 adapter**, no new source-language/meaning/credit review, no entries2/3/67 changes.

## Final disposition

**PASS — frozen source-to-display field mapping and HTML boundaries.**  
**HOLD — actual production reader/export, current global overlap, variant/canonical identity and release.**  
One private-fixture integrity limitation documented without modifying any producer/source code.

## Hash-verified inputs

| Input | Bytes | SHA-256 | Independent outcome |
|---|---:|---|---|
| Outer wrapper | 99,860 | `c1ccf02ae63a8e9b5c71ff38824fce3ff40937e61f68ad920f876a44978a8340` | CRC + 3 manifest payload hashes PASS |
| Producer result | 98,033 | `dea17674a7e2ff774be4b8cb75adf5c1dabe10d4a56409b9d3cbfbfedb2a6c19` | CRC + 12 manifest payload hashes PASS |
| Embedded original packet | 63,218 | `56054af50afb4a144ebbb8f6245afa51aa05a4c98418e8c65553d29a6b0cf250` | CRC + 23 manifest payload hashes, 7 submanifest entries PASS |
| Exact API Russian field | 776 | `135937267729f06952b5ff3e42896daf0fdc7ec784cbf69dfd1673357ef2b86a` | Exact pinned Fawaz row PASS |
| Exact private display field | 766 | `1b36b7d0a1d29b0bc47701568e76ab5f110cd79c14f205cca99593084a73a3b4` | Exact independent reconstruction PASS |

The complete upstream API response body is *not supplied*. Its historical SHA-256 `8120582acfcf6b860b336c1aba7ffa8f79a108066f4556e7d482f40923c0bbd5` remains metadata-only, not independently verified.

## Complete reversible mapping — precisely four changes

Original has **436 Unicode codepoints / 776 UTF-8 bytes**. Display has **426 codepoints / 766 bytes**. All nine contiguous ledger segments were checked for Unicode indices, UTF-8 byte coordinates and before/after hashes, then both directions were reconstructed exactly.

| Source CP [start,end) | Source UTF-8 bytes | Operation | Source literal | Display literal |
|---|---|---|---|---|
| [99,101) | [178,180) | Change 2 | two literal characters `\n` | single U+000A line break |
| [303,306) | [544,547) | Change 4 | `[1]` | omitted from display, retained in archive |
| [379,382) | [680,683) | Change 6 | `[2]` | omitted from display, retained in archive |
| [432,435) | [771,774) | Change 8 | `[3]` | omitted from display, retained in archive |

The other five span entries are byte-exact copies. No narration words, numbers, chain wording, quotation marks, other punctuation or section wording changed. The display ends at the original API quotation mark `»`; the saved Isnad site has an additional website-only full stop, **not added**. The website's printed `1 —` appears only as source metadata, not inserted into the narration.

## Source paragraph and commentary partition

The archived `isnad-1.html` is 25,988 bytes, SHA-256 `e471a93e4b173291863a0d8eb4589bf99dd16bbc0470b831babfafa7e800be00`, byte-identical to its inner source packet copy. The first Russian narration paragraph's Hadith-only source bytes are **[8148,8326)**; the second paragraph's API-equivalent bytes (omitting site-only period) are **[8333,8929)**. Both were parsed from actual HTML selectors and matched against independently pinned Fawaz data, not accepted merely from precomputed positions. The chapter title is metadata; chapter introduction/Qur'an, Arabic column, and editor conclusions are excluded.

All three notes are independently under the exact heading `Комментарии А. Ниршы`, separate from the Prophetic narration. Archived note text SHA-256: `[1]` `1794c7b537ef23f21a2516f2829b32ca9ece6a55716b43c1173c7ad5b6544a34`; `[2]` `103e86bb4e074ecd8513d403e0dfcee48be45927ecfb08412fcd10d1b1607c54`; `[3]` `96e527a812f1eeca7f957c4f927d21a5f2b84730e9608c6823368b3fe5a5d5ac`. Nothing was retranscribed or reclassified as Hadith.

## Executed independent tests

- Static independent verifier: **15 PASS groups**, checking nested ZIP manifests, exact raw row/HTML/ledger/metadata, full reconstruction; **9 independently corrupted cases correctly rejected**.
- Actual offline Chromium (Playwright, no network): desktop **1440×900**, mobile **390×844**, narrow mobile **320×568** all render the exact 766-B body with one real line break, no marker or commentary leakage, no JavaScript exception and no horizontal overflow. Browser text selection agrees with the display, and source/attribution remain outside it.
- Browser-derived JSON data serialization preserves exact raw and display strings (**a local probe, not a real product export**).
- Five isolated browser mutations fail closed: wrong raw source, wrong display, corrupt ledger, added Arabic, wrong target ID.
- **Unapplied private-fixture issue RU1-QC-ADAPTER-001 (medium)**: Coordinated replacement `Сообщается от ‘Умара` → `Сообщается из ‘Умара` simultaneously in the inline source, display and span ledger **still produces a fixture PASS** despite mismatched declared hashes. The fixture guards its own consistency but does not enforce externally anchored digests at runtime. This is not a failure of the independently verified frozen artifact; do not reuse fixture status as a substitute for pinned hash validation.
- **Unapplied coverage issue RU1-QC-ADAPTER-002**: No actual production Bank export or copy handler or integrated reader code was supplied. Consequently production export/print/copy and real integration remain **HOLD / unverified**, despite the successful private rendering checks.

## Gate separation and unchanged history

**PASS:** exact source/display mapping, archival boundaries, stable existing same-provider target `fawaz:df57907be352:bukhari:1`, independently rendered fixture.  
**HOLD:** actual production copy/export/integration, live global overlap and duplicate reconciliation, cross-collection/Arabic canonical equivalence, historical entry1 release hold and publication.  
**Unchanged provenance limits:** collection-level Abdullah Nirsha/Daura human attribution; exact individual translator unknown; AI-process status unknown. The owner’s separately established Human display/integration authority was not questioned or reopened and no new blanket credit/permission gate is invented.  
**Closed previous reviews:** source words/meaning/style, entries2/3 and entry67; none rerun.

All checks were offline and non-publishing. Source HTML/API/notes, shared data, GitHub and user files were not modified. No new workers were created. The companion JSON includes per-gate PASS/HOLD, full output text fingerprints, exact reversible field mapping and precise unapplied issues.
