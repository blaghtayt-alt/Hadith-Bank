# Offline independent QC reproducibility

This result package contains exact-input-wrapper.zip byte-for-byte. The standalone original source, producer outputs, and original notes are nested inside it. No web access is needed.

1. Unzip this reviewer ZIP into an isolated working directory.
2. The original wrapper is input/exact-input-wrapper.zip (SHA c1ccf02ae63a8e9b5c71ff38824fce3ff40937e61f68ad920f876a44978a8340).
3. Run `unzip -p input/exact-input-wrapper.zip exact-producer-result.zip > producer.zip`.
4. Run `mkdir -p producer && unzip -q producer.zip -d producer`. This creates `producer/` beside the reviewer scripts.
5. Run `python independent_checks.py` (requires beautifulsoup4; reads only input/exact-input-wrapper.zip).
6. Run `python independent_browser_checks.py` (requires Playwright Python and /usr/bin/chromium; uses producer/reader/private-reader-fixture.html, offline). It regenerates PNG screenshots and evidence JSON in the same directory.

All Python scripts are new reviewer-only tests and are not source or repository modifications.
The browser data serialization probe is NOT a production export handler; no production export code was supplied.
Output manifest hashes apply to the *frozen reviewer ZIP payloads*; rerunning tests may regenerate screenshots or receipts with different metadata.
