#!/usr/bin/env python3
"""Offline independent fixed-input verification; reads original/producer files, no network/writes to sources."""
import json, hashlib, zipfile, io, pathlib, re, sys, copy
from bs4 import BeautifulSoup
W=pathlib.Path(__file__).resolve().parent
WRAPPER=W/'input/exact-input-wrapper.zip'
EXPECTED_W='c1ccf02ae63a8e9b5c71ff38824fce3ff40937e61f68ad920f876a44978a8340'
EXPECTED_P='dea17674a7e2ff774be4b8cb75adf5c1dabe10d4a56409b9d3cbfbfedb2a6c19'
EXPECTED_RAW='135937267729f06952b5ff3e42896daf0fdc7ec784cbf69dfd1673357ef2b86a'
EXPECTED_DISPLAY='1b36b7d0a1d29b0bc47701568e76ab5f110cd79c14f205cca99593084a73a3b4'
TARGET='fawaz:df57907be352:bukhari:1'
H=lambda b: hashlib.sha256(b).hexdigest()
readj=lambda p: json.loads(pathlib.Path(p).read_text(encoding='utf-8'))
passed=[]
def check(n,assert_fn,detail=None):
 try: assert_fn(); passed.append({'id':n,'status':'PASS',**({'detail':detail} if detail else {})})
 except Exception as exc: print('FAIL',n,repr(exc),file=sys.stderr);raise

def verify_archive(raw, sha, manifest_name='MANIFEST.json', expected_count=None, manifest_style='list'):
 assert H(raw)==sha
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  assert z.testzip() is None
  names=z.namelist(); assert len(names)==len(set(names)), 'duplicate paths'
  assert not any(n.startswith('/') or '..' in pathlib.PurePosixPath(n).parts for n in names)
  manifest=json.loads(z.read(manifest_name))
  if manifest_style=='list':
   entries={r['path']:r for r in manifest['payloads']}
  else: entries=manifest
  assert len(entries)==(expected_count or len(entries))
  assert set(names)==set(entries)|{manifest_name}
  for k,entry in entries.items():
   b=z.read(k)
   assert entry['bytes']==len(b),(k,'size')
   assert entry['sha256']==H(b),(k,'hash')
  return {n:z.read(n) for n in names},list(entries)

def source_projection_verify(c,m, raw, source_row, original_html):
 # This intentionally pins externally supplied evidence, not self-consistent candidate claims.
 assert c['stable_existing_bank_record_id']==TARGET==m['stable_target_record_id']
 assert c['candidate_id']=='ru-bukhari-001-foreign-hadith-only-p002'
 assert c['provider_entry_number']==1 and c['provider_edition']=='rus-bukhari'
 assert c['provider_revision']=='df57907be35291c91ad6a6691180e22ca9920784'
 assert c['arabic'] is None and c['cross_collection_counterpart'] is None
 assert c['source']['raw_api_text_exact']==source_row['text']==raw.decode('utf8')
 assert H(raw)==EXPECTED_RAW and H(c['source']['raw_api_text_exact'].encode('utf8'))==EXPECTED_RAW
 assert m['raw_field_sha256']==c['source']['raw_api_text_sha256']==EXPECTED_RAW
 assert len(raw)==c['source']['raw_api_text_utf8_bytes']==m['raw_field_utf8_bytes']==776
 assert c['source']['raw_has_actual_LF'] is False and c['source']['raw_has_literal_backslash_n'] is True
 assert raw.decode().count(r'\n')==1 and raw.decode().count('\n')==0
 assert source_row['hadithnumber']==source_row['arabicnumber']==1
 assert source_row['reference']=={'book':1,'hadith':1}
 assert c['source_metadata_not_hadith_text']['provider_reference']==source_row['reference']
 assert H(original_html)==m['html_source_sha256']==c['source']['source_capture_html_sha256']
 assert c['source']['source_text_hash_claim_from_pinned_gap']==EXPECTED_RAW
 source=raw.decode('utf8'); segments=m['segments']; assert len(segments)==9
 out=''; before=''; sc=dc=sb=db=0
 for i,s in enumerate(segments,1):
  assert s['sequence']==i
  a=s['source_codepoints']; bb=s['source_utf8_bytes']; d=s['display_codepoints']; ee=s['display_utf8_bytes']
  assert a['start']==sc and bb['start']==sb and d['start']==dc and ee['start']==db
  assert a['end_exclusive']<=len(source) and a['end_exclusive']>=sc
  txt=source[sc:a['end_exclusive']]
  assert txt==s['before'] # independent exact raw slice
  assert raw[sb:bb['end_exclusive']]==txt.encode('utf8')
  assert H(txt.encode('utf8'))==s['before_utf8_sha256']
  assert H(s['after'].encode('utf8'))==s['after_utf8_sha256']
  if s['action']=='copy': assert s['before']==s['after']
  elif s['action']=='literal_escape_to_real_line_break':
   assert i==2 and s['before']==r'\n' and s['after']=='\n'
  elif s['action']=='exclude_source_verified_commentary_marker':
   assert i in (4,6,8) and s['before']==f'[{i//2-1}]' and s['after']==''
   assert s['archive_commentary_note_id']==str(i//2-1)
  else: raise AssertionError('unexpected operation '+s['action'])
  before+=s['before'];out+=s['after']
  sc=a['end_exclusive'];dc=d['end_exclusive'];sb=bb['end_exclusive'];db=ee['end_exclusive']
  assert len(out)==dc and len(out.encode('utf8'))==db
 assert before==source and out==c['display']['foreign_hadith_text']
 assert [s['sequence'] for s in segments if s['before']!=s['after']]==[2,4,6,8]==m['changed_segment_numbers']
 assert len(out)==m['display_codepoints']==426 and len(source)==m['raw_field_codepoints']==436
 assert len(out.encode('utf8'))==c['display']['utf8_bytes']==m['display_utf8_bytes']==766
 assert H(out.encode('utf8'))==c['display']['foreign_hadith_text_sha256']==m['display_text_sha256']==EXPECTED_DISPLAY
 assert out == source.replace(r'\n','\n',1).replace('[1]','',1).replace('[2]','',1).replace('[3]','',1)
 assert out.count('\n')==1 and out.count(r'\n')==0 and all(f'[{x}]' not in out for x in (1,2,3))
 assert c['display']['line_breaks']==1
 assert not out.endswith('.') and out.endswith('»')
 # HTML nodes, independent DOM selection rather than relying only on ledger locations.
 bs=BeautifulSoup(original_html,'html.parser')
 binds=m['source_html_narration_boundaries']
 assert len(binds)==2
 p1,p2=[bs.select_one(b['selector']) for b in binds]
 assert p1 is not None and p2 is not None
 t1=p1.get_text();t2=p2.get_text()
 assert t1.startswith('1 — ') and t2.endswith('».')
 assert t1[len('1 — '):]==source[:99]
 assert t2[:-1]==source[101:]
 assert source[99:101]==r'\n'
 # Document-level heading and exact byte spans, including non-narration exclusions.
 title=m['page_heading_metadata_only'];q=title['html_text_full_utf8']; assert original_html[q['byte_start']:q['byte_end_exclusive']].decode('utf8')==title['text']
 for v,text in zip(binds,[t1,t2]):
  sp=v['html_text_full_utf8']; b=original_html[sp['byte_start']:sp['byte_end_exclusive']]
  assert b.decode('utf8')==text and H(b)==sp['utf8_sha256'] and len(b)==sp['utf8_bytes']
  sub=v['html_russian_hadith_only_utf8']; subb=original_html[sub['byte_start']:sub['byte_end_exclusive']]
  assert subb== (source[:99] if v is binds[0] else source[101:]).encode('utf8')
 # Commentary 3 labels live only in separately attributed source section, and ledger marker offsets accurate.
 heading=bs.find(string=lambda x: x and 'Комментарии А. Ниршы' in x)
 assert heading is not None
 section=heading.find_parent('section',class_='comment')
 assert section is not None
 spans=m['archival_commentary_anchors'];assert len(spans)==3
 for x,n in zip(spans,[1,2,3]):
  assert x['id']==str(n) and x['heading_original']=='Комментарии А. Ниршы'
  node=bs.select_one(x['source_html_selector'])
  assert node is not None and node.find_parent('section',class_='comment')==section
  note=node.get_text(); assert note.startswith(f'[{n}]')
  sp=x['html_text_span_utf8']; snippet=original_html[sp['byte_start']:sp['byte_end_exclusive']]
  assert note==snippet.decode('utf8') and H(snippet)==sp['utf8_sha256'] and len(snippet)==sp['utf8_bytes']
  marker=x['html_marker_span_utf8']; assert original_html[marker['byte_start']:marker['byte_end_exclusive']]==f'[{n}]'.encode('utf8')
  seg=segments[2*n+1]
  assert seg['source_marker_site_html_byte_start']>=binds[1]['html_text_full_utf8']['byte_start']
  assert original_html[seg['source_marker_site_html_byte_start']:seg['source_marker_site_html_byte_end_exclusive']]==f'[{n}]'.encode('utf8')
 assert c['source_archival_only']['notes_not_readings_or_standalone_display_targets']
 assert c['source_archival_only']['notes_archived_unmodified_in_original_HTML']
 assert c['editorial_status']['independent_final_adapter_QC']=='PENDING'
 assert c['editorial_status']['global_overlap_and_live_reconciliation']=='NOT_CHECKED'
 assert c['editorial_status']['cross_collection_identity']=='NOT_ESTABLISHED'
 assert c['editorial_status']['publication']=='NOT_AUTHORIZED'
 assert c['source_metadata_not_hadith_text']['ai_translation_status']=='unknown'
 assert c['source_metadata_not_hadith_text']['source_variant_chain_note'].startswith('Russian version starts with Umar')
 return {'source_codepoints':len(source),'display_codepoints':len(out), 'mapping_operations': [{'sequence':s['sequence'],'action':s['action'],'source_codepoints':s['source_codepoints'],'display_codepoints':s['display_codepoints'],'before':s['before'] if s['action']!='copy' else '[COPY_UNCHANGED]', 'after':s['after'] if s['action']!='copy' else '[COPY_UNCHANGED]'} for s in segments], 'paragraphs': [{'source_offset_utf8':(b['html_text_full_utf8']['byte_start'],b['html_text_full_utf8']['byte_end_exclusive'])} for b in binds],'archived_notes': [{'id':n['id'], 'sha256':n['note_text_sha256'],'bytes':n['note_text_utf8_bytes']} for n in spans]}

with zipfile.ZipFile(WRAPPER) as z: wrapperbytes=WRAPPER.read_bytes(); producerbytes=z.read('exact-producer-result.zip'); request=json.loads(z.read('REQUEST.json'))
check('A01.wrapper_exact_bytes_sha256',lambda: (lambda a: (a==99860 and H(wrapperbytes)==EXPECTED_W) or (_ for _ in ()).throw(AssertionError()))(len(wrapperbytes)))
wr,wp=verify_archive(wrapperbytes,EXPECTED_W,expected_count=3)
check('A02.wrapper_manifest_3_payloads_CRC_all_hashes',lambda: (len(wp)==3 and len(wr)==4) or (_ for _ in ()).throw(AssertionError()))
check('A03.request_stable_scope',lambda: (request['stableTarget']==TARGET and request['resultSHA256']==EXPECTED_P) or (_ for _ in ()).throw(AssertionError()))
pr,pp=verify_archive(producerbytes,EXPECTED_P,expected_count=12,manifest_style='object')
check('A04.producer_12_payloads_CRC_all_hashes',lambda: (len(producerbytes)==98033 and len(pp)==12) or (_ for _ in ()).throw(AssertionError()))
origbytes=pr['evidence/original-pinned-source-packet.zip']
or_,op=verify_archive(origbytes,'56054af50afb4a144ebbb8f6245afa51aa05a4c98418e8c65553d29a6b0cf250',manifest_name='manifest.json',expected_count=23,manifest_style='object')
check('A05.original_23_payloads_CRC_all_hashes',lambda: (len(origbytes)==63218 and len(op)==23) or (_ for _ in ()).throw(AssertionError()))
check('A06.original_inner_seven_item_manifest',lambda: (lambda a,b: all(a[k]['bytes']==len(or_['existing-packet/'+k]) and a[k]['sha256']==H(or_['existing-packet/'+k]) for k in a) and len(a)==7)(json.loads(or_['existing-packet/manifest.json']),or_))
check('A07_original_html_equal_embedded_copy',lambda: (pr['evidence/isnad-1.html']==or_['existing-packet/isnad-1.html']) or (_ for _ in ()).throw(AssertionError()))
c=json.loads(pr['candidate.json']);m=json.loads(pr['source-display-map.json']); rows=json.loads(or_['existing-packet/exact-russian-source-rows.json']); gap=json.loads(or_['existing-packet/exact-gap-targets.json'])
raw=pr['evidence/api-entry1-field.raw.utf8'];html=pr['evidence/isnad-1.html']; r=rows[0]
check('B01_pinned_Fawaz_row_equals_raw_field',lambda: (raw.decode('utf8')==r['text']==c['source']['raw_api_text_exact'] and len(raw)==776 and H(raw)==EXPECTED_RAW) or (_ for _ in ()).throw(AssertionError()))
check('B02_stable_provider_target_gap_and_revision',lambda: (gap[0]['existing_bank_id']==TARGET and gap[0]['source_text_sha256']==EXPECTED_RAW and gap[0]['revision']==c['provider_revision'] and gap[0]['json_pointer']=='/hadiths/0') or (_ for _ in ()).throw(AssertionError()))
res=source_projection_verify(c,m,raw,r,html)
check('B03_complete_9_span_byte_cp_ledger_reversibility',lambda: True)
check('B04_only_LF_conversion_and_three_archived_note_markers',lambda: True)
check('B05_original_HTML_two_paragraphs_heading_punctuation',lambda: True)
check('B06_exact_three_commentary_anchors_separate',lambda: True)
check('B07_metadata_identity_provenance_uncertainty_and_holds',lambda: True)
# Active negative tests against independent immutable pin and exact policy.
negative=[]
def reject(name, fn):
 failed=False;why=''
 try: fn()
 except (AssertionError,IndexError,KeyError,ValueError) as exc: failed=True;why=str(exc)
 assert failed,name+' accepted corruption unexpectedly';negative.append({'id':name,'status':'PASS_REJECTED','error':why[:240]})
reject('N1_source_word_mutation',lambda:source_projection_verify({**c,'source':{**c['source'],'raw_api_text_exact':c['source']['raw_api_text_exact'].replace('Сообщается от','Сообщается из',1)}},m,raw,r,html))
reject('N2_unauthorized_display_word_mutation',lambda:source_projection_verify({**c,'display':{**c['display'],'foreign_hadith_text':c['display']['foreign_hadith_text'].replace('Поистине','Возможно',1)}},m,raw,r,html))
bad=copy.deepcopy(m);bad['segments'][3]['action']='copy'
reject('N3_commentary_marker_treated_as_body_copy',lambda:source_projection_verify(c,bad,raw,r,html))
bad=copy.deepcopy(m);bad['segments'][4]['before']=' ЗАМЕНА'+bad['segments'][4]['before']
reject('N4_untracked_span_insertion',lambda:source_projection_verify(c,bad,raw,r,html))
bad=copy.deepcopy(m);bad['segments'][5]['source_codepoints']['start']-=1
reject('N5_byte_cp_coordinate_misalignment',lambda:source_projection_verify(c,bad,raw,r,html))
bad=copy.deepcopy(m);bad['archival_commentary_anchors'][0]['html_text_span_utf8']['byte_start']+=1
reject('N6_misbound_archival_note_anchor',lambda:source_projection_verify(c,bad,raw,r,html))
reject('N7_unpinned_html_change',lambda:source_projection_verify(c,m,raw,r,html.replace('Комментарии А. Ниршы'.encode('utf8'),'Комментарии П. Ниршы'.encode('utf8'),1)))
reject('N8_bogus_target_new_identity',lambda:source_projection_verify({**c,'stable_existing_bank_record_id':'new:unapproved:1'},m,raw,r,html))
reject('N9_added_Arabic_or_counterpart',lambda:source_projection_verify({**c,'arabic':'unapproved Arabic'},m,raw,r,html))
check('C01_corruption_checks_9_expected_rejections',lambda: (len(negative)==9) or (_ for _ in ()).throw(AssertionError()))
reported={'scope':'one private final adapter for Russian Bukhari 1', 'wrapper_sha256':EXPECTED_W,'wrapper_bytes':len(wrapperbytes),'producer_sha256':EXPECTED_P,'producer_bytes':len(producerbytes),'original_packet_sha256':H(origbytes),'original_packet_bytes':len(origbytes),'raw_sha256':H(raw),'raw_bytes':len(raw),'display_sha256':H(c['display']['foreign_hadith_text'].encode('utf8')),'display_bytes':len(c['display']['foreign_hadith_text'].encode('utf8')),'checks':passed,'negative_checks':negative,'source_display_evidence':res,'archives':{'wrapper_payloads':len(wp),'producer_payloads':len(pp),'original_payloads':len(op),'original_inner_manifest_payloads':7}}
p=W/'independent_static_evidence.json';p.write_text(json.dumps(reported,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print('PASS',len(passed),'static tests;',len(negative),'negative corruptions rejected;',p)
