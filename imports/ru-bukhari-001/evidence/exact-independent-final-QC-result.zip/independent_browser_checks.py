#!/usr/bin/env python3
"""Independent offline Chromium test of supplied private fixture, not a production Bank reader test."""
from playwright.sync_api import sync_playwright
import hashlib, json, pathlib
W=pathlib.Path(__file__).resolve().parent
P=W/'producer'
H=lambda s:hashlib.sha256(s.encode('utf8')).hexdigest()
html=(P/'reader/private-reader-fixture.html').read_text(encoding='utf8')
c=json.loads((P/'candidate.json').read_text('utf8'))
ledger=json.loads((P/'source-display-map.json').read_text('utf8'))
raw=(P/'evidence/api-entry1-field.raw.utf8').read_text('utf8')
results={'environment':'local /usr/bin/chromium, Playwright Python, offline page.set_content, external resource requests aborted','fixture_hash':H(html),'devices':[], 'negative_checks':[], 'data_roundtrip':{}, 'unavailable_routes':[], 'console_warnings':[]}
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-background-networking'])
 try:
  for label,w,h in [('desktop_1440x900',1440,900),('mobile_390x844',390,844),('narrow_mobile_320x568',320,568)]:
   ctx=browser.new_context(viewport={'width':w,'height':h},is_mobile=label!='desktop_1440x900',has_touch=label!='desktop_1440x900',device_scale_factor=1)
   ctx.route('**/*',lambda route:route.abort())
   page=ctx.new_page()
   errors=[];network=[]
   page.on('pageerror',lambda error:errors.append(str(error)))
   page.on('request',lambda req:network.append(req.url))
   page.set_content(html,wait_until='load',timeout=20000)
   state=page.locator('body').get_attribute('data-fixture-status')
   text=page.locator('#hadith-text').text_content()
   meta=page.evaluate("""() => ({
    documentWidth:document.documentElement.scrollWidth,viewportWidth:innerWidth,
    bodyWidth:document.body.getBoundingClientRect().width,
    mainBox:{x:document.querySelector('main').getBoundingClientRect().x, width:document.querySelector('main').getBoundingClientRect().width},
    textBox:{x:document.querySelector('#hadith-text').getBoundingClientRect().x,width:document.querySelector('#hadith-text').getBoundingClientRect().width},
    whiteSpace:getComputedStyle(document.querySelector('#hadith-text')).whiteSpace,
    fixtureStatus:document.body.dataset.fixtureStatus,
    title:document.querySelector('h1').textContent,
    actualExportButtons:document.querySelectorAll('button,a[download],input[type=button]').length,
    exportFunctionsVisible: typeof window.exportHadith,
    contentType:document.querySelector('#candidate-data').getAttribute('type'),
    noParagraphChildMarkup:document.querySelector('#hadith-text').childElementCount===0,
    metadataOutsideNarration:document.querySelector('aside.metadata').contains(document.querySelector('#source-chain')),
    source:document.querySelector('#source-chain').textContent,
    translator:document.querySelector('#attribution').textContent,
    providerId:document.querySelector('#record-id').textContent,
    selection:(()=>{const r=document.createRange();r.selectNodeContents(document.querySelector('#hadith-text'));let sel=window.getSelection();sel.removeAllRanges();sel.addRange(r);return sel.toString()})(),
    runtimeCandidate: JSON.parse(document.querySelector('#candidate-data').textContent),
    runtimeMap:JSON.parse(document.querySelector('#span-map-data').textContent)
   })""")
   assert state=='pass' and errors==[], (label,errors,state)
   assert text==c['display']['foreign_hadith_text'] and text==meta['selection']
   assert H(text)=='1b36b7d0a1d29b0bc47701568e76ab5f110cd79c14f205cca99593084a73a3b4'
   assert text.count('\n')==1 and r'\n' not in text
   assert meta['whiteSpace']=='pre-wrap' and meta['noParagraphChildMarkup']
   assert meta['providerId']=='fawaz:df57907be352:bukhari:1'
   assert meta['source']==c['source_identity']['source_path']
   assert meta['translator']==c['source_metadata_not_hadith_text']['translator_provenance']
   assert meta['runtimeCandidate']==c and meta['runtimeMap']==ledger
   assert meta['metadataOutsideNarration'] and 'Комментарии' not in text and '[1]' not in text and '[2]' not in text and '[3]' not in text
   assert network==[]
   # Actual presentation and CSS line wrapping, not test of production renderer.
   page.evaluate('window.getSelection().removeAllRanges()')
   screenshot=W/f'private_fixture_{label}.png'
   page.screenshot(path=str(screenshot),full_page=True)
   results['devices'].append({'device':label,'render':'PASS','source_data':'PASS','selection_copy_probe':'PASS', 'browser_errors':errors,'network_attempts':network,'horizontal_overflow':meta['documentWidth']>meta['viewportWidth'],'document_width':meta['documentWidth'],'viewport_width':meta['viewportWidth'],'main_box':meta['mainBox'],'text_box':meta['textBox'],'actual_export_button_count':meta['actualExportButtons'],'direct_export_function_present':meta['exportFunctionsVisible']!='undefined','screenshot':screenshot.name,'screenshot_sha256':hashlib.sha256(screenshot.read_bytes()).hexdigest(),'screenshot_bytes':screenshot.stat().st_size})
   if label=='desktop_1440x900':
    # Browser data serialization and text selection only. No real export path provided.
    serialized=page.evaluate("""() => {const c=JSON.parse(document.querySelector('#candidate-data').textContent); return JSON.stringify({id:c.stable_existing_bank_record_id, lang:c.display.foreign_language,text:document.querySelector('#hadith-text').textContent,source:c.source.raw_api_text_exact})}""")
    roundtrip=json.loads(serialized)
    assert roundtrip['id']=='fawaz:df57907be352:bukhari:1'
    assert roundtrip['lang']=='ru' and roundtrip['text']==text and roundtrip['source']==raw
    results['data_roundtrip']={'name':'browser_derived_JSON_serialization_probe_NOT_production_export','status':'PASS','serialized_utf8_bytes':len(serialized.encode('utf8')),'sha256':H(serialized),'text_field_sha256':H(roundtrip['text']),'source_field_sha256':H(roundtrip['source'])}
   ctx.close()
  # Active browser corruption checks. Mutations confined to in-memory HTML strings.
  corruptions=[
   ('raw_narration_single_mutation',html.replace('"raw_api_text_exact":"Сообщается от ‘Умара','"raw_api_text_exact":"Сообщается из ‘Умара',1),'raw span mismatch'),
   ('display_narration_single_mutation',html.replace('"foreign_hadith_text":"Сообщается от ‘Умара','"foreign_hadith_text":"Сообщается из ‘Умара',1),'result mismatch'),
   ('ledger_copy_segment_mutation',html.replace('"before":"Сообщается от ‘Умара','"before":"Сообщается из ‘Умара',1),'raw span mismatch'),
   ('unapproved_new_reference_added',html.replace('"arabic":null','"arabic":"unapproved"',1),'scope expansion'),
   ('wrong_target_single_location',html.replace('"stable_existing_bank_record_id":"fawaz:df57907be352:bukhari:1"','"stable_existing_bank_record_id":"unapproved:1"',1),'wrong target'),
  ]
  for name,altered,fragment in corruptions:
   assert altered!=html
   q=browser.new_page()
   errors=[];q.on('pageerror',lambda ex:errors.append(str(ex)))
   q.set_content(altered,wait_until='load',timeout=15000)
   state=q.locator('body').get_attribute('data-fixture-status')
   passed=state!='pass' and q.locator('#hadith-text').text_content()=='' and any(fragment in e for e in errors)
   results['negative_checks'].append({'case':name,'expected':'FAIL_CLOSED','actual':'PASS_REJECTED' if passed else 'FAIL_OPEN','errors':errors,'body_status':state})
   assert passed,(name,state,errors)
   q.close()
  # Stronger coordinated corruption: candidate raw + display + ledger before+after all edited
  # without updating declared hash fingerprint fields. In private fixture, self-consistency alone is NOT an immutable anchor.
  exact='Сообщается от ‘Умара';bad='Сообщается из ‘Умара'
  assert html.count(exact)>=4
  altered=html.replace(exact,bad)
  q=browser.new_page()
  errors=[];q.on('pageerror',lambda ex:errors.append(str(ex)))
  q.set_content(altered,wait_until='load',timeout=15000)
  runtime_text=q.locator('#hadith-text').text_content()
  bypass=(q.locator('body').get_attribute('data-fixture-status')=='pass' and bad in runtime_text and H(runtime_text)!=c['display']['foreign_hadith_text_sha256'])
  results['negative_checks'].append({'case':'coordinated_raw_and_ledger_mutation_without_rehash','expected':'FAIL_CLOSED_IF_RUNTIME_TRUST_PINNED','actual':'GUARD_BYPASS_DEMONSTRATED' if bypass else 'REJECTED','error_count':len(errors),'fixture_status':q.locator('body').get_attribute('data-fixture-status'),'runtime_display_sha256':H(runtime_text),'declared_unchanged_sha256':c['display']['foreign_hadith_text_sha256'],'interpretation':'Self-consistency guard alone does not check declared pinned hashes; strict external independent QC catches this corruption. Non-production fixture limitation.'})
  assert bypass
  q.close()
  results['unavailable_routes']=['no actual production Bank reader/source records supplied','no copy button or production copy handler supplied','no export/download handler supplied','no desktop/mobile production reader integration path supplied','browser data round-trip is a local simulation, not proof of production exports']
 finally: browser.close()
assert all(x['render']=='PASS' for x in results['devices'])
assert all(x['actual']=='PASS_REJECTED' for x in results['negative_checks'] if x['case']!='coordinated_raw_and_ledger_mutation_without_rehash')
(W/'independent_browser_evidence.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'devices':[(v['device'],v['horizontal_overflow'],v['document_width'],v['viewport_width']) for v in results['devices']],'negative':[(x['case'],x['actual']) for x in results['negative_checks']],'unavailable':results['unavailable_routes']},indent=2))
