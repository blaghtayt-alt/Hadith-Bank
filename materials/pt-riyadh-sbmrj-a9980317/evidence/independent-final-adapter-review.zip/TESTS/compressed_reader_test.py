from playwright.sync_api import sync_playwright
import json,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
html=(p/'staging/reader-compressed/index.html').read_text(encoding='utf-8')
rows=json.loads((p/'private-fixture/materials/pt-riyadh-sbmrj-a9980317/records.json').read_text(encoding='utf8'))
receipt={'backend':'actual-code/scripts/build_reader.py','encoding':'gzip-base64','cases':[],'errors':[]}
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width,height in [(1280,900),(390,844)]:
  pg=b.new_page(viewport={'width':width,'height':height})
  pg.on('pageerror',lambda e:receipt['errors'].append(str(e)))
  pg.set_content(html,wait_until='domcontentloaded')
  pg.wait_for_function("document.getElementById('total-count').textContent === '2'",timeout=10000)
  pg.locator('#query').fill('Abu Barzah');pg.locator('#run-search').click()
  pg.wait_for_function("document.querySelectorAll('#results [data-occurrence-id]').length === 2",timeout=10000)
  ids=pg.locator('#results [data-occurrence-id]').evaluate_all('(els)=>els.map(e=>e.dataset.occurrenceId)')
  assert ids==[r['id'] for r in rows]
  assert pg.locator('#results').inner_text().count('Arabic: not supplied · English: not supplied')==2
  receipt['cases'].append({'viewport':[width,height],'ids':ids,'two_distinct_results':True,'without_Arabic_English':True,'no_horizontal_overflow':pg.evaluate('document.documentElement.scrollWidth <= innerWidth + 1')})
  pg.close()
 b.close()
assert not receipt['errors']
assert all(x['no_horizontal_overflow'] for x in receipt['cases'])
receipt['reader_html_bytes']=(p/'staging/reader-compressed/index.html').stat().st_size
receipt['reader_html_sha256']=hashlib.sha256((p/'staging/reader-compressed/index.html').read_bytes()).hexdigest()
receipt['status']='PASS'
(p/'independent_evidence/compressed-browser-tests.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(receipt,indent=2))
