#!/usr/bin/env python3
"""Finite real Chromium DOM/export tests on isolated generated build, using set_content since navigation is blocked by container browser policy."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import json, hashlib, re
from bs4 import BeautifulSoup
BASE=Path(__file__).resolve().parent
STAGE=BASE/'staging'
EVID=BASE/'independent_evidence'
SHOT=EVID/'screenshots';SHOT.mkdir(parents=True,exist_ok=True)
RAW=json.loads((BASE/'private-fixture/materials/pt-riyadh-sbmrj-a9980317/records.json').read_text())
STRE=[json.loads(s) for s in (BASE/'private-fixture/search/records.jsonl').read_text().splitlines()]
IDS=['pt_riyadh_sbmrj_0832','pt_riyadh_sbmrj_0833']
DATA={r['id']:r for r in RAW}
READER=(STAGE/'reader/index.html').read_text(encoding='utf8')
STATIC=list((STAGE/'static/hadith/pt/riyadh/sbmrj-samir-el-hayek-undated-a9980317').glob('*.html'))
CSS=(STAGE/'static/assets/discovery.css').read_text(encoding='utf8')
counts=[];fails=[];screens=[];cases=[];errors=[]

def check(label,yes,details=None):
    counts.append({'check':label,'pass':bool(yes),'details':details})
    if not yes:
      fails.append(label)
      raise AssertionError(f'FAIL {label}: {details}')
def hashb(b):return hashlib.sha256(b).hexdigest()
def dims(page):
    return page.evaluate('''() => ({viewport: innerWidth, docWidth: document.documentElement.scrollWidth, bodyWidth: document.body.scrollWidth, height: innerHeight, horizontalOverflow: document.documentElement.scrollWidth > innerWidth + 1, layoutViewportWidth: document.documentElement.clientWidth})''')
def screenshot(page,file):
    dest=SHOT/file;page.screenshot(path=str(dest),full_page=False,animations='disabled');screens.append({'file':dest.relative_to(EVID).as_posix(),'bytes':dest.stat().st_size,'sha256':hashb(dest.read_bytes())})

with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    version=browser.version
    for vp,width,height in [('desktop',1280,900),('mobile',390,844)]:
        context=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1,accept_downloads=True)
        page=context.new_page()
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.set_content(READER,wait_until='domcontentloaded')
        page.wait_for_function("document.querySelector('#total-count').textContent.trim() === '2'",timeout=10000)
        check(vp+' branded title',page.title()=='Hadith Bank · Reader')
        check(vp+' initial record count',page.locator('#total-count').inner_text()=='2')
        page.locator('#query').fill('Abu Barzah');page.locator('#run-search').click()
        page.wait_for_function("document.querySelectorAll('#results [data-occurrence-id]').length === 2",timeout=10000)
        result_ids=page.locator('#results [data-occurrence-id]').evaluate_all('(nodes) => nodes.map(node => node.dataset.occurrenceId)')
        check(vp+' distinct result cards',result_ids==IDS,result_ids)
        check(vp+' no false canonical in result labels',page.locator('#results').inner_text().count('Canonical reference not established')==2)
        check(vp+' correct no Arabic or English counterparts',page.locator('#results').inner_text().count('Arabic: not supplied · English: not supplied')==2)
        check(vp+' current human origin visible',page.locator('#results').inner_text().count('Human translation')==2)
        # In-page selected export via actual JS blob; test independently for two rows.
        for id in IDS:
            page.locator('#results [data-occurrence-id="'+id+'"] .record-select input').check()
        check(vp+' selection export controls enabled',page.locator('#download').is_enabled() and '(2)' in page.locator('#download').inner_text())
        with page.expect_download(timeout=15000) as download_event:page.locator('#download').click()
        download=download_event.value;target=EVID/('browser-export-'+vp+'.json');download.save_as(str(target))
        exported=json.loads(target.read_text(encoding='utf8'))
        check(vp+' export exact projected records',exported==STRE and [r['id'] for r in exported]==IDS)
        for i,r in enumerate(exported):
            check(vp+' export full exact body hash '+r['id'],hashb(r['text_translation'].encode('utf8'))==RAW[i]['extraction']['body_sha256'])
        case_export={'viewport':vp,'download_name':download.suggested_filename,'bytes':target.stat().st_size,'sha256':hashb(target.read_bytes()),'export_exact_search_rows':True}
        check(vp+' source filename',download.suggested_filename=='hadith-bank-selected-records.json')
        d=dims(page);check(vp+' search no horizontal overflow',not d['horizontalOverflow'],d)
        screenshot(page,'reader-search-'+vp+'.png')
        for id in IDS:
            anchor=page.locator('#results [data-occurrence-id="'+id+'"]')
            anchor.get_by_text('Open narration',exact=False).click()
            # Allow potential async workspace hydration.
            page.locator('#workspace-content .language-reading[data-language="pt"] p.narration').wait_for(state='attached',timeout=10000)
            container=page.locator('#workspace-content')
            body=container.locator('.language-reading[data-language="pt"] p.narration').text_content()
            check(vp+' '+id+' exact browser textContent incl spaces/newlines',body==DATA[id]['text']['translation'],{'actual':hashb(body.encode()),'expected':DATA[id]['extraction']['body_sha256']})
            check(vp+' '+id+' exactly Portuguese-only reading',container.locator('.language-reading').count()==1 and container.locator('.language-reading').get_attribute('data-language')=='pt')
            check(vp+' '+id+' foreign-only availability', 'Arabic · not yet available' in container.inner_text() and 'English · not yet available' in container.inner_text())
            check(vp+' '+id+' printed token not canonical', 'Collection number not supplied' in container.inner_text())
            check(vp+' '+id+' no false grouping', container.locator('article.record-card').count()==1 and container.locator('article.record-card').get_attribute('data-occurrence-id')==id)
            check(vp+' '+id+' correct source PDF URL label',any('materials/pt-riyadh-sbmrj-a9980317/source.pdf' in x for x in container.locator('a.source-original-download').evaluate_all('(nodes)=>nodes.map(a=>a.href)')))
            check(vp+' '+id+' historical unknown versus current human distinct', 'Human translation' in container.inner_text() and 'Preserved source-origin label' in container.text_content() and 'Unknown' in container.text_content())
            check(vp+' '+id+' metadata narrator and source distinct', 'Abu Barzah' in container.text_content() and 'Prof. Samir El Hayek' in container.text_content())
            d=dims(page);check(vp+' '+id+' workspace no horizontal overflow',not d['horizontalOverflow'],d)
            screenshot(page,'reader-'+id[-4:]+'-'+vp+'.png')
            cases.append({'viewport':vp,'id':id,'exact_body_sha256':hashb(body.encode()),'workspace_shown':True,'source_link_staged_only':True,'overflow':d['horizontalOverflow']})
            page.locator('#back-to-results').click()
            page.wait_for_function("document.querySelector('#discovery-results').hidden === false && document.querySelectorAll('#results [data-occurrence-id]').length===2")
        case_export['ids']=IDS
        cases.append({'viewport':vp,'browser_export':case_export})
        context.close()
    # Static pages, JavaScript OFF. Inline the exact builder CSS only for visual measurement; content unchanged.
    for vp,width,height in [('desktop',1280,900),('mobile',390,844)]:
        ctx=browser.new_context(viewport={'width':width,'height':height},java_script_enabled=False,device_scale_factor=1)
        for id in IDS:
            page=ctx.new_page()
            target=None
            for path in STATIC:
                if id in path.read_text(encoding='utf8'):
                    target=path;break
            check(vp+' '+id+' static file found',target is not None)
            page.set_content(target.read_text(encoding='utf8').replace('<link rel=stylesheet href=../../../../assets/discovery.css>','<style>'+CSS+'</style>'),wait_until='domcontentloaded')
            text=page.locator('div.text.quotation').text_content()
            check(vp+' '+id+' JS-disabled static body literal exact',text==DATA[id]['text']['translation'],{'actualSHA':hashb(text.encode()),'expectedSHA':DATA[id]['extraction']['body_sha256']})
            check(vp+' '+id+' static source number not supplied', 'Collection number not supplied' in page.locator('h1').inner_text())
            check(vp+' '+id+' static source origin current Human', 'Translation: Human' in page.locator('main').inner_text() and '"classification":"human"' in page.locator('main').text_content())
            check(vp+' '+id+' static separate identity and source',id in page.locator('main').text_content() and 'materials/pt-riyadh-sbmrj-a9980317/source.pdf' in page.locator('main').inner_html())
            check(vp+' '+id+' static no actual Arabic reading',page.locator('.language-reading').count()==1)
            d=dims(page);check(vp+' '+id+' JS-disabled static no overflow',not d['horizontalOverflow'],d)
            screenshot(page,'static-nojs-'+id[-4:]+'-'+vp+'.png')
            cases.append({'viewport':vp,'id':id,'static_nojs':True,'body_sha256':hashb(text.encode()),'overflow':d['horizontalOverflow'],'source_file':target.name})
            page.close()
        ctx.close()
    browser.close()
check('no uncaught JavaScript page errors',len(errors)==0,errors)
receipt={'task':'PT-RIYADH-TWO-FOREIGN-ONLY-FINAL-ADAPTER-QC-002','chromium_version':version,'method':'Real Chromium, Playwright page.set_content with exact generated reader and static HTML; local file / loopback browser navigations blocked by environment policy. CSS injected verbatim for no-JS static presentation measurements only. No remote URLs followed.','counts':{'checks':len(counts),'failed':len(fails),'screenshots':len(screens),'export_files':2,'viewports':['1280x900','390x844']},'cases':cases,'checks':counts,'browser_errors':errors,'screenshots':screens,'limitations':['Live hosted URL and source GitHub URL intentionally untested; generated links checked only','Page navigation to file:// and 127.0.0.1 blocked by environment browser policy; actual DOM evaluated using set_content instead']}
p=EVID/'browser-tests.json';p.write_text(json.dumps(receipt,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
print(json.dumps({'status':'PASS','counts':receipt['counts'],'browser_version':version,'export_shas':[case['browser_export']['sha256'] for case in cases if 'browser_export' in case],'screenshots':len(screens)},indent=2))
