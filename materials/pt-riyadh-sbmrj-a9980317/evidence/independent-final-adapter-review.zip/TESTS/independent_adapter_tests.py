#!/usr/bin/env python3
"""Independent finite current-main adapter QC; isolated files only. Not a publisher."""
from pathlib import Path
from copy import deepcopy
from collections import Counter
import json, hashlib, sys, subprocess, shutil, tempfile, re, html
import jsonschema
from bs4 import BeautifulSoup

BASE=Path(__file__).resolve().parent
ROOT=BASE/'private-fixture'
SRC=ROOT/'materials/pt-riyadh-sbmrj-a9980317'
STAGE=BASE/'staging'
EVID=BASE/'independent_evidence'
EVID.mkdir(exist_ok=True)
sys.path.insert(0,str(BASE/'actual-code/scripts'))
from material_registry import load_public_materials
from build_reader import load_records
from build_bank_views import canonical

EXP_IDS=['pt_riyadh_sbmrj_0832','pt_riyadh_sbmrj_0833']
EXP_HASH='d0b49d0e1ebe307fc214350419c1093291992a36787941f5bb67092541eb6dbc'
EXP_SRC='a9980317600c6beb088c73fac3d074b131d0f35ff889241a129fa23df091a3c4'
EXP_ZIP='cef203a00c631eef9d5573e8ecdc88e5a08b3e2a8d9322268c69bce3c1d63cc9'
BODY=['f57eeb2b47d7c1885b03f9c7b742856478df9d89cb442f8157401193ad146b13','0d133d650b73198d67581d4043d48d7d18bf76dc077b5f1c842c4fb7be7cc63a']
SPAN=[(5,496),(5,451)]
HELD={'pt_riyadh_sbmrj_1348','pt_riyadh_sbmrj_sup_ch360_02'}
REFERENCE=['Abu Daúd','(Abu Daúd)']
assertions=[]

def digest(data):return hashlib.sha256(data).hexdigest()
def fh(path):return digest(Path(path).read_bytes())
def check(name, cond, extra=None):
    assertions.append({'name':name,'result':'PASS' if cond else 'FAIL','detail':extra})
    if not cond:raise AssertionError(name+': '+str(extra))
def loadj(path):return json.loads(Path(path).read_text(encoding='utf8'))
def save(name,obj):
    p=EVID/name;p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8');return p

check('pinned source pdf SHA',fh(SRC/'source.pdf')==EXP_SRC)
check('pinned canonical JSON exact byte SHA',fh(SRC/'records.json')==EXP_HASH)
check('pinned exact outer ZIP',fh('/mnt/data/PT-RIYADH-TWO-FOREIGN-ONLY-FINAL-ADAPTER-QC-002.zip')==EXP_ZIP)
raw=loadj(SRC/'records.json');man=loadj(SRC/'manifest.json');span=loadj(SRC/'evidence/source-span-map.json');held=loadj(SRC/'evidence/held-record-scope.json')
fixture_search=ROOT/'search/records.jsonl';stream=[json.loads(s) for s in fixture_search.read_text(encoding='utf8').splitlines()]
check('two unique IDs correct, row order', [r['id'] for r in raw]==EXP_IDS and len(set(r['id'] for r in raw))==2)
check('source map pinned same 2 IDs', [r['id'] for r in span]==EXP_IDS)
check('two held IDs separately protected',set(held['preservedHeldIDs'])==HELD and all(r['id'] not in HELD for r in raw))
check('registered manifest adapter and source',man['adapter']=='records-v1' and man['source']['sha256']==EXP_SRC and man['records']['sha256']==EXP_HASH and man['records']['count']==2 and man['id']=='pt-riyadh-sbmrj-a9980317')
check('owner authorized distinct from QC and rights',man['publication']['authorized'] is True and man['publication']['certified_release_eligible'] is False and man['publication']['rights_clearance_asserted'] is False and man['publication']['independent_whole_book_qc_asserted'] is False)
check('explicit counterpart disabled',man['counterpart_policy']['mode']=='disabled')
check('both printed numbers duplicate without in_book/canonical/provider',all(r['number']['source_number_as_printed']=='833' and r['number']['in_book'] is None and r['number']['canonical'] is None and r['number']['numbering_scope']=='duplicate_source_local_token_not_canonical' and r['number']['original_occurrence_id']==r['id'] for r in raw))
check('correct distinct local source bodies',raw[0]['text']['translation']!=raw[1]['text']['translation'])
check('original 4 cases absent from registration except selected 2', len(raw)==2 and set(r['id'] for r in raw).isdisjoint(HELD))

schema_root=BASE/'actual-code/schemas'
for key,name,instances in [('material','material-record.schema.json',raw),('search','search.record.schema.json',stream),('manifest','material-manifest.schema.json',[man])]:
    schema=loadj(schema_root/name)
    try:
        registry=jsonschema.validators.RefResolver(base_uri=schema_root.as_uri()+'/',referrer=schema)
        validator=jsonschema.validators.validator_for(schema)(schema,resolver=registry)
        errs=[e.message for row in instances for e in validator.iter_errors(row)]
        check('JSON Schema '+key,len(errs)==0, errs[:6])
    except Exception as exc:check('JSON Schema '+key,False,str(exc))

case=[]
for i,(r,s) in enumerate(zip(raw,span)):
    id=r['id'];field=s['source_passage_verbatim'];start,end=s['bodySpanCodepoints'];body=field[start:end]
    check(id+' sourceField SHA equals source-map and canonical', digest(field.encode())==s['sourceFieldSHA256']==r['extraction']['source_field_sha256'])
    check(id+' exact [start,end] slice and trailing whitespace', (start,end)==SPAN[i] and len(field)==[504,461][i] and field[:start]=='833. ' and r['text']['translation']==body and body[-1] in ' \n')
    check(id+' body SHA pinned 3-ways',digest(body.encode())==s['bodySHA256']==r['extraction']['body_sha256']==BODY[i])
    check(id+' trailing reference removed verbatim',field[end:]==REFERENCE[i] and s['reference_as_printed']==REFERENCE[i] and r['references']['citation_as_printed']==REFERENCE[i])
    check(id+' exact foreign-only and no commentary',r['text']['arabic'] is None and r['commentary']=={'arabic':None,'translation':None} and r.get('footnotes',[])==[])
    check(id+' page + safe distinct narrator',r['page']=={'pdf':[397],'printed':['397']} and r['narrator']['name']=='Abu Barzah')
    check(id+' unsupported counterpart number/references withheld',r['references']['items']==[] and r['references']['counterpart_verified'] is False and r['number']['canonical'] is None and r['number']['in_book'] is None)
    check(id+' source and translator binding',r['source']['sha256']==EXP_SRC and r['source']['supplied_filename']=='source.pdf' and r['translator']['name']=='Prof. Samir El Hayek')
    check(id+' historical unknown/AI and current human separately declared',r['translation_provenance']['origin']=='unknown' and r['ai_translation']=='unknown' and r['translation_provenance']['ai_translation']=='unknown')
    check(id+' historical review and rights not inflated',r['review']['status']=='bounded_source_fidelity_pass_final_adapter_pending' and r['review']['certified_release_eligible'] is False and r['review']['release_eligible'] is False and r['rights']['copyright_status']=='unassessed' and r['rights']['permission_to_republish']=='unassessed')
    check(id+' no unauthorized Arabic pairing',r['text']['arabic'] is None and not r['references']['counterpart_verified'])
    case.append({'id':id,'expected_body_sha256':BODY[i],'exact_codepoint_slice':[start,end],'passage_codepoints':len(field),'body_codepoints':len(body),'excluded_source_suffix':REFERENCE[i],'printed_source_token':'833','canonical_number':None,'in_book_number':None,'source_pdf_page':397,'narrator':'Abu Barzah','detected_trailing_whitespace':repr(body[-1]),'adapter_status':'PASS'})

reg=load_public_materials(ROOT)
proj=reg['groups'][0]
check('actual material registry returns one group of two',len(reg['materials'])==1 and len(reg['groups'])==1 and len(proj)==2)
check('actual registry projected rows exactly equal frozen published fixture search',proj==stream)
rows,cat,info=load_records(ROOT)
check('actual search records full-stream SHA verified',info['records_sha256']==fh(fixture_search) and info['record_count']==2 and rows==stream)
check('source locator/identity roundtrip',all(row['source']['record_locator']=={'path':'materials/pt-riyadh-sbmrj-a9980317/records.json','json_pointer':'/'+str(i)} and row['canonical_record_sha256']==digest(canonical(raw[i])) and row['id']==EXP_IDS[i] for i,row in enumerate(rows)))
check('current Human provenance policy with historical Unknown preserved',all(row['translation_provenance']['origin']=='unknown' and row['translation_provenance']['current_policy']['classification']=='human' and row['ai_translation']=='unknown' for row in rows))
check('search no Arabic or counterpart grouping flags',all(row['text_arabic'] is None and row.get('counterpart_policy',{}).get('mode')=='disabled' for row in rows))
check('search record count excludes both held', set(row['id'] for row in rows)==set(EXP_IDS) and set(row['id'] for row in rows).isdisjoint(HELD))
check('search source hash correct',all(row['source']['sha256']==EXP_SRC for row in rows))

readbuild=loadj(STAGE/'reader-build.stdout.json');staticbuild=loadj(STAGE/'discovery-build.stdout.json')
check('actual reader build two records exactly',readbuild['record_count']==2 and readbuild['grouped_reading_count']==2 and readbuild['reviewed_reading_groups']==0 and readbuild['self_contained'] and readbuild['source_text_modified'] is False)
check('static build independently generated two exact separate pages',staticbuild['record_pages']==2 and staticbuild['static_record_pages_dom_verified']==2 and staticbuild['source_records_sha256']==info['records_sha256'] and staticbuild['source_texts_unchanged'])

md=STAGE/'markdown/pt/riyadh/sbmrj-samir-el-hayek-undated-a9980317/page-0001.md';md_text=md.read_text(encoding='utf8')
for i,r in enumerate(raw):
    id=r['id'];body=r['text']['translation'];key=html.escape(body,quote=False).replace('\n','<br>\n')
    check(id+' complete Markdown body incl newline/trailing whitespace',f'<p dir="auto">{key}</p>' in md_text)
    check(id+' Markdown source identity/details',id in md_text and ('<strong>Translation origin:</strong> Human') in md_text and 'Preserved source label: Unknown' in md_text and r['references']['citation_as_printed'] in html.unescape(md_text))
    paths=list((STAGE/'static/hadith/pt/riyadh/sbmrj-samir-el-hayek-undated-a9980317').glob('*.html'))
    matching=[]
    for page in paths:
        s=BeautifulSoup(page.read_text(encoding='utf8'),'html.parser')
        if id in s.get_text(separator=' '):matching.append((page,s))
    check(id+' exactly one dedicated static page',len(matching)==1)
    page,s=matching[0]
    rendered=s.select_one('div.text.quotation')
    check(id+' static DOM verbatim text incl whitespace',rendered and rendered.get_text()==body, {'html':page.name,'expected_sha':digest(body.encode()),'actual_sha':digest(rendered.get_text().encode()) if rendered else None})
    check(id+' static no Arabic translation substitute',len(s.select('div.reading-content div.text.quotation'))==1 and s.select_one('.language-reading summary').get_text().startswith('Portuguese') and 'Collection number not supplied' in s.title.string and 'Translation: Human' in s.get_text())
    check(id+' static original PDF link',any('materials/pt-riyadh-sbmrj-a9980317/source.pdf' in a.get('href','') for a in s.select('a')))
    check(id+' static historical provenance and unique ID',r['id'] in s.get_text() and '"origin":"unknown"' in s.get_text() and '"classification":"human"' in s.get_text())
    case[i]['static_html']=page.relative_to(STAGE).as_posix();case[i]['static_html_sha256']=fh(page)
check('two static filenames distinct and not number-derived',len(set(x['static_html'] for x in case))==2 and all('833.html' not in x['static_html'] for x in case))

# Fail-closed negative controls. Copy only under isolated disposable path.
def mutate_test(label,change,should_contain):
    with tempfile.TemporaryDirectory(prefix='pt002-neg-',dir=str(BASE)) as td:
        testroot=Path(td)/'bank'
        shutil.copytree(ROOT,testroot)
        records=testroot/'materials/pt-riyadh-sbmrj-a9980317/records.json';manifest=testroot/'materials/pt-riyadh-sbmrj-a9980317/manifest.json'
        rr=loadj(records);mm=loadj(manifest)
        change(rr,mm)
        records.write_text(json.dumps(rr,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
        # If caller requests a valid rehash, change() sets special sentinel.
        if mm.pop('_qc_update_records_hash',False):mm['records']['sha256']=fh(records)
        manifest.write_text(json.dumps(mm,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
        try:load_public_materials(testroot);got='ACCEPTED'
        except Exception as exc:got=type(exc).__name__+': '+str(exc)
        check('negative fail-closed '+label,should_contain in got,got)
        return {'label':label,'mutant_result':got,'expected_substring':should_contain,'classification':'REJECTED_AS_EXPECTED'}
neg=[]
neg.append(mutate_test('body tamper w/o registry hash change',lambda rr,mm:rr[0]['text'].__setitem__('translation',rr[0]['text']['translation']+'X'),'Material checksum mismatch'))
neg.append(mutate_test('material identity mismatch despite rehashed manifest',lambda rr,mm:(rr[0].__setitem__('book_key','muslim'),mm.__setitem__('_qc_update_records_hash',True)),'Record/material identity mismatch'))
neg.append(mutate_test('explicit held row despite rehashed manifest',lambda rr,mm:(rr[1].__setitem__('show_in_html_hadith',False),mm.__setitem__('_qc_update_records_hash',True)),'Record explicitly withheld'))
with tempfile.TemporaryDirectory(prefix='pt002-search-neg-',dir=str(BASE)) as td:
    dst=Path(td);shutil.copytree(ROOT,dst/'bank');linepath=dst/'bank/search/records.jsonl';ss=linepath.read_text();linepath.write_text(ss.replace('Abu Barzah','Abu BADzah',1));
    try:load_records(dst/'bank');got='ACCEPTED'
    except Exception as exc:got=type(exc).__name__+': '+str(exc)
    check('negative fail-closed search tamper vs catalog digest', 'SHA-256 mismatch' in got,got)
    neg.append({'label':'search tamper without catalog rehash','mutant_result':got,'classification':'REJECTED_AS_EXPECTED'})

# An independent pinned semantic guard catches post-authority modifications even if a new local manifest hash is computed.
def guard_present(r,s,pinned_hash):
    try:
        full=s['source_passage_verbatim'];cp=r['extraction']['body_span_codepoints'];body=r['text']['translation'];
        assert cp==s['bodySpanCodepoints']
        assert digest(full.encode())==r['extraction']['source_field_sha256']==s['sourceFieldSHA256']
        assert full[cp[0]:cp[1]]==body
        assert digest(body.encode())==r['extraction']['body_sha256']==s['bodySHA256']==pinned_hash
        assert r['number']['canonical'] is None and r['number']['in_book'] is None
        assert r['text']['arabic'] is None
        assert r['number']['source_number_as_printed']=='833'
        return True
    except AssertionError:return False
check('independent pinned guard baseline both',all(guard_present(r,s,BODY[i]) for i,(r,s) in enumerate(zip(raw,span))))
m=deepcopy(raw[0]);m['text']['translation']+='!';check('independent pinned guard rejects body tamper',not guard_present(m,span[0],BODY[0]))
m=deepcopy(raw[0]);m['number']['canonical']='833';check('independent pinned guard rejects invented canonical',not guard_present(m,span[0],BODY[0]))
m=deepcopy(raw[0]);m['text']['arabic']='fabricated';check('independent pinned guard rejects false counterpart',not guard_present(m,span[0],BODY[0]))
m=deepcopy(raw[0]);m['extraction']['body_span_codepoints']=[5,495];check('independent pinned guard rejects moved slice',not guard_present(m,span[0],BODY[0]))

report={'task':'PT-RIYADH-TWO-FOREIGN-ONLY-FINAL-ADAPTER-QC-002','scope':'two exact records; previous source/component review closed; no publication','inputs':{'source_pdf_sha256':EXP_SRC,'canonical_records_sha256':EXP_HASH,'outer_zip_sha256':EXP_ZIP,'search_records_sha256':info['records_sha256']},'record_cases':case,'assertions_count':len(assertions),'failed_count':sum(a['result']=='FAIL' for a in assertions),'assertions':assertions,'negative_controls':neg,'staged_builds':{'reader':readbuild,'static':staticbuild},'held_unchanged':sorted(HELD)}
save('core-tests.json',report)
print(json.dumps({'status':'PASS','checks':len(assertions),'negative_controls':len(neg),'cases':case,'stage':{'static_pages':staticbuild['record_pages'],'reader_count':readbuild['record_count']}},ensure_ascii=False,indent=2))
