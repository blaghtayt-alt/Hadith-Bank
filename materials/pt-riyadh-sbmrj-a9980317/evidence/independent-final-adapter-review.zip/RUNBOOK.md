# Verification and reproduction

The original input ZIP is not repackaged wholesale. Its 135 files were checked by CRC, byte-size and SHA-256 against the original manifest. The source PDF was SHA-256 checked without repeating the closed source review.

1. Obtain and extract the exact original `PT-RIYADH-TWO-FOREIGN-ONLY-FINAL-ADAPTER-QC-002.zip` (SHA-256 `cef203a00c631eef9d5573e8ecdc88e5a08b3e2a8d9322268c69bce3c1d63cc9`) in a disposable folder.
2. Copy `TESTS/independent_adapter_tests.py`, `TESTS/independent_browser_tests.py`, and `TESTS/compressed_reader_test.py` into that extraction directory. These scripts rely on its supplied `actual-code/`, `private-fixture/` and their own `staging/` generated outputs. They never modify the supplied registry or source files.
3. Run `mkdir -p staging/reader staging/static staging/markdown staging/reader-compressed`. Generate the uncompressed reader **and its build receipt** with `PYTHONPATH=actual-code/scripts python -c "import json;from pathlib import Path;from build_reader import build;print(json.dumps(build(Path('private-fixture'),Path('staging/reader/index.html').resolve(),Path('staging/markdown').resolve(),compress=False),indent=2))" > staging/reader-build.stdout.json`.
4. Generate the separate static tree and receipt with `PYTHONPATH=actual-code/scripts python -c "import json;from pathlib import Path;from build_discovery import build;print(json.dumps(build(Path('private-fixture'),Path('staging/static').resolve()),indent=2))" > staging/discovery-build.stdout.json`.
5. Generate the compressed reader and receipt via `PYTHONPATH=actual-code/scripts python -c "import json;from pathlib import Path;from build_reader import build;print(json.dumps(build(Path('private-fixture'),Path('staging/reader-compressed/index.html').resolve(),compress=True),indent=2))" > staging/reader-compressed.build.json`.
6. Run `python independent_adapter_tests.py`, `python independent_browser_tests.py`, and `python compressed_reader_test.py`. Requires Python 3, `jsonschema`, `beautifulsoup4`, `playwright`, and executable Chromium at `/usr/bin/chromium` (update executable path in a disposable test copy if different).
7. Inspect PROOF/ for stdout, complete assertion logs, screenshots, generated HTML, Markdown, browser JSON exports, and the original 135-file input hash inventory. Only the two specified record IDs are judged.

The review used Chromium via `page.set_content` because this environment blocked both file:// and 127.0.0.1 navigation. This does not prove live link availability.
