# Português — Portuguese / riyadh

Edition: `sbmrj-samir-el-hayek-undated-a9980317` · Narrations 1–2 of 2.

[Edition index](README.md)

## Narration 1

[Open this narration online](https://blaghtayt-alt.github.io/Hadith-Bank/hadith/pt/riyadh/sbmrj-samir-el-hayek-undated-a9980317/ec0d1bd234bd792456f8253d.html)

<section class="language-reading" lang="pt">
<h3>Portuguese</h3>

<p dir="auto">Abu Barzah (R) relatou que ao se aproximar o dia do desfecho da sua vida, o<br>
Profeta (S), vendo que iria deixar a companhia, costuma a suplicar: “Ó Deus, Tu és<br>
Sagrado, e todo o louvor é para Ti! Presto testemunho de que não há ninguém digno de<br>
louvor a não seres Tu! Peço o Teu perdão, e me volto a Ti!” Um Companheiro lhe<br>
perguntou: “Ó Mensageiro de Deus, estás agora dizendo palavras que nunca disseste<br>
antes!” Ele disse: “Essas palavras são uma expiação do que se passa num ajuntamento.”<br>
</p>

<p dir="auto">[riyadh · hadith number not supplied]</p>

<p><strong>Source:</strong> O Jardim dos Virtuosos · Translation origin: Human</p>

</section>

<p><strong>Source:</strong> O Jardim dos Virtuosos — source URL not supplied<br>
<strong>Collection:</strong> riyadh · <strong>Edition:</strong> sbmrj-samir-el-hayek-undated-a9980317<br>
<strong>Number:</strong> Collection number not supplied<br>
<strong>Page:</strong> PDF page 397 · Printed page 397<br>
<strong>Translator:</strong> Prof. Samir El Hayek<br>
<strong>Narrator:</strong> Abu Barzah<br>
<strong>Translation origin:</strong> Human</p>

<details><summary>Source translation-origin history</summary>

<p dir="auto">Preserved source label: Unknown</p>
<p dir="auto">Preserved source AI-translation flag: unknown</p>
<p dir="auto">Original source metadata is preserved; current translation classification follows the recorded provenance evidence and owner policy.</p>

</details>

<details><summary>Original import and review history</summary>

<p>Historical import status: bounded_source_fidelity_pass_final_adapter_pending · Historical independent Pro QC: source_and_component_only_final_adapter_pending · Release: source_candidate</p>

<p dir="auto">DUPLICATE_PRINTED_833_NOT_CANONICAL<br>
ARABIC_PARALLEL_NOT_APPROVED</p>

</details>

<details>
<summary>References</summary>

<p><strong>citation as printed</strong></p>
<p dir="auto">Abu Daúd</p>

</details>

<details>
<summary>Narrator and supplied tags</summary>

<pre>{&quot;narrator&quot;:{&quot;name&quot;:&quot;Abu Barzah&quot;,&quot;evidence&quot;:&quot;As printed in the Portuguese narration; mismatched Arabic narrator not inherited.&quot;},&quot;topic_tags&quot;:[],&quot;editorial_tags&quot;:[]}</pre>

</details>

<details>
<summary>Source locators and review issues</summary>

<p><strong>Occurrence ID:</strong> <code>pt_riyadh_sbmrj_0832</code><br><strong>Canonical record:</strong> <a href="../../../../../private-fixture/materials/pt-riyadh-sbmrj-a9980317/records.json">materials/pt-riyadh-sbmrj-a9980317/records.json</a><br><strong>JSON pointer:</strong> <code>/0</code><br><strong>Original file:</strong> <a href="../../../../../private-fixture/materials/pt-riyadh-sbmrj-a9980317/source.pdf">materials/pt-riyadh-sbmrj-a9980317/source.pdf</a><br><strong>Original SHA-256:</strong> <code>a9980317600c6beb088c73fac3d074b131d0f35ff889241a129fa23df091a3c4</code></p><p><a href="https://github.com/blaghtayt-alt/Hadith-Bank/raw/main/materials/pt-riyadh-sbmrj-a9980317/source.pdf">Download PDF</a></p>

<p><strong>Review issues:</strong></p>
<p dir="auto">DUPLICATE_PRINTED_833_NOT_CANONICAL<br>
ARABIC_PARALLEL_NOT_APPROVED</p>

</details>

---

## Narration 2

[Open this narration online](https://blaghtayt-alt.github.io/Hadith-Bank/hadith/pt/riyadh/sbmrj-samir-el-hayek-undated-a9980317/dfcd38a09330a52252b39946.html)

<section class="language-reading" lang="pt">
<h3>Portuguese</h3>

<p dir="auto">Abu Barzah (R) relatou que o Profeta (S) antes de se levantar de uma reunião<br>
costumava suplicar: “ Ó Deus, Tu és Sagrado, e todo o louvor é para Ti! Presto<br>
testemunho de que não há ninguém digno de louvor a não seres Tu! Peço o Teu perdão,<br>
e me volto a Ti! ” Um Companheiro lhe perguntou: “Ó Mensageiro de Deus, estás agora<br>
dizendo palavras que nunca disseste antes!” Ele disse: “Essas palavras são uma<br>
expiação do que se passa num ajuntamento.” </p>

<p dir="auto">[riyadh · hadith number not supplied]</p>

<p><strong>Source:</strong> O Jardim dos Virtuosos · Translation origin: Human</p>

</section>

<p><strong>Source:</strong> O Jardim dos Virtuosos — source URL not supplied<br>
<strong>Collection:</strong> riyadh · <strong>Edition:</strong> sbmrj-samir-el-hayek-undated-a9980317<br>
<strong>Number:</strong> Collection number not supplied<br>
<strong>Page:</strong> PDF page 397 · Printed page 397<br>
<strong>Translator:</strong> Prof. Samir El Hayek<br>
<strong>Narrator:</strong> Abu Barzah<br>
<strong>Translation origin:</strong> Human</p>

<details><summary>Source translation-origin history</summary>

<p dir="auto">Preserved source label: Unknown</p>
<p dir="auto">Preserved source AI-translation flag: unknown</p>
<p dir="auto">Original source metadata is preserved; current translation classification follows the recorded provenance evidence and owner policy.</p>

</details>

<details><summary>Original import and review history</summary>

<p>Historical import status: bounded_source_fidelity_pass_final_adapter_pending · Historical independent Pro QC: source_and_component_only_final_adapter_pending · Release: source_candidate</p>

<p dir="auto">DUPLICATE_PRINTED_833_NOT_CANONICAL<br>
ARABIC_PARALLEL_NOT_APPROVED</p>

</details>

<details>
<summary>References</summary>

<p><strong>citation as printed</strong></p>
<p dir="auto">(Abu Daúd)</p>

</details>

<details>
<summary>Narrator and supplied tags</summary>

<pre>{&quot;narrator&quot;:{&quot;name&quot;:&quot;Abu Barzah&quot;,&quot;evidence&quot;:&quot;As printed in the Portuguese narration; mismatched Arabic narrator not inherited.&quot;},&quot;topic_tags&quot;:[],&quot;editorial_tags&quot;:[]}</pre>

</details>

<details>
<summary>Source locators and review issues</summary>

<p><strong>Occurrence ID:</strong> <code>pt_riyadh_sbmrj_0833</code><br><strong>Canonical record:</strong> <a href="../../../../../private-fixture/materials/pt-riyadh-sbmrj-a9980317/records.json">materials/pt-riyadh-sbmrj-a9980317/records.json</a><br><strong>JSON pointer:</strong> <code>/1</code><br><strong>Original file:</strong> <a href="../../../../../private-fixture/materials/pt-riyadh-sbmrj-a9980317/source.pdf">materials/pt-riyadh-sbmrj-a9980317/source.pdf</a><br><strong>Original SHA-256:</strong> <code>a9980317600c6beb088c73fac3d074b131d0f35ff889241a129fa23df091a3c4</code></p><p><a href="https://github.com/blaghtayt-alt/Hadith-Bank/raw/main/materials/pt-riyadh-sbmrj-a9980317/source.pdf">Download PDF</a></p>

<p><strong>Review issues:</strong></p>
<p dir="auto">DUPLICATE_PRINTED_833_NOT_CANONICAL<br>
ARABIC_PARALLEL_NOT_APPROVED</p>

</details>

---


[Edition index](README.md)
