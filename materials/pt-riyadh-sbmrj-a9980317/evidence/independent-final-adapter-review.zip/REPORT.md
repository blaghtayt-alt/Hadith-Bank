# PT-RIYADH-TWO-FOREIGN-ONLY-FINAL-ADAPTER-QC-002

**Independent final adapter verdict: PASS for exactly 2 canonical occurrences; 0 new adapter holds.**

This is a **read-only, finite two-record adapter review**. The prior four-case page/semantic/credit/source-word QC remains closed and was not repeated. No shared files, repository, GitHub Pages or source records were modified or published. The supplied current-main scripts were executed in an isolated fixture; the claim of main-branch revision `948323bb` was not separately checked against the live remote.

## Pinned input integrity

- Outer input ZIP: **15,265,790 bytes**; SHA-256 `cef203a00c631eef9d5573e8ecdc88e5a08b3e2a8d9322268c69bce3c1d63cc9`.
- The exact 135 manifest payloads: full ZIP CRC, byte length and SHA-256 checks **PASS**. The complete original `MANIFEST.json` is included under `PROOF/INPUT-MANIFEST.json`.
- Source PDF: SHA-256 `a9980317600c6beb088c73fac3d074b131d0f35ff889241a129fa23df091a3c4` (checksum only, **no renewed visual/source-text review**).
- Final canonical two-row `records.json`: SHA-256 `d0b49d0e1ebe307fc214350419c1093291992a36787941f5bb67092541eb6dbc`.
- Registry's verified search stream: SHA-256 `45abeed27cf287266630092005de187e414285e7f26657b721370b2fa3d7e4a6`.
- All 5 supporting evidence payloads passed the actual `material_registry.load_public_materials` checksum/size validation, including the unchanged original four-case records and earlier independent QC archive.

## Per-record adapter dispositions

| Field | `pt_riyadh_sbmrj_0832` | `pt_riyadh_sbmrj_0833` |
|---|---|---|
| Adapter QC | **PASS** | **PASS** |
| Source-field codepoints | 504 | 461 |
| Exact narration slice | `[5,496]` | `[5,451]` |
| Body codepoints | 491 | 446 |
| Exact body SHA-256 | `f57eeb2b47d7c1885b03f9c7b742856478df9d89cb442f8157401193ad146b13` | `0d133d650b73198d67581d4043d48d7d18bf76dc077b5f1c842c4fb7be7cc63a` |
| Excluded reference suffix | `Abu Daúd` | `(Abu Daúd)` |
| Source-body boundary | Retains final LF | Retains final space |
| Source-local printed number | `833` | `833` |
| Canonical/in-book number | `null` / `null` | `null` / `null` |
| Narrator | Abu Barzah | Abu Barzah |
| Arabic / English counterpart | Not supplied / disabled | Not supplied / disabled |
| Source PDF page | 397 | 397 |

The record IDs remain distinct despite their duplicate source-local printed token; no numeric merge, Arabic 832 association, or fabricated translation was introduced. Printed citations stay in `references.citation_as_printed`, not appended to the verbatim narration. Arabic bodies and commentary are null. Source/document hashes, record locator JSON pointers `/0` and `/1`, translator display and separate provenance metadata all roundtrip.

## Actual independent execution

- **71** passing source-span, schema, checksum, registry, search-projection, Markdown, and static-generation assertions. This includes genuine current-main `material_registry.load_public_materials`, `build_reader.load_records`, `build_reader.build`, and `build_discovery.build` calls.
- Standalone uncompressed reader rebuild: **2 source occurrences**, **2 reading groups**, **zero linked family groups**, exact source-text preservation; generated reader SHA-256 `2817ea066b3ebd35596fd445879f39839129eb8609357bdd68cb887b12d4a2fc`.
- Compressed standalone reader generated through current-main code and successfully loaded in real Chromium desktop and mobile; SHA-256 `28535f46beaf9c075c81aea28518ddcd85b763de7275bd6fbb8f464a0c561035`.
- Static discovery build: **2 distinct full-text pages**, both passing builder DOM verification; Markdown one page containing both exact bodies, including newline and trailing-space boundaries.
- **89** passing real Chromium/Playwright assertions across desktop **1280×900** and mobile **390×844**, including exact JavaScript reader textContent, search, identity, absent counterparts, attribution policy, source links and no horizontal page overflow.
- Both viewports exported selected JSON via the **actual UI Download selected JSON** action; exported structures equal the exact pinned search projections and independently match canonical narration SHA-256 values. Desktop and mobile exported bytes have identical SHA-256 `b5f631a5d4dd2d68dad3edcb3a590c38293458cce31cd0299fbeddf04b907b9d`.
- Four static record/viewport combinations checked in Chromium with JavaScript explicitly **disabled**; their DOM text is verbatim source-body text. Screenshots include ten views (reader/search/static).
- No JavaScript runtime errors observed in the bounded views.

### Mutation/fail-closed controls

The executable registry/search rejected four isolated negative inputs: unauthorized body-byte change without updated manifest; mismatched canonical book identity with rehashed manifest; explicit `show_in_html_hadith=false` row with rehashed manifest; and altered search stream without updated catalog SHA. Independently pinned exact-slice guards rejected changed body, altered slice, fabricated Arabic, and invented canonical number. The generic registry's structural checks alone are **not** independent evidence for a source-specific body slice or canonical mapping; keep this reviewer-pinned source-span/hash/identity proof attached to the two exact records.

## Existing holds and unapplied matters — not new adapter failures

1. `pt_riyadh_sbmrj_1348` (incomplete Portuguese) and `pt_riyadh_sbmrj_sup_ch360_02` (unresolved supplementary discrepancy) are **not registered** and stay held. The source-QC scope for those two was not reopened.
2. The two canonical records' historical `review.status` and `independent_pro_qc` still include `final_adapter_pending`; they were preserved byte-for-byte. This independent PASS is reported **externally**, not silently written into original historical fields. The owner controls whether and when integration metadata changes.
3. Source links in generated pages are staged targets; target URL availability on the published website or GitHub was **not** verified. This is a local current-code fixture proof, not a claim that publication has occurred.
4. Publication authorization, independent review, historical translation-origin `unknown`, current owner-policy `Human`, and rights `unassessed` remain **separate**. The task explicitly did not reopen translator/source credits, meanings, licensing or whole-book QC.
5. Browser navigation to `file://` or localhost is blocked by this environment's Chromium policy. Actual Chromium DOM/layout/interaction/export tests were executed using Playwright `set_content` with the **exact generated HTML**, and CSS was injected verbatim **only** for no-JS static visual measurements. This is not an end-to-end hosted deployment test.

**Disposition:** These exact two final adapters PASS bounded integration-readiness QC. No shared write, no rights clearance or final release asserted. The two unregistered holds and all source originals remain intact. Preserve the documented 5% reserve on subsequent owner-managed integration; no additional workers or parallel tasks were launched.
