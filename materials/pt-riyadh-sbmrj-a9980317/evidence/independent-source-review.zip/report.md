# Independent targeted QC — Portuguese Riyadh SBMRJ

**Read-only:** exactly three author-reported issue locations, four source records. No repository changes, imports, publication, translation rewriting or external origin/licence investigation. This is not full-book approval.

## Input integrity

- Source ZIP: `targeted-qc001.zip` — **12,906,981 bytes** — SHA-256 `a796fba23439e555e3018134afff24af57b71647038b785a136c6675ed483c48`
- Source PDF: `source.pdf` — **13,846,949 bytes, 821 pages** — SHA-256 `a9980317600c6beb088c73fac3d074b131d0f35ff889241a129fa23df091a3c4`
- ZIP manifest and all four listed members verified against SHA-256; `findings.json` includes their per-file hashes.
- All eight Arabic/Portuguese `source_passage_verbatim` UTF-8 byte digests independently recomputed and matched packet record hashes. All four Portuguese passage strings are independently found within the relevant PDF text layers (three exact, one whitespace-normalized). Arabic passages were independently inspected in the PDF images, not falsely claimed to byte-match the PDF's corrupted Arabic text-layer ordering.

## Decisions at each location

| Source | Record | Source fidelity | Pairing/completeness | Conservative action |
|---|---|---|---|---|
| PDF 397 | `pt_riyadh_sbmrj_0832` | Arabic 832 and upper Portuguese printed 833 each present as reported | **Not equivalent**: Abu Hurayra/Tirmidhi vs Abu Barzah/Abu Daúd | **HOLD bilingual pairing**, retain both physical passages and both printed identifiers |
| PDF 397 | `pt_riyadh_sbmrj_0833` | Arabic 833 and *lower* Portuguese printed 833 separately present; same Abu Barzah account and Abu Daúd credit | Physical pairing supported, **but Portuguese 833 is printed twice** on this page | Hold **dedup/number-only join**; preserve distinct top and bottom Portuguese occurrences; source-level pairing is not external authentication |
| PDF 568 (boundary check 569) | `pt_riyadh_sbmrj_1348` | Arabic 1416 complete, Portuguese 1416 faithfully captured **as truncated** | **Portuguese incomplete** | **HOLD completed translation / Portuguese terminal citation / full bilingual display**; no invented continuation |
| PDF 720–721 | `pt_riyadh_sbmrj_sup_ch360_02` | Both fragments accurately present | **Substantive source discrepancy** + unclosed Portuguese quote | **HOLD bilingual equivalence**; retain separate supplementary editorial examples, not numbered hadith 1790 |

### 1. PDF 397 — physical adjacency is not equivalence

The Arabic item labeled **٨٣٢** attributes to **أبي هريرة** a report on the expiation of excess speech in a meeting, referencing Tirmidhi and including a `حديث حسن صحيح` source statement. Immediately after it, the Portuguese is printed as **833. Abu Barzah ...** and mentions **Abu Daúd**. These are different reports, not two linguistic versions of the same report.

Later on **the same source page**, Arabic **٨٣٣** attributes to **أبي برزة** a supplication recited when leaving a gathering, with **أبو داود** reference. A second, distinct, *lower* Portuguese **833. Abu Barzah ...** appears after it and substantively tracks that Arabic 833. The upper Portuguese wording speaks about approaching the end of the Prophet’s life (`ao se aproximar o dia do desfecho da sua vida`); the lower says `antes de se levantar de uma reunião`. Do **not** merge the Portuguese 833 occurrences, change either printed label, assign upper Portuguese 833 to Arabic 832, or treat repetition as a reliable canonical identifier. The author's fields `physically_adjacent_different_reports` for 0832 and the source contexts for 0833 are corroborated, but published pairing remains gated.

### 2. PDF 568 — Portuguese 1416 physically cut off

Arabic **١٤١٦** attributed to **المُغِيرة بن شعبة** is complete and ends with a printed `متفق عليه` reference. Its Portuguese **1416. Al mughira Ibn Chubah** ends, without a closing quote or complete sentence, after **`quanto ao homem de posses, essas posses nada poderão fazer`**. The remaining PDF 568 area is blank. The opening of PDF **569** starts **1417**, so there is no immediate next-page continuation of 1416. Record ID **1348** is an occurrence ID, **not** the source's Portuguese hadith number.

The record's Portuguese quotation is source-faithful **but incomplete**. Keep its exact truncated ending and record the uncertainty; the complete Arabic must not be used to invent a Portuguese completion or printed Portuguese citation. Page 569 was checked only at its opening as a boundary test; no other report on 569 was reviewed.

### 3. PDF 720–721 — supplementary Arabic/Portuguese mismatch

In the closing commentary of chapter 360, the source's **second Arabic quotation** is exactly **`« لَسْــتَ مِــنْـهُمْ »`**, clarified in adjacent Arabic commentary as not among those trailing their garments arrogantly (`لست من الذين يسبلون أزرهم خيلاء`). The immediately preceding, different example discusses Abu Bakr and all the gates of Paradise.

The Portuguese *second* example on page 721 instead says **`“Você (Abu Bakr) não é uma das pessoas que não serão convidadas para ingressarem no Paraíso, porque você não é um daqueles que deixam o manto se arrastar atrás deles por arrogância.`** The extra assertion about *not being invited* is not supported by the short Arabic second quote; the Portuguese quotation is **unclosed in the actual PDF**, which is faithfully retained in the record. These quotes belong to supplementary commentary examples, not to a newly numbered hadith and not to the body of numbered 1790. Do not fix the double negative or attach the fragment to another record. `(Abu Bakr)` is a printed parenthetical recipient reference; this targeted evidence does not establish a named hadith transmitter.

## Targeted coverage, evidence and methodological limits

- **Three** specified issues, **four** records, source PDF **397, 568, 720, 721** rendered at 200 dpi. Only top of **569** inspected to verify the abrupt transition to report 1417. No additional issue locations or full-book passages checked.
- Rendered image files in `evidence/` are raw page images or a raw boundary crop of the supplied PDF, with SHA-256 in `output-manifest.json`. The source PDF itself remains unchanged and is already contained in the original user packet.
- Arabic was reviewed visually against its page render. The document's native Arabic text layer has broken reading order/font mapping; source `arabic.source_passage_verbatim` has internally verified hashes and visually corroborated key narrators and wording, **not** a proven byte-equivalent extraction from the PDF text layer. Portuguese text was also checked directly against the PDF text layer.
- Neither independent canonical Arabic edition verification nor general translation-quality validation is claimed. All three author hypotheses are **confirmed for the narrow source facts stated above**, not accepted as wider release clearance.
- User asserts Portuguese translation was human-produced. Supplied record metadata credits **Prof. Samir El Hayek** (translator) and **Shiekh Hussam Albostani** (revision); those metadata claims were recorded without a new examination of front matter (outside scope). They are separate from the user's translation-process assertion.

**Final disposition:** All four records retain at least one specified hold or pairing guard. Literal component-level fidelity at these places does not establish a complete or approved release. No source text, metadata, repository, publication or import was changed.
