# BS-TIRMIDHI-H2-SPELLING-DELTA-QC-001 — independent scoped review

**Verdict: PASS for the exact private Hadith 2 spelling successor only.** The previous source-specific spelling hold BS-TIRMIDHI-HD002-MATN-ORTHO-001 is resolved by the successor bytes; other release/integration gates remain unchanged, and the frozen original remains immutable.

## Input verification

- Uploaded packet: **1,078,185 bytes**, SHA-256 `4409b8fc59e351f02d5d132cc5042fa98661fd1dc4c0de6dc02d5ac047b5dcd9`; ZIP CRC PASS; all **3/3** outer payload byte lengths and hashes PASS.
- Nested private successor ZIP: **1,077,751 bytes**, SHA-256 `4407c6cb8db76ab693f49b47a9df729da4c45a633ea99dccad7b3d6e82a511e4`; CRC PASS; **4/4** nested payloads PASS.
- Pinned original independent QC ZIP: SHA-256 `a7dfcd05d7cc44764121d06e6a3bacb7fb82759805f84961711798e48cc6b110`; nested copy matches original exact bytes; CRC and **12/12** payloads PASS.
- Frozen original first-three packet: SHA-256 `85dbb16f7169f4ddeb9be22928950c616ffb559429238a1eb122e09cddba5e3d`; CRC and **18/18** payloads PASS. Nested original candidates equal its `candidates.jsonl` byte for byte.
- Original volume-1 PDF: **21,099,408 bytes**, SHA-256 `8b62165c8b1f79fbeb70e0e24afc751c45fadc24dcaee18ae7ec255926221bc2`; byte-identical to source PDF in frozen first-three packet. Only physical page **66** was freshly rendered and visually inspected for this delta. Printed footer reads **62**. The 528-page total is metadata only, not a new review.
- Private receipt matches the nested source-bound audit, excluding receipt-only packet details. All stated successor/original hashes independently recalculate correctly.

## Exact source word and two-field correction

On physical PDF page 66 / printed page 62, the first matn occurrence reads `s vodom ili sa posljednjom kapi vode`. The later occurrence reads **`uporedo sa vodom ili poslednjom kapi vode`** — without `j` after `l` in the second occurrence. Both source readings are legible in the attached *derived* source-page crop.

| Frozen candidate field | From | To | Decision |
|---|---|---|---|
| `matn_bosnian_exact_reading` | `ili posljednjom kapi vode` | `ili poslednjom kapi vode` | PASS |
| `raw_bosnian_transcribed_segment` | `ili posljednjom kapi vode` | `ili poslednjom kapi vode` | PASS |

The first `sa posljednjom kapi vode` occurrence remains **unchanged** in both fields. Precisely **two ASCII `j` bytes** were deleted across the entire original three-row JSONL; replacement of precisely the two authorized longer phrases reproduces the successor byte-for-byte. Neither original printed spelling is modernized or harmonized.

- Frozen original JSONL SHA-256: `e2f2171a500ee0ec60b80da0fb986382307d66c72214f964dd05313172ececbe` (16,332 bytes).
- Private successor JSONL SHA-256: **`531c10a2068d366e0b3d44c6abcd5bc882afaf8918f53e697664b99481a22ed0`** (16,330 bytes).
- Hadith 2 frozen row SHA-256: `fc45276750e7afd7ceb172c269d3b07a2c9458a29a7b407222b73d89f7f6706c` (5769 bytes).
- Hadith 2 exact successor row SHA-256: **`3115c2509942616fea983e0103fdcd98d1105a32a1fb7e0c433bb8350e386804`** (5767 bytes).
- Successor matn field (UTF-8) SHA-256: **`871b8222d7039ac3431cfce4782935b3d64cf2242386e0fc9bbf8658c5c60080`**.
- Successor raw-transcription field (UTF-8) SHA-256: **`0b747fd8be3f491f0b131d255fb36a5e30aa6cdf0e1cf2b99f01e52ee243bcb3`**.
- Unmodified chain field (UTF-8) SHA-256: `2e7b1bf1decaeaedf1f1bba9dc3c5a7e1b645f76aba5df9cb383e65ac646f931`.

Both field replacement spans were independently checked against the receipt; exact original/after field hashes match. All **43** other Hadith 2 fields, including its ID, source edition, printed number, original page span, author comments/footnotes separation, narrator/chain, archived hold flags, release status, and canonical matching caution, are exactly unchanged. Hadith 1 row SHA-256 `dd7f5342d547da3b4f90a724acb165120c03d9c7ebb6e53bdac748d5a8499ec8` and Hadith 3 row SHA-256 `dec246f85e6fdfb50bb984acbe0b5bacbc8086ff1f94bbbfca263bf707ab8512` match before/after: their previous PASS reviews were not reopened.

## Scope and remaining gates

**Scoped decision:** PASS — the verified source-ink discrepancy is fixed in the exact pinned private successor. The original source/result archives and candidate records remain unchanged. The successor still contains its historical `release_status=HOLD_PENDING_INDEPENDENT_QC` and `independent_qc=NOT_YET_PERFORMED` values; this separate review is the new evidence that an authorized downstream owner may consume. Those fields were intentionally not silently patched.

Reader staging still excludes Hadith 2. No registration, user-visible reader change, publication, GitHub write, new Hadith reading, Arabic display, commentary transcription, human retranslation, external identity/concordance matching, ownership transfer or licensing determination was performed. Independent release/overlap/rights gates remain separate.

**Uncertainty:** No OCR/text-layer output was used as fidelity evidence. Source ink clearly distinguishes the two checked word spellings. This scope does not certify all punctuation Unicode or text outside the exact correction. If a future source-image recheck finds genuinely unclear ink, it must be logged rather than guessed.

**Evidence:** `evidence/p066-printed62-first-vs-second-source-4x.png` (source PDF p66, crop 27/24/446/195 PDF points, scale 4) and `evidence/p066-printed62-footer-3x.png` (same page, footer, scale 3). Images are derived source evidence; the pinned PDF remains authoritative.

**Checkpoint:** `CASE02-CHECKPOINT.json` includes exact successor row and body hashes for downstream matching. `RESULT.json` contains the full 45-field diff audit and preservation controls. This ZIP has no modified candidate/source file or registration command.
