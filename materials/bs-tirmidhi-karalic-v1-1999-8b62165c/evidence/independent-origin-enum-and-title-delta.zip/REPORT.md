# BS-TIRMIDHI-THREE-ORIGIN-ENUM-AND-TITLE-DELTA-QC-002 — Independent bounded verdict

**Verdict: PASS — both previously identified integration-only findings resolved in the exact private successor.** This is **not** a renewed source/meaning review, full-book acceptance, repository merge or publication authorization.

## Input and scope

- Input ZIP: 1,367,732 bytes, SHA-256 `b8a818b23be822ce4e9c2955859ddfdba3e00a77a92cdda5e48388806fe38ac1`; CRC PASS; **135/135** manifest payloads independently SHA-256/size checked.
- Nested prior adapter QC result: 636,891 bytes, SHA-256 `5d04149128f46fc45c432978cf1e02159f78c28668459a00bbf89dfc3a39f46c`; CRC PASS; 23/23 manifest payload hashes passed.
- Original PDF reused unchanged at SHA-256 `8b62165c8b1f79fbeb70e0e24afc751c45fadc24dcaee18ae7ec255926221bc2`; no pages or wording rereviewed.
- Before canonical JSON SHA-256 `3a3102e3d5263e5c58ac9df995c94d45c9979a1c1cae26d41f9585bf8f76b478`; successor canonical SHA-256 `a838c90f33f7b84cc0bab29d16d720844b4ee8c76e113371358fe0cdd3e1ec8a`.
- Successor material manifest SHA-256 `48932bb4f175706f20555464a69b11aa1bedff0b64a7bf4a3c42cd22466b4b3f`; fixture catalog SHA-256 `dba5ef660d461caa5f25262217f4fecaac67f7d123f75716b5b3abaca2eb06e7`.
- Actual code snapshot supplies baseline claim `1a8c79f2609186f6f8366d7570084a92274e2108`. The  153 supplied code files were hash-verified against the packet manifest; we **did not independently authenticate** its Git commit against a remote.

## Finding 1: Generated search provenance origin enum — PASS

The only canonical-record byte delta is exactly three occurrences of:

```text
"origin": "human" -> "origin": "human_translator_credited"
```

Reversing these three literal substitutions restores the entire previous canonical JSON **byte-for-byte**. All other canonical fields, IDs, chains, bodies, pages, original source spelling, null canonical numbers, counterpart restrictions, historical `ai_translation: false`, and credited translator **Prof. Mahmut Karalić** are preserved. The new value uses an existing supported generated-search schema enum; it is **not** a new translator/production-history determination.

Independent generated-search validation using `actual-code/schemas/search.record.schema.json` rejects all three original `human` origins (as expected) and accepts all three `human_translator_credited` origins. Material-manifest and all three canonical-record schemas pass. Comparing prior generated search records with the actual new generated search records shows only `translation_provenance.origin` and the expected dependent `canonical_record_sha256` change in each record; **all other generated search fields are identical**. Schema SHA-256 `05a934f14fbf038a4655a4f94423ef3600ffb2f0a47f99982eb4230a07fc078b`.

| Case | Body SHA-256 (unchanged) | Result |
|---|---|---|
| 1 | `ce92b74895cd46808a99e9db1f5bf5c7859e5aa8f6fa7bf0ab6093d49187e68f` | PASS |
| 2 | `4989c263b0a0a238baf946c0e45b89cd3f39c65624554738059b2c8effc247cd` | PASS |
| 3 | `3aa7bee2cafb7545a9fdd2414dd1cb780e0cf3a66446aa6942669f863274b15d` | PASS |

## Finding 2: Diagnostic 390px header title — PASS

Fixture catalog and actual generated full reader use the title **Hadith Bank**. In real headless Chromium at 390px, the actual title yields **0px horizontal overflow**. Replacing only the title text in a **disposable browser DOM** with the old long diagnostic title reproduces **71px overflow**. Restoring Hadith Bank immediately restores **0px**. No production file was edited.

The `reading-room.css` SHA-256 is `71a360316e9fe753f4daa3238c0cb16a5ff94e0fd8d9250a3da5f2706ddb191b` — **identical** to the earlier independent adapter packet. Six actual DOM tests (three records × 390/1280px) returned exact text hashes, Human labels, Prof. Mahmut Karalić credit, one source reading, no unsolicited Arabic/English, and zero JS page exceptions or horizontal overflow. The actual selected-JSON download from Hadith 2 contains `translation_provenance.origin: human_translator_credited` and `ai_translation: false`.

**Browser method/limitation:** Chromium rendered the exact generated HTML/JS using `set_content` on an inert document, with external requests aborted. File, loopback and live navigation are **not certified**, and no admin navigation restriction was bypassed.

## Actual supplied-code caller checks

- `material_registry.load_public_materials`: PASS, 1 material / 3 records.
- `build_reader.load_records`: PASS, exact generated search-record round trip.
- `build_reader.build`: PASS, 371,567-byte self-contained reader, SHA-256 `76dc9bc14c2c812c65eebf0249c78287f408df09bd4a3b7bf2a6bb581e0427b8`.
- `build_discovery.build`: PASS, 3 static record pages.
- Markdown builder: PASS, 5 files.
- Generated search SHA-256 `ab3fe9f38c484418ad7be7796b018ac01e0e9ced771c50642dd2ad58af824500`.
- Source code aggregate sorted-path/hash-list SHA-256 `08e5be8b22be44413fd38d8f86e8bd2bb113f231478dc50b141bb6b002e72d19` for 153 bundled code files. Exact critical file hashes are in RESULT.json.

## Disposition

**PASS both bounded delta fixes; no new HOLD from this QC.** All earlier source/body reviews remain closed, all original input bytes unchanged, counterpart identity/canonical numbering disabled, source-only and release flags preserved. No public repository changes, deployment, rights determination, cross-project French/Hindi merge, full-corpus CI, or hosted/live tests were performed. These remain separate gates, not blanket reopenings of this bounded QC.

## Evidence

This ZIP carries the independently executed assertion scripts, execution logs, schema/record comparison JSON, six browser-case results, actual 390px diagnostic metrics, selected Hadith-2 export, representative screenshots, and manifest SHA-256 file bindings. No source PDF or full reading source is redistributed in this result ZIP.
