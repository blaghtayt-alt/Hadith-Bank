from pathlib import Path
import json,hashlib
from playwright.sync_api import sync_playwright
base=Path('/mnt/data/_bs_tirmidhi_enum_delta_work')
out=base/'independent-browser'; html=(base/'independent-actual-execution/reader.html').read_text('utf-8')
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 c=b.new_context(viewport={'width':390,'height':760});p=c.new_page();p.route('**/*',lambda r:r.abort());p.set_content(html,wait_until='load')
 p.screenshot(path=str(out/'header-actual-title-width390.png'),animations='disabled')
 p.locator('#brand-title').evaluate("el => el.textContent='PRIVATE bounded adapter execution proof'")
 p.screenshot(path=str(out/'header-diagnostic-long-title-width390.png'),animations='disabled')
 p.locator('#brand-title').evaluate("el => el.textContent='Hadith Bank'")
 assert p.evaluate('document.documentElement.scrollWidth')==390
 c.close();b.close()
print([(x.name,x.stat().st_size,hashlib.sha256(x.read_bytes()).hexdigest()) for x in sorted(out.glob('header-*.png'))])
