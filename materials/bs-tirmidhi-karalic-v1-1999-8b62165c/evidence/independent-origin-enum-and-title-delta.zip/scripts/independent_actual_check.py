#!/usr/bin/env python3
"""Isolated integration delta check, no production source edits, no outside network."""
from pathlib import Path
import json,hashlib,shutil,sys,contextlib,io
BASE=Path('/mnt/data/_bs_tirmidhi_enum_delta_work')
SOURCE=BASE/'input';CODE=SOURCE/'actual-code';OVERLAY=SOURCE/'successor-overlay';OUT=BASE/'independent-actual-execution'
OUT.mkdir(exist_ok=True)
FIX=OUT/'fixture'
assert not FIX.exists()
shutil.copytree(OVERLAY,FIX)
(srcpdf:=Path('/mnt/data/_bs_tirmidhi_qc_input/source-volume1-original.pdf'))
assert hashlib.sha256(srcpdf.read_bytes()).hexdigest()=='8b62165c8b1f79fbeb70e0e24afc751c45fadc24dcaee18ae7ec255926221bc2'
shutil.copy2(srcpdf,FIX/'materials/bs-tirmidhi-karalic-v1-1999-8b62165c/source.pdf')
sys.path.insert(0,str(CODE/'scripts'))
import material_registry,build_reader,build_discovery
from language_display import language_readings
from current_provenance import classification
import jsonschema
H=lambda x:hashlib.sha256(x).hexdigest()
expected={r['id']:r for r in json.loads((FIX/'materials/bs-tirmidhi-karalic-v1-1999-8b62165c/records.json').read_text())}
results={'source':'exact untouched private package, clean-main supplied code snapshot','code_harness':str(Path(__file__).relative_to(BASE)), 'sourcePDFSha256':H(srcpdf.read_bytes()), 'expectedRecordsSha256':H((FIX/'materials/bs-tirmidhi-karalic-v1-1999-8b62165c/records.json').read_bytes())}
# Schemas: run canonical, material, generated search checks through validator directly.
mat_schema=json.loads((CODE/'schemas/material-manifest.schema.json').read_text())
record_schema=json.loads((CODE/'schemas/material-record.schema.json').read_text())
search_schema=json.loads((CODE/'schemas/search.record.schema.json').read_text())
manifest=json.loads((FIX/'materials/bs-tirmidhi-karalic-v1-1999-8b62165c/manifest.json').read_text())
validation={'canonical':{},'search':{},'manifest':None}
def errs(val,schema): return [e.message+' @'+'.'.join(map(str,e.path)) for e in jsonschema.Draft202012Validator(schema).iter_errors(val)]
validation['manifest']=errs(manifest,mat_schema)
for id,r in expected.items():validation['canonical'][id]=errs(r,record_schema)
reg=material_registry.load_public_materials(FIX)
records=[r for group in reg['groups'] for r in group]
assert len(records)==3 and {r['id'] for r in records}==set(expected)
results['registryMaterials']=len(reg['materials']); results['registeredCount']=len(records)
checks=[]
for r in records:
 c=expected[r['id']];assert r['text_translation']==c['text']['translation'] and r['text_arabic'] is None
 assert r['translation_provenance']['origin']=='human_translator_credited'
 assert r['ai_translation'] is False and classification(r)=='human'
 assert r['number']==c['number'] and r['references']==c['references']
 assert r['counterpart_policy']['mode']=='disabled' and len(language_readings(r))==1
 assert len(language_readings(r)[0]['comments'])==0
 validation['search'][r['id']]=errs(r,search_schema)
 checks.append({'id':r['id'],'bodySha256':H(r['text_translation'].encode()),'origin':r['translation_provenance']['origin'],'currentDisplay':classification(r),'translatorName':r.get('translator'),'counterpartMode':r['counterpart_policy']['mode'],'searchSchemaErrors':validation['search'][r['id']]})
assert not validation['manifest'] and not any(validation['canonical'].values()) and not any(validation['search'].values()),validation
results['checks']=checks;results['schemaValidation']=validation
# Demonstrate strict old-origin rejection, not merely new schema acceptance.
oldfail={}
for r in records:
 old=dict(r);old['translation_provenance']=dict(r['translation_provenance']);old['translation_provenance']['origin']='human'
 oldfail[r['id']]=errs(old,search_schema)
assert all(len(v)==1 and 'not one of' in v[0] for v in oldfail.values())
results['oldSearchOriginRejected']=oldfail
# Actual generated search registry and build load/full/markdown/static.
search=FIX/'search/records.jsonl';search.parent.mkdir(exist_ok=True)
search.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in records),encoding='utf-8',newline='\n')
assert H(search.read_bytes())==json.loads((FIX/'catalog/materials.json').read_text())['search']['records_sha256'], ('catalog search precomputed SHA not exact',H(search.read_bytes()))
reloaded,catalog,info=build_reader.load_records(FIX)
assert reloaded==records
results['roundtrip']=True;results['searchFileSha256']=H(search.read_bytes())
reader=build_reader.build(FIX,OUT/'reader.html',markdown_output=OUT/'markdown',compress=True)
static=build_discovery.build(FIX,OUT/'static')
assert static['record_pages']==3
results['reader']=reader;results['static']=static;results['readerHtmlSha256']=H((OUT/'reader.html').read_bytes())
results['staticRecordPages']=static['record_pages'];results['markdownFiles']=len(list((OUT/'markdown').rglob('*.md')))
(OUT/'ACTUAL_RESULT.json').write_text(json.dumps(results,ensure_ascii=False,indent=2,default=str)+'\n')
print(json.dumps({'success':True,'records':len(records),'materialManifestSchema':len(validation['manifest']),'canonicalSchemas':sum(map(len,validation['canonical'].values())),'generatedSearchSchemas':sum(map(len,validation['search'].values())),'oldOriginSearchSchemaFailures':sum(map(len,oldfail.values())),'catalogTitle':catalog.get('title'),'readerHtmlBytes':(OUT/'reader.html').stat().st_size,'staticRecordPages':static['record_pages'],'markdownFiles':results['markdownFiles'],'searchSHA':results['searchFileSha256'],'codeSourcePath':str(CODE)},ensure_ascii=False))
