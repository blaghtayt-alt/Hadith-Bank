#!/usr/bin/env python3
"""Actual generated reader Chromium DOM, zero navigation/no external network."""
from pathlib import Path
from hashlib import sha256
import json
from playwright.sync_api import sync_playwright
BASE=Path('/mnt/data/_bs_tirmidhi_enum_delta_work')
EX=BASE/'independent-actual-execution'
OUT=BASE/'independent-browser';OUT.mkdir(exist_ok=True)
html=(EX/'reader.html').read_text('utf8')
rows=json.loads((EX/'fixture/materials/bs-tirmidhi-karalic-v1-1999-8b62165c/records.json').read_text('utf8'))
expected={r['id']:r for r in rows}
case_queries=['milostinja','poslednjom','tekbir']
H=lambda s:sha256(s.encode('utf8')).hexdigest()
result={'test':'Chromium DOM tests of exact generated self-contained reader; no file://, loopback or external URL navigations','browser':'/usr/bin/chromium','route':'about:blank with set_content exact generated HTML bytes','navigation':'NOT_TESTED; environment administrator blocks local navigations; did not attempt bypass','externalRequestsBlocked':[],'cases':[],'screenshots':[],'titleDiagnostic':None,'export':None}
def metrics(page):
 return page.evaluate('''() => ({width: window.innerWidth, documentWidth: document.documentElement.scrollWidth, clientWidth:document.documentElement.clientWidth, horizontalOverflowPx:Math.max(0, document.documentElement.scrollWidth-document.documentElement.clientWidth), brandText:document.querySelector('#brand-title')?.textContent || null, brandRight:Math.round(document.querySelector('#brand-title').getBoundingClientRect().right)})''')
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 for width in (390,1280):
  for case,(r,query) in enumerate(zip(rows,case_queries),1):
   ctx=browser.new_context(viewport={'width':width,'height':844 if width==390 else 900},accept_downloads=True)
   page=ctx.new_page();errors=[];console_errors=[];requested=[]
   page.on('pageerror',lambda e:errors.append(str(e)))
   page.on('console',lambda e:console_errors.append(e.text) if e.type=='error' else None)
   page.route('**/*',lambda route:(requested.append(route.request.url),route.abort()))
   page.set_content(html,wait_until='load',timeout=30000)
   at_open=metrics(page)
   assert page.locator('#brand-title').inner_text()=='Hadith Bank',at_open
   assert at_open['horizontalOverflowPx']==0,('initial header overflow',width,at_open)
   if width==390 and case==1:
    # Disposable DOM diagnostic with exactly the previous proof-only long catalog title.
    brand=page.locator('#brand-title')
    brand.evaluate("el => el.textContent='PRIVATE bounded adapter execution proof'")
    diagnostic=metrics(page)
    brand.evaluate("el => el.textContent='Hadith Bank'")
    restored=metrics(page)
    assert restored['horizontalOverflowPx']==0
    result['titleDiagnostic']={'originalActualTitleMetrics':at_open,'longProofTitleMetrics':diagnostic,'restoredActualTitleMetrics':restored,'disposableDOMOnly':True,'cssAndProductionSourceUnchanged':True}
   page.fill('#query',query);page.click('#run-search');page.wait_for_timeout(170)
   assert page.locator('article').count()==1,('search',case,width,page.locator('article').count(),page.locator('body').inner_text()[-600:])
   page.get_by_role('link',name='Open narration').first.click();page.wait_for_timeout(130)
   narration=page.locator('#narration-workspace p.narration[lang="bs"]')
   assert narration.count()==1
   body=narration.first.inner_text()
   assert body==r['text']['translation']
   text=page.locator('#narration-workspace').inner_text()
   assert 'Human translation' in text and 'Prof. Mahmut Karalić' in text
   assert 'Arabic · not yet available' in text and 'English · not yet available' in text
   assert '1 readings' in text and 'Collection number not supplied' in text
   assert len(errors)==0,(case,width,errors)
   after=metrics(page)
   assert after['horizontalOverflowPx']==0,(case,width,after)
   rec={'case':case,'widthPx':width,'query':query,'id':r['id'],'bodySHA256':H(body),'exactBody':True,'humanDisplay':True,'credit':True,'oneReadingOnly':True,'canonicalNumberAbsent':True,'metadataCounterpartsNotPresent':True,'metricsBefore':at_open,'metricsAfter':after,'pageErrors':errors,'consoleErrors':console_errors,'externalBlocked':requested[:5],'result':'PASS'}
   if width==390 and case==2:
    p=OUT/'reader-case2-mobile-390.png';page.screenshot(path=str(p),animations='disabled',full_page=False)
    result['screenshots'].append({'name':p.name,'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()})
   if width==1280 and case==2:
    page.get_by_text('Select',exact=True).last.click()
    button=page.get_by_role('button',name='Download selected JSON',exact=False)
    assert button.count()==1
    with page.expect_download(timeout=12000) as ev:button.click()
    d=ev.value; raw=Path(d.path()).read_bytes(); obj=json.loads(raw)
    assert len(obj)==1 and obj[0]['id']==r['id'] and obj[0]['text_translation']==r['text']['translation']
    assert obj[0]['translation_provenance']['origin']=='human_translator_credited' and obj[0]['ai_translation'] is False
    out=OUT/'reader-case2-selected-export.json';out.write_bytes(raw)
    result['export']={'selectedRecords':1,'jsonSha256':sha256(raw).hexdigest(),'bodySHA256':H(obj[0]['text_translation']),'origin':obj[0]['translation_provenance']['origin'],'historicalAI':obj[0]['ai_translation'],'file':out.name,'exact':True}
    p=OUT/'reader-case2-desktop-1280.png';page.screenshot(path=str(p),animations='disabled',full_page=False)
    result['screenshots'].append({'name':p.name,'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()})
   result['cases'].append(rec)
   ctx.close()
 browser.close()
(OUT/'BROWSER_DELTA_RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'browserCases':len(result['cases']),'header390':result['titleDiagnostic'],'selectedExportOrigin':result['export']['origin'],'browserErrors':sum(len(x['pageErrors']) for x in result['cases']),'overflow':sum(x['metricsAfter']['horizontalOverflowPx'] for x in result['cases']),'titleFix':'PASS','schemaUIDelta':'PASS'},ensure_ascii=False))
