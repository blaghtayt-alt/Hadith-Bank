from pathlib import Path
import json, hashlib, zipfile, difflib, copy
b=Path('/mnt/data/_bs_tirmidhi_enum_delta_work/input')
new_root=b/'successor-overlay'; name='bs-tirmidhi-karalic-v1-1999-8b62165c'
p=new_root/'materials'/name
old_bytes=(p/'evidence/records-before-origin-enum-v002.json').read_bytes()
new_bytes=(p/'records.json').read_bytes()
assert hashlib.sha256(old_bytes).hexdigest()=='3a3102e3d5263e5c58ac9df995c94d45c9979a1c1cae26d41f9585bf8f76b478'
assert hashlib.sha256(new_bytes).hexdigest()=='a838c90f33f7b84cc0bab29d16d720844b4ee8c76e113371358fe0cdd3e1ec8a'
with zipfile.ZipFile('/mnt/data/BS-TIRMIDHI-THREE-FINAL-ADAPTER-QC-001.zip') as z:
 old_prior=z.read('registered-private-fixture/materials/'+name+'/records.json')
 assert old_prior==old_bytes, 'old canonical does not match previous supplied adapter input'
 assert z.read('registered-private-fixture/materials/'+name+'/source.pdf')==Path('/mnt/data/_bs_tirmidhi_qc_input/source-volume1-original.pdf').read_bytes()
print('prior old records match: YES; PDF bytes match pinned original')
token1=b'"origin": "human"'; token2=b'"origin": "human_translator_credited"'
print('counts',old_bytes.count(token1),old_bytes.count(token2),new_bytes.count(token1),new_bytes.count(token2))
assert old_bytes.count(token1)==3 and old_bytes.count(token2)==0
assert new_bytes.count(token2)==3 and new_bytes.count(token1)==0
assert old_bytes.replace(token1,token2)==new_bytes
assert new_bytes.replace(token2,token1)==old_bytes
old=json.loads(old_bytes);new=json.loads(new_bytes)
assert len(old)==len(new)==3
expected=['ce92b74895cd46808a99e9db1f5bf5c7859e5aa8f6fa7bf0ab6093d49187e68f','4989c263b0a0a238baf946c0e45b89cd3f39c65624554738059b2c8effc247cd','3aa7bee2cafb7545a9fdd2414dd1cb780e0cf3a66446aa6942669f863274b15d']
for i,(a,z,h) in enumerate(zip(old,new,expected),1):
 assert a['id']==z['id']
 assert a['translation_provenance']['origin']=='human' and z['translation_provenance']['origin']=='human_translator_credited'
 test=copy.deepcopy(z);test['translation_provenance']['origin']='human'
 assert test==a
 body=z['text']['translation'];assert hashlib.sha256(body.encode('utf-8')).hexdigest()==h
 assert z['text']==a['text'] and z['source']==a['source'] and z['page']==a['page']
 assert z['number']==a['number'] and z['references']==a['references']
 print(f'case {i}: ONLY origin changed, body SHA {h}, flags ai_translation={z["ai_translation"]}, origin={z["translation_provenance"]["origin"]}, id={z["id"]}')

# cross-file fidelity. Note new overlay may contain only 3 changed fields plus regenerated hashes, beyond records.
mat=json.loads((p/'manifest.json').read_bytes())
assert mat['records']['sha256']==hashlib.sha256(new_bytes).hexdigest()
for field in mat['supporting_files']:
 f=new_root/field['path'];assert f.exists(),f
 assert hashlib.sha256(f.read_bytes()).hexdigest()==field['sha256'] and len(f.read_bytes())==field['size_bytes'], f
print('manifest supporting files PASS',len(mat['supporting_files']))
cat=json.loads((new_root/'catalog/materials.json').read_bytes()); print('private title',cat['title']);assert cat['title']=='Hadith Bank'
assert cat['record_count']==3 and len(cat['materials'])==1
assert cat['materials'][0]['canonical_records_sha256']==hashlib.sha256(new_bytes).hexdigest()
assert cat['materials'][0]['translation_provenance']['origin']=='human_translator_credited'
schema=json.loads((b/'actual-code/schemas/search.record.schema.json').read_bytes())
print('schema origin:',schema.get('properties',{}).get('translation_provenance'))
print('SOURCE BODY AND FIELDS PASS')
