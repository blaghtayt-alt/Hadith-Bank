# BS-TIRMIDHI-1-3-INDEPENDENT-QC-001 — frozen source-first review

## Final verdict

**Input integrity: PASS. Independent source-fidelity decisions: #1 PASS, #2 HOLD, #3 PASS.** There is one clearly visible frozen-candidate matn spelling deviation; no candidate was changed, and no publication, repo change, or canonical identity claim was made.

| Frozen candidate | Bosnian narration pages (physical / printed) | Source-text decision | Finding |
|---|---|---|---|
| 1 | PDF pp63–64 / print pp59–60 | **PASS** | Heading, both chain branches, Ibn Omera, and full matn match; `milostinja sadaka` is actually printed. Hennad alternative and Ebu Isa assessment are separately categorized, and superscript notes stay archival. |
| 2 | PDF pp65–66 / print pp61–62 | **HOLD** | The second occurrence at PDF p66 prints `poslednjom` (without `j` after `l`); frozen matn and raw segment both say `posljednjom`. The earlier occurrence on the same page *does* read `posljednjom` and must remain. The narrative/footnote boundary and narrator Ebu Hurejre are otherwise correct. |
| 3 | PDF p69 / print p65 | **PASS** | Heading, both chain branches, Alije, and full matn match, including `njegov (početak) kojim mnoge radnje bivaju zabranjene`. Printed commentary starts after `selam.` and continues p70; it is not part of the reader matn. |

## Verified integrity, source, and boundaries

- Exact input ZIP: 22,802,659 bytes; SHA-256 `85dbb16f7169f4ddeb9be22928950c616ffb559429238a1eb122e09cddba5e3d`; CRC PASS; all **18 of 18** current manifest payloads matched SHA-256 and byte lengths.
- Original unchanged volume-1 PDF inside packet: 21,099,408 bytes; SHA-256 `8b62165c8b1f79fbeb70e0e24afc751c45fadc24dcaee18ae7ec255926221bc2`; 528 physical pages. Source PDF rather than candidate, OCR or evidence JPEG was used as final visual authority.
- Parent-v3 manifest has 78 listed outputs; only **5 exact included corresponding payloads** can be independently re-verified from this narrow packet, and all five matched. The remaining 73 records are **not reverified** here. Other volumes are not present and outside scope.
- Physical p3 verifies `TIRMIZIJIN DŽAMI'-SUNEN / TIRMIZIJINA ZBIRKA HADISA`, `PRVA KNJIGA`, `PRVO IZDANJE`, `PROF. MAHMUT KARALIĆ`, `Zenica, 1999`. Physical p2 provides series CIP `Travnik, 1999`; it is not substituted for the volume title-page city. Physical p63 reads `POGLAVLJA O ČISTOĆI`.
- Pages visually inspected: physical pp2, 3, 62–70. Exact Bosnian narration spans p63→64, p65→66, p69. Nearby p62 and p68 Arabic, as well as footnotes, commentary and p70 next chapter, were only examined for boundaries—not separately transcribed.

## Case 1 — PASS, physical p63 (print 59) through p64 (print 60)

The printed heading is `1. Namaz neće biti primljen bez (propisne) čistoće`. p63 contains the Kutejbe / Ebu Avane / Simak beginning with three note markers; p64 continues with `ISPRIČAO NAM JE Hennad`, Veki', Israil, Musa'ba b. Sa'da, Ibn Omera and the quotation. The complete Bosnian matn is source-consistent; specifically, the apparently odd `milostinja sadaka` is printed and must **not** be corrected. The separate sentence `U hadisu koji prenosi Hennad stoji: ...` and `Ebu Isa kaže: ...` follow the main matn and are not appended to the candidate reader narration. Original footnote superscripts were deliberately excluded from the reader fields as allowed. No concrete omitted or substituted Bosnian matn words identified.

## Case 2 — HOLD, physical p65 (print 61) through p66 (print 62)

The printed heading is `2. O vrijednostima čišćenja`. The two branches through Malik and Suhejl, the narrator Ebu Hurejre, and the start of the quoted Bosnian hadith agree with the frozen candidate. At the printed page break the last word of p65 is `zajedno`, and p66 continues `s vodom ili sa posljednjom kapi vode` — that FIRST occurrence is correctly transcribed. Several lines later p66 prints `svaki grijeh uporedo sa vodom ili **poslednjom** kapi vode`; the current frozen `matn_bosnian_exact_reading` and `raw_bosnian_transcribed_segment` both wrongly write `posljednjom` for this SECOND occurrence. This is a verified source character difference, not permission to rewrite or modernize either occurrence.

**Proposed correction, not applied:** in both specified fields, change only the substring `uporedo sa vodom ili posljednjom kapi vode` to `uporedo sa vodom ili poslednjom kapi vode`, after human confirmation of original PDF physical p66, printed p62, fourth matn line. No other candidate wording should be changed on this record. Source and frozen candidate files remain unchanged. The Ebu Isa assessment on p66 and subsequent transmitter/biography notes pp67–68 were correctly separated; exclusion of their full text is not the hold reason.

*Editorial uncertainty warning (not part of any hadith):* **OCR wasnt clear.** The scanned pages' text layer is unreliable. The second spelling is legible in the original PDF render and has high-confidence independent visual support; human confirmation should precede any owner-approved patch. Apostrophe codepoints (e.g. `mu’min`) cannot be verified as specific Unicode characters from ink alone; no invented normalization is justified.

## Case 3 — PASS, physical p69 (print 65), context p68 and p70

The heading `3. Ključ namaza je čišćenje`, both Kutejbe/Hennad/Mahmud and Muhammed b. Beššar chain branches, the `Alije` attribution, and all Bosnian matn words match the printed original. Preserve `njegov (početak) kojim mnoge radnje bivaju zabranjene`: the unusual source syntax is not an error to be harmonized. The printed matn ends `selam.` on p69, then `Ebu Isa veli` introduces assessment/context and a note on the same page. Context on p70 is not missing hadith text. The auxiliary `tirmidhi_assessment_separate` field is an excerpt, **not** a certified diplomatic reproduction of all quotation punctuation or subsequent assessment on p70; there is no independent source-matn hold on that basis.

## Unknowns and gates retained

- The printed *local* source report numbers 1, 2 and 3, narration beginnings, and pages were seen directly. The archival `chain_bosnian_transcription_omitting_footnote_marks` and `raw_bosnian_transcribed_segment` strings still begin with `1.`/`2.`/`3.`; the explicit `source_printed_hadith_number_internal_only` field is separate. **Reader projection removal of these archival prefixes was not tested** because no reader code/display candidate was included. This does **not** independently certify cross-edition identity, external URLs, Arabic concordance, or number-only matching. External reference statements in the frozen producer data remain historical self-checks, not the independent result here.
- This review does not establish complete coverage of the volume, seven-volume completeness, rights, publisher-master byte equivalence, general overlap, provenance of any external witness, or release eligibility. Rights, overlap, integration, ownership and publication holds remain unchanged.
- No candidate rewrites, OCR-generated replacements, AI translations, source transformations, public writes, or broader-book assessment. The exact frozen input remains preserved in the original attached ZIP. Each separately saved case checkpoint and the precise source-image crop mapping accompany `RESULT.json`.
