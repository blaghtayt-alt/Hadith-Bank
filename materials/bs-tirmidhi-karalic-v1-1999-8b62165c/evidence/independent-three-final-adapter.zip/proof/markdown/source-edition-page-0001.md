# bs / جامع الترمذي — Jami al-Tirmidhi

Edition: `bs-karalic-first-edition-volume-1-1999` · Narrations 1–3 of 3.

[Edition index](README.md)

## Narration 1

[Open this narration online](https://blaghtayt-alt.github.io/Hadith-Bank/hadith/bs/tirmidhi/bs-karalic-first-edition-volume-1-1999/f73fac2d70e7cc36bf1842f0.html)

<p dir="auto"><strong>Namaz neće biti primljen bez (propisne) čistoće</strong></p>

<p><strong>Hadith</strong> · A narration preserved from the source.</p>

<section class="language-reading" lang="bs">
<h3>bs</h3>

<p dir="auto">ISPRIČAO NAM JE Kutejbe b. Seid; kaže: Nama je ispričao Ebu Avane, on je prenio od Simaka b. Harba (h) ISPRIČAO NAM JE Hennad; kaže: Nama je ispričao Veki&#x27;, prenijevši od Israila, on od Simaka, on od Musa&#x27;ba b. Sa&#x27;da, on od Ibn Omera, a on od Vjerovjesnika, Allah ga blagoslovio i spasio, da je kazao: “Namaz neće biti primljen bez (propisne) čistoće, niti će biti primljena milostinja sadaka (koja se podijeli) iz nepošteno stečene imovine.”</p>

<p dir="auto">[جامع الترمذي — Jami al-Tirmidhi · hadith number not supplied]</p>

<p><strong>Source:</strong> <a href="https://www.islamland.com/uploads/books/53fb0782-dff0-490a-ad4d-1141b8adb1fd-bs_Sunen_Tirmizi_crno_bijelo_1.pdf" target="_blank" rel="noopener noreferrer">Tirmizijin Džami&#x27;-Sunen / Tirmizijina zbirka hadisa</a> · Translation origin: Human</p>

</section>

<p><strong>Source:</strong> <a href="https://www.islamland.com/uploads/books/53fb0782-dff0-490a-ad4d-1141b8adb1fd-bs_Sunen_Tirmizi_crno_bijelo_1.pdf">Tirmizijin Džami&#x27;-Sunen / Tirmizijina zbirka hadisa</a><br>
<strong>Collection:</strong> جامع الترمذي — Jami al-Tirmidhi · <strong>Edition:</strong> bs-karalic-first-edition-volume-1-1999<br>
<strong>Number:</strong> Collection number not supplied<br>
<strong>Page:</strong> PDF page 63, 64 · Printed page 59, 60<br>
<strong>Translator:</strong> Prof. Mahmut Karalić<br>
<strong>Narrator:</strong> Ibn Omera<br>
<strong>Translation origin:</strong> Human</p>

<details><summary>Source translation-origin history</summary>

<p dir="auto">Preserved source label: Source attribution supplied</p>
<p dir="auto">Preserved source AI-translation flag: False</p>
<p dir="auto">Original source metadata is preserved; current translation classification follows the recorded provenance evidence and owner policy.</p>

</details>

<details><summary>Original import and review history</summary>

<p>Historical import status: bounded_source_fidelity_pass_final_adapter_pending · Historical independent Pro QC: passed_bounded_source_only_final_adapter_pending · Release: private_candidate</p>

<p dir="auto">No source-alignment issues listed.</p>

</details>

<details>
<summary>References</summary>

<p><strong>reason</strong></p>
<p dir="auto">Producer Arabic/concordance self-checks remain archived, not independent narrationANDvariantidentity proof. Printed source numbers deliberately omitted from reading metadata.</p>

</details>

<details>
<summary>Narrator and supplied tags</summary>

<pre>{&quot;narrator&quot;:{&quot;name&quot;:&quot;Ibn Omera&quot;},&quot;topic_tags&quot;:[],&quot;editorial_tags&quot;:[]}</pre>

</details>

<details>
<summary>Source locators and review issues</summary>

<p><strong>Occurrence ID:</strong> <code>bs-tirmidhi-karalic-v01-0001-source-sha-8b62165c8b1f</code><br><strong>Canonical record:</strong> <a href="../../../../fixture/materials/bs-tirmidhi-karalic-v1-1999-8b62165c/records.json">materials/bs-tirmidhi-karalic-v1-1999-8b62165c/records.json</a><br><strong>JSON pointer:</strong> <code>/0</code><br><strong>Original file:</strong> <a href="../../../../fixture/materials/bs-tirmidhi-karalic-v1-1999-8b62165c/source.pdf">materials/bs-tirmidhi-karalic-v1-1999-8b62165c/source.pdf</a><br><strong>Original SHA-256:</strong> <code>8b62165c8b1f79fbeb70e0e24afc751c45fadc24dcaee18ae7ec255926221bc2</code></p><p><a href="https://github.com/blaghtayt-alt/Hadith-Bank/raw/main/materials/bs-tirmidhi-karalic-v1-1999-8b62165c/source.pdf">Download PDF</a></p>

<p><strong>Review issues:</strong></p>
<p dir="auto">None listed in this record.</p>

</details>

---

## Narration 2

[Open this narration online](https://blaghtayt-alt.github.io/Hadith-Bank/hadith/bs/tirmidhi/bs-karalic-first-edition-volume-1-1999/1752c5c8d3221f8e7ff734bc.html)

<p dir="auto"><strong>O vrijednostima čišćenja</strong></p>

<p><strong>Hadith</strong> · A narration preserved from the source.</p>

<section class="language-reading" lang="bs">
<h3>bs</h3>

<p dir="auto">ISPRIČAO NAM JE Ishak b. Musa el-Ensari; kaže: Nama je ispričao Ma&#x27;n b. Isa el-Kazazi; kaže: Nama je ispričao Malik b. Enes (h) ISPRIČAO NAM JE Kutejbe, prenijevši od Malika, on od Suhejla b. Ebu Saliha, a on od Ebu Hurejre, koji je kazao da je Allahov Poslanik, Allah ga blagoslovio i spasio, rekao: “Kada rob musliman, ili (je kazao): mu’min, uzimajući abdest opere svoje lice, iz njegova lica zajedno s vodom ili sa posljednjom kapi vode, izađe svaki grijeh koji je počinio pogledom (svojih očiju) ili je rekao slično tome. A kada opere svoje ruke, iz njegovih ruku izađe svaki grijeh uporedo sa vodom ili poslednjom kapi vode, koje je njima (rukama) počinio, tako da (poslije abdesta) ostane potpuno čist od grijeha.”</p>

<p dir="auto">[جامع الترمذي — Jami al-Tirmidhi · hadith number not supplied]</p>

<p><strong>Source:</strong> <a href="https://www.islamland.com/uploads/books/53fb0782-dff0-490a-ad4d-1141b8adb1fd-bs_Sunen_Tirmizi_crno_bijelo_1.pdf" target="_blank" rel="noopener noreferrer">Tirmizijin Džami&#x27;-Sunen / Tirmizijina zbirka hadisa</a> · Translation origin: Human</p>

</section>

<p><strong>Source:</strong> <a href="https://www.islamland.com/uploads/books/53fb0782-dff0-490a-ad4d-1141b8adb1fd-bs_Sunen_Tirmizi_crno_bijelo_1.pdf">Tirmizijin Džami&#x27;-Sunen / Tirmizijina zbirka hadisa</a><br>
<strong>Collection:</strong> جامع الترمذي — Jami al-Tirmidhi · <strong>Edition:</strong> bs-karalic-first-edition-volume-1-1999<br>
<strong>Number:</strong> Collection number not supplied<br>
<strong>Page:</strong> PDF page 65, 66 · Printed page 61, 62<br>
<strong>Translator:</strong> Prof. Mahmut Karalić<br>
<strong>Narrator:</strong> Ebu Hurejre<br>
<strong>Translation origin:</strong> Human</p>

<details><summary>Source translation-origin history</summary>

<p dir="auto">Preserved source label: Source attribution supplied</p>
<p dir="auto">Preserved source AI-translation flag: False</p>
<p dir="auto">Original source metadata is preserved; current translation classification follows the recorded provenance evidence and owner policy.</p>

</details>

<details><summary>Original import and review history</summary>

<p>Historical import status: bounded_source_fidelity_pass_final_adapter_pending · Historical independent Pro QC: passed_bounded_source_only_final_adapter_pending · Release: private_candidate</p>

<p dir="auto">No source-alignment issues listed.</p>

</details>

<details>
<summary>References</summary>

<p><strong>reason</strong></p>
<p dir="auto">Producer Arabic/concordance self-checks remain archived, not independent narrationANDvariantidentity proof. Printed source numbers deliberately omitted from reading metadata.</p>

</details>

<details>
<summary>Narrator and supplied tags</summary>

<pre>{&quot;narrator&quot;:{&quot;name&quot;:&quot;Ebu Hurejre&quot;},&quot;topic_tags&quot;:[],&quot;editorial_tags&quot;:[]}</pre>

</details>

<details>
<summary>Source locators and review issues</summary>

<p><strong>Occurrence ID:</strong> <code>bs-tirmidhi-karalic-v01-0002-source-sha-8b62165c8b1f</code><br><strong>Canonical record:</strong> <a href="../../../../fixture/materials/bs-tirmidhi-karalic-v1-1999-8b62165c/records.json">materials/bs-tirmidhi-karalic-v1-1999-8b62165c/records.json</a><br><strong>JSON pointer:</strong> <code>/1</code><br><strong>Original file:</strong> <a href="../../../../fixture/materials/bs-tirmidhi-karalic-v1-1999-8b62165c/source.pdf">materials/bs-tirmidhi-karalic-v1-1999-8b62165c/source.pdf</a><br><strong>Original SHA-256:</strong> <code>8b62165c8b1f79fbeb70e0e24afc751c45fadc24dcaee18ae7ec255926221bc2</code></p><p><a href="https://github.com/blaghtayt-alt/Hadith-Bank/raw/main/materials/bs-tirmidhi-karalic-v1-1999-8b62165c/source.pdf">Download PDF</a></p>

<p><strong>Review issues:</strong></p>
<p dir="auto">None listed in this record.</p>

</details>

---

## Narration 3

[Open this narration online](https://blaghtayt-alt.github.io/Hadith-Bank/hadith/bs/tirmidhi/bs-karalic-first-edition-volume-1-1999/8565be33c88803e9b499ac5d.html)

<p dir="auto"><strong>Ključ namaza je čišćenje</strong></p>

<p><strong>Hadith</strong> · A narration preserved from the source.</p>

<section class="language-reading" lang="bs">
<h3>bs</h3>

<p dir="auto">ISPRIČALI SU NAM Kutejbe, Hennad i Mahmud b. Gajlan; kažu: Nama je ispričao Veki&#x27; prenijevši od Sufjana (h) ISPRIČAO NAM JE Muhammed b. Beššar; kaže: Nama je ispričao Abdur-Rahman b. Mehdi; kaže: Nama je ispričao Sufjan prenijevši od Abdullaha b. Muhammeda b. Akila, on od Muhammeda b. el-Hanefijja, on od Alije, a on od Vjerovjesnika, Allah ga blagoslovio i spasio, da je rekao: “Ključ namaza je čišćenje, njegov (početak) kojim mnoge radnje bivaju zabranjene je početni tekbir, a njegov završetak je selam.”</p>

<p dir="auto">[جامع الترمذي — Jami al-Tirmidhi · hadith number not supplied]</p>

<p><strong>Source:</strong> <a href="https://www.islamland.com/uploads/books/53fb0782-dff0-490a-ad4d-1141b8adb1fd-bs_Sunen_Tirmizi_crno_bijelo_1.pdf" target="_blank" rel="noopener noreferrer">Tirmizijin Džami&#x27;-Sunen / Tirmizijina zbirka hadisa</a> · Translation origin: Human</p>

</section>

<p><strong>Source:</strong> <a href="https://www.islamland.com/uploads/books/53fb0782-dff0-490a-ad4d-1141b8adb1fd-bs_Sunen_Tirmizi_crno_bijelo_1.pdf">Tirmizijin Džami&#x27;-Sunen / Tirmizijina zbirka hadisa</a><br>
<strong>Collection:</strong> جامع الترمذي — Jami al-Tirmidhi · <strong>Edition:</strong> bs-karalic-first-edition-volume-1-1999<br>
<strong>Number:</strong> Collection number not supplied<br>
<strong>Page:</strong> PDF page 69 · Printed page 65<br>
<strong>Translator:</strong> Prof. Mahmut Karalić<br>
<strong>Narrator:</strong> Alije<br>
<strong>Translation origin:</strong> Human</p>

<details><summary>Source translation-origin history</summary>

<p dir="auto">Preserved source label: Source attribution supplied</p>
<p dir="auto">Preserved source AI-translation flag: False</p>
<p dir="auto">Original source metadata is preserved; current translation classification follows the recorded provenance evidence and owner policy.</p>

</details>

<details><summary>Original import and review history</summary>

<p>Historical import status: bounded_source_fidelity_pass_final_adapter_pending · Historical independent Pro QC: passed_bounded_source_only_final_adapter_pending · Release: private_candidate</p>

<p dir="auto">No source-alignment issues listed.</p>

</details>

<details>
<summary>References</summary>

<p><strong>reason</strong></p>
<p dir="auto">Producer Arabic/concordance self-checks remain archived, not independent narrationANDvariantidentity proof. Printed source numbers deliberately omitted from reading metadata.</p>

</details>

<details>
<summary>Narrator and supplied tags</summary>

<pre>{&quot;narrator&quot;:{&quot;name&quot;:&quot;Alije&quot;},&quot;topic_tags&quot;:[],&quot;editorial_tags&quot;:[]}</pre>

</details>

<details>
<summary>Source locators and review issues</summary>

<p><strong>Occurrence ID:</strong> <code>bs-tirmidhi-karalic-v01-0003-source-sha-8b62165c8b1f</code><br><strong>Canonical record:</strong> <a href="../../../../fixture/materials/bs-tirmidhi-karalic-v1-1999-8b62165c/records.json">materials/bs-tirmidhi-karalic-v1-1999-8b62165c/records.json</a><br><strong>JSON pointer:</strong> <code>/2</code><br><strong>Original file:</strong> <a href="../../../../fixture/materials/bs-tirmidhi-karalic-v1-1999-8b62165c/source.pdf">materials/bs-tirmidhi-karalic-v1-1999-8b62165c/source.pdf</a><br><strong>Original SHA-256:</strong> <code>8b62165c8b1f79fbeb70e0e24afc751c45fadc24dcaee18ae7ec255926221bc2</code></p><p><a href="https://github.com/blaghtayt-alt/Hadith-Bank/raw/main/materials/bs-tirmidhi-karalic-v1-1999-8b62165c/source.pdf">Download PDF</a></p>

<p><strong>Review issues:</strong></p>
<p dir="auto">None listed in this record.</p>

</details>

---


[Edition index](README.md)
