#!/usr/bin/env python3
"""Independent read-only, three-record final adapter projection verification.
Runs against the extracted, cryptographically pinned user packet and its separate
actual-adapter execution. Does not mutate either input or production code.
"""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json, zipfile, sys, re, html
from bs4 import BeautifulSoup
from jsonschema import Draft202012Validator

INPUT = Path('/mnt/data/_bs_tirmidhi_adapter_qc/input')
OUTPUT = INPUT/'execution-independent'
REPORT = Path('/mnt/data/BS-TIRMIDHI-THREE-FINAL-ADAPTER-QC-001-RESULT/logs')
SOURCEZIP=Path('/mnt/data/BS-TIRMIDHI-THREE-FINAL-ADAPTER-QC-001.zip')
PREFIX='registered-private-fixture/materials/bs-tirmidhi-karalic-v1-1999-8b62165c/'
DIGEST=lambda b:sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
result={'scope':'three Bosnian Karalić volume1 registered source occurrences only','routes':{},'per_case':[],'input_hashes':{},'code_hashes':{},'generated_artifacts':{},'notes':[]}

assert SOURCEZIP.stat().st_size==22230679
assert DIGEST(SOURCEZIP.read_bytes())=='a71e20e49274c1e2175c65ec60767a5910e0ad18f09dd0c3bf79d0d77409f13a'
with zipfile.ZipFile(SOURCEZIP) as z:
 assert z.testzip() is None
 m=json.loads(z.read('MANIFEST.json')); entries=m['payloads']; names=set(z.namelist())
 assert len(entries)==237 and len(names)==238 and set(e['path'] for e in entries)==names-{'MANIFEST.json'}
 for e in entries:
  b=z.read(e['path']); assert DIGEST(b)==e['sha256'] and len(b)==e['bytes'],e['path']
  assert DIGEST((INPUT/e['path']).read_bytes())==e['sha256'],('mutated input',e['path'])
result['routes']['input_integrity']='PASS 237/237 payload size/SHA and ZIP CRC; extracted inputs unchanged'
result['input_hashes']['packet']=DIGEST(SOURCEZIP.read_bytes())
manifest=load(INPUT/PREFIX/'manifest.json');records=load(INPUT/PREFIX/'records.json');raw=[json.loads(x) for x in (INPUT/'closed-evidence/exact-source-successor-candidates-1-3.jsonl').read_text().splitlines()]
bindings=load(INPUT/PREFIX/'evidence/source-body-bindings.json')
provenance=load(INPUT/'registered-private-fixture/catalog/provenance-policy.json')
review=load(INPUT/PREFIX/'evidence/current-private-scoped-review.json')
prior=load(INPUT/'closed-evidence/bosnian-tirmidhi-source-passed-three-private-stage-v002.json')
target=load(INPUT/'TARGET.json')
assert target['records']==3 and target['language']=='bs' and target['historicalAI'] is False and target['historicalOrigin']=='human'
assert len(records)==len(raw)==len(bindings)==3 and len({r['id'] for r in records})==3
for path,expect in [
 (PREFIX+'records.json','3a3102e3d5263e5c58ac9df995c94d45c9979a1c1cae26d41f9585bf8f76b478'),
 (PREFIX+'manifest.json','a2f92acb8afa66d0d9c84889295006ed03734ddecc8de8c8f1c157c173a6a5cb'),
 (PREFIX+'source.pdf','8b62165c8b1f79fbeb70e0e24afc751c45fadc24dcaee18ae7ec255926221bc2'),
 ('closed-evidence/exact-source-successor-candidates-1-3.jsonl','531c10a2068d366e0b3d44c6abcd5bc882afaf8918f53e697664b99481a22ed0'),
 ('closed-evidence/BS-TIRMIDHI-H2-SPELLING-DELTA-QC-001-RESULT.zip','12f27d2f8f0a14c07597d9600107da2a3cdae2b96a7065a65a0c1dce521442b7'),
]:
 actual=DIGEST((INPUT/path).read_bytes());assert actual==expect,path
 result['input_hashes'][path]=actual
with zipfile.ZipFile(INPUT/'closed-evidence/BS-TIRMIDHI-H2-SPELLING-DELTA-QC-001-RESULT.zip') as z:
 assert z.testzip() is None
 assert len(z.namelist())==6
result['routes']['embedded_prior_delta_archive']='PASS exact pinned prior QC ZIP and CRC'
assert prior['exactSuccessorAccepted']==result['input_hashes']['closed-evidence/exact-source-successor-candidates-1-3.jsonl']
assert manifest['records']['count']==3 and manifest['counterpart_policy']['mode']=='disabled'
assert manifest['publication']['certified_release_eligible'] is False and manifest['publication']['rights_clearance_asserted'] is False
assert manifest['current_scoped_review']['final_adapter']=='PENDING'
assert manifest['source']['translator']=='Prof. Mahmut Karalić' and manifest['source']['volume']==1 and manifest['source']['edition_year']==1999
assert manifest['source']['pdf_pages']==528
assert review['records_sha256']==result['input_hashes'][PREFIX+'records.json']
for file_name, schema_name, arr in [('material-manifest.schema.json','material manifest',[manifest]),('material-record.schema.json','material record',records)]:
 schema=load(INPUT/'actual-code/schemas'/file_name);v=Draft202012Validator(schema)
 for i,r in enumerate(arr):
  issues=list(v.iter_errors(r));assert not issues,(schema_name,i,[(str(x)[:600]) for x in issues[:4]])
result['routes']['schema_manifest_and_records']='PASS material manifest and all 3 material records; schema files exact from code snapshot'
raw_map={s['source_occurrence_id'] if 'source_occurrence_id' in s else s.get('candidate_id') or s.get('occurrence_id') or s.get('id'):s for s in raw}
# Source row identifiers are captured in the registration table, but raw candidate IDs use another key.
if None in raw_map:
 raw_map={records[i]['id']:raw[i] for i in range(3)}
binding_map={b['id']:b for b in bindings}
assert len(binding_map)==3
stream_path=OUTPUT/'fixture/search/records.jsonl';projected=[json.loads(line) for line in stream_path.read_text().splitlines()]
assert len(projected)==3
projected_map={r['id']:r for r in projected}
assert set(projected_map)=={r['id'] for r in records}
proj_schema=load(INPUT/'actual-code/schemas/search.record.schema.json');proj_validator=Draft202012Validator(proj_schema)
schema_issues=[]
for i,p in enumerate(projected):
 issues=list(proj_validator.iter_errors(p))
 for issue in issues:
  schema_issues.append({'case':i+1,'record_id':p['id'],'instance_path':'/'+ '/'.join(map(str,issue.path)),'schema_path':'/'+ '/'.join(map(str,issue.schema_path)),'actual_value':issue.instance,'message':issue.message})
result['projected_schema_issues']=schema_issues
result['routes']['schema_projected_records']=('HOLD: ' + str(len(schema_issues)) + ' JSON Schema errors; `translation_provenance.origin=human` not allowed by pinned search schema' if schema_issues else 'PASS all 3 actual search records')

static_pages={}
for file in (OUTPUT/'static/hadith').rglob('*.html'):
 page=BeautifulSoup(file.read_text(encoding='utf-8'),'html.parser')
 json_ld=json.loads(page.select_one('script[type="application/ld+json"]').string)
 rid=json_ld['mainEntity']['identifier']['value']
 assert rid not in static_pages
 static_pages[rid]=(file,page)
assert len(static_pages)==3
md_path=next((OUTPUT/'markdown/bs/tirmidhi').rglob('page-*.md'))
md_data=md_path.read_text(encoding='utf-8'); md_soup=BeautifulSoup(md_data,'html.parser')
md_texts=[p.get_text() for section in md_soup.select('section.language-reading') for p in section.select('p[dir="auto"]')]
# markdown reader also embeds citation p[dir=auto]; first item per section is the body.
md_texts=[]
for section in md_soup.select('section.language-reading'):
 p=section.select_one('p[dir="auto"]');assert p;md_texts.append(p.get_text())
assert len(md_texts)==3
case_hashes=['ce92b74895cd46808a99e9db1f5bf5c7859e5aa8f6fa7bf0ab6093d49187e68f','4989c263b0a0a238baf946c0e45b89cd3f39c65624554738059b2c8effc247cd','3aa7bee2cafb7545a9fdd2414dd1cb780e0cf3a66446aa6942669f863274b15d']
for i,row in enumerate(records):
 rid=row['id']; b=binding_map[rid]; cand=raw[i]; p=projected_map[rid]; static_file,static_page=static_pages[rid]
 raw_string=cand['raw_bosnian_transcribed_segment']; span=b['selectedCodepointSpan']; prefix=f'{i+1}. '
 body=raw_string[span[0]:span[1]]; expected=row['text']['translation']
 assert raw_string.startswith(prefix) and span==[len(prefix),len(raw_string)] and body==expected
 assert DIGEST(raw_string.encode())==b['sourceFieldSHA256']==row['extraction']['raw_source_field_sha256']
 assert DIGEST(expected.encode())==b['bodySHA256']==case_hashes[i]==review['body_sha256'][rid]
 assert p['id']==rid and p['text_translation']==expected and DIGEST(p['text_translation'].encode())==case_hashes[i]
 assert row['source']['sha256']==manifest['source']['sha256'] and p['page']==row['page']
 assert row['page']['pdf']==([63,64] if i==0 else [65,66] if i==1 else [69])
 assert row['page']['printed']==([59,60] if i==0 else [61,62] if i==1 else [65])
 assert row['title']['arabic'] is None and row['commentary']=={'arabic':None,'translation':None} and row['footnotes']==[]
 assert row['text']['arabic'] is None and p['text_arabic'] is None
 assert row['ai_translation'] is False and p['ai_translation'] is False
 assert row['translation_provenance']['origin']==p['translation_provenance']['origin']=='human'
 assert row['translator']['name']==p['translator']['name']=='Prof. Mahmut Karalić'
 assert row['number']=={'source_entry_id':None,'in_book':None,'canonical':None} and p['number']==row['number']
 assert row['references']['items']==[] and row['references']['canonical'] is None and row['references']['counterpart_verified'] is False
 assert not row['related_versions'] and not row['topic_tags']
 assert p['counterpart_policy']['mode']=='disabled' and not p.get('language_versions')
 assert row['review']['release_status']=='private_candidate' and row['review']['release_eligible'] is False
 assert row['review']['certified_release_eligible'] is False and row['rights']['status']=='not_assessed_for_publication'
 assert row['extraction']['source_prefix_removed_from_reading'] and row['extraction']['selected_codepoint_span']==span
 assert row['id'] in review['body_sha256'] and p['source_id']==manifest['source_id']
 sections=static_page.select('details.language-reading');assert len(sections)==1
 ps=sections[0].select('div.text.quotation[lang="bs"]'); assert ps and ps[0].get_text()==expected
 assert 'Translation origin: Human' in static_page.get_text(' ',strip=True)
 assert 'Prof. Mahmut Karalić' in static_page.get_text(' ',strip=True)
 assert expected==md_texts[i]
 assert static_page.find('main') and static_page.select_one('script[type="application/ld+json"]')
 assert 'Collection number not supplied' in static_page.get_text(' ',strip=True)
 assert 'Arabic' not in ''.join(section.get('lang','') for section in sections)
 assert (i!=1 or ('sa posljednjom kapi vode' in body and 'ili poslednjom kapi vode' in body))
 assert b.get('sourceQCVerdict','').startswith('PASS')
 result['per_case'].append({'case':i+1,'id':rid,'verdict':'PASS','body_codepoints':len(expected),'body_sha256':DIGEST(expected.encode()),'raw_source_field_sha256':DIGEST(raw_string.encode()),'selected_codepoint_span':span,'excluded_prefix':prefix,'pdf_pages':row['page']['pdf'],'printed_pages':row['page']['printed'],'static_record':str(static_file.relative_to(OUTPUT)),'static_body_matches':True,'markdown_body_matches':True,'reader_stream_body_matches':True,'provenance_human':True,'historical_ai_false':True,'translator':'Prof. Mahmut Karalić','numbers_empty':True,'counterparts_disabled':True,'release_eligible':False})
result['routes']['canonical_raw_span_bindings']='PASS 3/3 exactly raw[3:] — no text, chain or punctuation changes'
result['routes']['metadata_and_separation']='PASS 3/3 chain retained, human/credit, no canonical numbers/Arabic/commentary/counterpart projection, release gates intact'
result['routes']['static_pages']='PASS 3/3 exact full Bosnian body via static HTML, correct identity/Human/credit metadata'
result['routes']['markdown']='PASS 3/3 exact full bodies in generated Markdown plus edition/index files'
result['routes']['search_jsonl']='PASS 3/3 projected bodies unchanged, metadata present; separate search-schema enum HOLD remains'

run=load(OUTPUT/'RESULT.json')
assert run['records']==3 and run['reader']['record_count']==3 and run['static']['record_pages']==3 and run['markdownFiles']==5
assert run['reader']['grouped_reading_count']==3 and run['reader']['source_text_modified'] is False
assert run['static']['source_texts_unchanged'] is True and run['static']['languages']=={'bs':3}
assert run['reader']['network_dependencies']==[] and run['reader']['self_contained'] is True
assert run['publicWrite'] is False and run['sourceReviewRepeated'] is False
assert run['reader']['records_sha256']==DIGEST(stream_path.read_bytes())==run['static']['source_records_sha256']
result['routes']['actual_adapter_execution']='PASS loader, round trip, self-contained full-reader, static, Markdown; 3 records'
result['input_hashes']['generated_search_records_jsonl']=DIGEST(stream_path.read_bytes())
for name in ['material_registry.py','build_reader.py','build_discovery.py','current_provenance.py','language_display.py','source_glyphs.py','review_display_policy.py']:
 f=INPUT/'actual-code/scripts'/name
 result['code_hashes'][name]=DIGEST(f.read_bytes())
result['code_hashes']['run_actual_adapters.py']=DIGEST((INPUT/'run_actual_adapters.py').read_bytes())
result['code_hashes']['reader/template.html']=DIGEST((INPUT/'actual-code/reader/template.html').read_bytes())
result['code_hashes']['reader/reading-room.css']=DIGEST((INPUT/'actual-code/reader/reading-room.css').read_bytes())
result['code_hashes']['code_snapshot_payload_count']=sum(e['path'].startswith('actual-code/') for e in entries)
for f in sorted(OUTPUT.rglob('*')):
 if f.is_file() and f.suffix not in ['.png']:
  result['generated_artifacts'][str(f.relative_to(OUTPUT))]={'sha256':DIGEST(f.read_bytes()),'bytes':f.stat().st_size}
result['notes']=[
 'Initial source1&3 and exact case2 spelling-delta reviews remain closed; no source PDF page was reopened.',
 'Prior case1&3 exact historical canonical-object equality is asserted in supplied scoped-stage evidence; this check independently verifies current body/raw spans, metadata and pinned stage hashes, not an unavailable earlier canonical snapshot.',
 'Offline generated links use production-template base paths; deployment/navigation and external repository URLs are not checked in this private packet.',
 'No full-collection, rights, narration-variant-identity, live-site or merged-HEAD gate is asserted.'
]
REPORT.mkdir(parents=True,exist_ok=True)
(REPORT/'DATA_CHECKS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS','cases':len(result['per_case']),'routes':list(result['routes']),'payloads':237,'record_shas':[r['body_sha256'] for r in result['per_case']]},ensure_ascii=False))
