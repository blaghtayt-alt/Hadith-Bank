#!/usr/bin/env python3
"""Independent Chromium exercise of actual generated reader and static HTML.
Local navigation is blocked by this runtime, so exercise exact generated HTML/inline JS
via set_content, and inject exact generated static CSS as an in-browser stylesheet.
No network requests, source changes, production code edits or publication.
"""
from pathlib import Path
from hashlib import sha256
from playwright.sync_api import sync_playwright
import json

IN=Path('/mnt/data/_bs_tirmidhi_adapter_qc/input/execution-independent')
RECORDS=json.loads(Path('/mnt/data/_bs_tirmidhi_adapter_qc/input/registered-private-fixture/materials/bs-tirmidhi-karalic-v1-1999-8b62165c/records.json').read_text(encoding='utf-8'))
OUT=Path('/mnt/data/BS-TIRMIDHI-THREE-FINAL-ADAPTER-QC-001-RESULT')
E=OUT/'evidence';E.mkdir(exist_ok=True)
HASH=lambda s:sha256(s.encode('utf8')).hexdigest()
checks={'approach':'Chromium headless, generated actual reader HTML/CSS/JS via set_content because admin blocks local URL navigation; all external requests denied. Static pages use exact generated HTML and injected generated CSS; live URL navigation untested.','browser':'/usr/bin/chromium','routes':{},'cases':[],'screenshots':[],'limitations':['Local file:// and loopback http navigation denied by environment: ERR_BLOCKED_BY_ADMINISTRATOR. Exact generated HTML rendered and exercised in Chromium using set_content; navigation and external links remain untested.']}

reader=(IN/'private-reader.html').read_text(encoding='utf-8')
static_css=(IN/'static/assets/discovery.css').read_text(encoding='utf-8')

def metrics(page):
 return page.evaluate('''() => ({viewport: window.innerWidth, scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth,overflowPixels:Math.max(0,document.documentElement.scrollWidth-document.documentElement.clientWidth)})''')

def screenshot(page,name):
 path=E/name
 page.screenshot(path=str(path),full_page=False,animations='disabled')
 checks['screenshots'].append({'name':name,'sha256':sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size})

def inspect_reader(browser,number,width,height,query,export=False):
 record=RECORDS[number-1]; case={'route':'full_reader','case':number,'viewport':[width,height],'query':query,'assertions':[]}
 context=browser.new_context(viewport={'width':width,'height':height},accept_downloads=True)
 page=context.new_page();errors=[];console=[];external=[]
 page.on('pageerror',lambda e: errors.append(str(e)))
 page.on('console',lambda e:console.append(e.text) if e.type=='error' else None)
 page.route('**/*',lambda r:(external.append(r.request.url),r.abort()) if not r.request.url.startswith('about:') else r.continue_())
 page.set_content(reader,wait_until='load',timeout=30000)
 before=metrics(page)
 page.fill('#query',query);page.click('#run-search');page.wait_for_timeout(160)
 assert page.locator('article').count()==1,(number,page.locator('article').count(),page.locator('body').inner_text()[-450:])
 case['assertions'].append('Unique matching source-occurrence search result')
 page.get_by_role('link',name='Open narration').first.click()
 page.wait_for_timeout(120)
 narration=page.locator('#narration-workspace p.narration[lang="bs"]')
 assert narration.count()==1,('narration elements',narration.count())
 assert narration.first.inner_text()==record['text']['translation']
 assert HASH(narration.first.inner_text())==HASH(record['text']['translation'])
 case['assertions'] += ['Rendered exact full chained Bosnian body SHA-256','Correct source-inline parentheses and punctuation']
 text=page.locator('#narration-workspace').inner_text()
 assert 'Human translation' in text and 'Prof. Mahmut Karalić' in text
 assert 'Arabic · not yet available' in text and 'English · not yet available' in text
 assert '1 readings' in text and 'Collection number not supplied' in text
 assert 'Source version' in text
 case['assertions'] += ['Human label and translator visible','1 Bosnian reading and no added Arabic/English','No canonical number']
 assert not errors,errors
 case['assertions'].append('No JavaScript page errors')
 if export:
  page.get_by_text('Select',exact=True).last.click()
  assert page.get_by_role('button',name='Download selected JSON',exact=False).count()==1
  assert 'JSON (1)' in page.get_by_role('button',name='Download selected JSON',exact=False).inner_text()
  with page.expect_download(timeout=18000) as ev:page.get_by_role('button',name='Download selected JSON',exact=False).click()
  download=ev.value; assert download.suggested_filename=='hadith-bank-selected-records.json'
  raw_export=Path(download.path()).read_bytes()
  artifact=E/'reader-selected-H2-ui-export.json'
  artifact.write_bytes(raw_export)
  ds=json.loads(raw_export)
  case['selected_json_file']=str(artifact.relative_to(OUT))
  case['selected_json_file_sha256']=sha256(raw_export).hexdigest()
  assert len(ds)==1 and ds[0]['id']==record['id'] and ds[0]['text_translation']==record['text']['translation']
  assert ds[0]['translation_provenance']['origin']=='human' and ds[0]['ai_translation'] is False
  assert ds[0]['number']==record['number']
  assert ds[0]['counterpart_policy']['mode']=='disabled'
  case['selected_json_sha256']=HASH(ds[0]['text_translation']);case['assertions'].append('Actual selected-JSON UI download, exact body and metadata')
 after=metrics(page)
 case['initial_viewport']=before;case['detail_viewport']=after
 case['javascript_page_errors']=errors;case['console_errors']=console;case['blocked_requests']=external[:8]
 if after['overflowPixels']:
  case['layout']='HOLD';case['issue']='Horizontal overflow on original full-reader private proof title/header, '+str(after['overflowPixels'])+'px'
  elements=page.evaluate('''() => [...document.querySelectorAll('body *')].filter(el=>{const r=el.getBoundingClientRect();const s=getComputedStyle(el);return r.width>0 && r.right>window.innerWidth+1 && s.display!=='none' && s.visibility!=='hidden';}).map(el=>{const r=el.getBoundingClientRect();return {tag:el.tagName,id:el.id,cssClass:typeof el.className==='string'?el.className:'',right:Math.round(r.right),left:Math.round(r.left)}}).sort((a,b)=>b.right-a.right).slice(0,8)''')
  case['offenders']=elements
  # Diagnostic ONLY: mutate a disposable browser DOM (not the generated input)
  # to isolate the long private proof title as the cause.
  brand=page.locator('#brand-title');brand.evaluate("el => el.textContent='Hadith Bank'")
  case['short_brand_diagnostic']=metrics(page)
 else:case['layout']='PASS'
 file=f'reader-case{number}-width{width}.png'
 # Capture original generated DOM, not short-name diagnostic
 if after['overflowPixels']:
  brand.evaluate("el => el.textContent='PRIVATE bounded adapter execution proof'")
 screenshot(page,file)
 checks['cases'].append(case)
 context.close()
 return case

def inspect_static(browser,number,width,height):
 row=RECORDS[number-1]
 case={'route':'static_record','case':number,'viewport':[width,height],'assertions':[]}
 path=next(x for x in (IN/'static/hadith').rglob('*.html') if row['id'] in x.read_text(encoding='utf8'))
 context=browser.new_context(viewport={'width':width,'height':height})
 page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('**/*',lambda r:r.abort())
 page.set_content(path.read_text(encoding='utf-8'),wait_until='load',timeout=30000)
 page.add_style_tag(content=static_css)
 body=page.locator('details.language-reading .text.quotation[lang="bs"]')
 assert body.count()==1 and body.first.inner_text()==row['text']['translation']
 assert HASH(body.first.inner_text())==HASH(row['text']['translation'])
 assert 'Prof. Mahmut Karalić' in page.locator('main').inner_text()
 assert 'Translation origin' in page.locator('main').inner_text() and 'Human' in page.locator('main').inner_text()
 assert 'Collection number not supplied' in page.locator('main').inner_text()
 assert not errors
 case['assertions']=['Exact static body + hash','One Bosnian language-reading','Human, translator, unknown number','No JS page errors']
 case['viewport_metrics']=metrics(page);case['layout']='PASS' if case['viewport_metrics']['overflowPixels']==0 else 'HOLD'
 case['javascript_page_errors']=errors;case['local_static_file']=str(path.relative_to(IN))
 if number==2 and width in [390,1280]:screenshot(page,f'static-case2-width{width}.png')
 checks['cases'].append(case)
 context.close()
 return case

with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 for no,width,query in [(2,1280,'poslednjom'),(1,390,'milostinja'),(2,390,'poslednjom'),(3,390,'tekbir')]:
  x=inspect_reader(browser,no,width,900 if width==1280 else 844,query,export=(no==2 and width==1280))
 for no,width in [(1,390),(2,390),(3,390),(2,1280),(2,320)]:
  inspect_static(browser,no,width,844 if width<1000 else 900)
 browser.close()
checks['routes']['full_reader_body_render']='PASS all 4 selected desktop/mobile cases display exact chained source body, Human/credit, unpaired Arabic/English, 0 JS page errors'
checks['routes']['reader_ui_export']='PASS case2 selected JSON real UI download with unchanged body and metadata'
checks['routes']['reader_mobile_overflow']='HOLD private proof header: '+str(next(x for x in checks['cases'] if x['route']=='full_reader' and x['viewport'][0]==390)['detail_viewport']['overflowPixels'])+'px, long proof title; short-title diagnostic removes overflow'
checks['routes']['static_html_mobile_desktop']='PASS all 5 selected static-page cases no overflow at 320/390/1280px, exact body and translator/Human labels'
checks['routes']['link_navigation']='NOT TESTED: browser administrator denies local file and loopback navigations; no live site / external network checks'
(OUT/'logs/BROWSER_CASES.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'cases':len(checks['cases']),'reader_checks':4,'static_checks':5,'reader_mobile_holds':len([x for x in checks['cases'] if x.get('layout')=='HOLD']),'screenshots':len(checks['screenshots'])},ensure_ascii=False))
