# BS-TIRMIDHI-THREE-FINAL-ADAPTER-QC-001 — Independent bounded report

**Final disposition: HOLD for two non-source integration issues.** The three canonical Bosnian bodies/metadata pass. The actual registered loader, full-reader builder, static builder and Markdown exporter execute successfully, but the supplied search-record JSON Schema rejects the preserved `human` origin, and the long custom **private proof** header overflows a 390px reader viewport. These findings do **not** reopen closed source1/3 PASS or case2 spelling-delta PASS, and do not imply an incorrect translation or extra narration.

## Input and code pins

- Original packet: **22,230,679 bytes**, SHA-256 `a71e20e49274c1e2175c65ec60767a5910e0ad18f09dd0c3bf79d0d77409f13a`; ZIP CRC **PASS**, all **237/237** manifest payloads SHA and sizes **PASS**. Extracted input payloads remained unchanged after execution.
- Exact source PDF (archival, not rereviewed): `8b62165c8b1f79fbeb70e0e24afc751c45fadc24dcaee18ae7ec255926221bc2`.
- Frozen registered records: `3a3102e3d5263e5c58ac9df995c94d45c9979a1c1cae26d41f9585bf8f76b478`.
- Material manifest: `a2f92acb8afa66d0d9c84889295006ed03734ddecc8de8c8f1c157c173a6a5cb`.
- Accepted successor candidates JSONL: `531c10a2068d366e0b3d44c6abcd5bc882afaf8918f53e697664b99481a22ed0`.
- Prior closed independent H2 delta archive: `12f27d2f8f0a14c07597d9600107da2a3cdae2b96a7065a65a0c1dce521442b7`.
- Actual production code snapshot: **222** pinned code payloads; sorted path+size+SHA inventory digest `86bdb6a3983fe12437519ebbde221bfcb18cc3ac7ea423fff376a717e65f99d0`. Primary modules: `material_registry.py` `0aafebef031e952e45d4a426692976a184cd362babd63e63fbcfb0d1595001d0`, `build_reader.py` `3be859ea6b7ce807b750a07969cdd19c3d4f3581f49f0cc3afe5e972728e9d44`, `build_discovery.py` `42474d02cd14526e6d1bedd0823044a2306254550895006b1b818bfb29503069`, `run_actual_adapters.py` `ba6f799734852798f5cb7e12f3b73524da71698342700a157af7ce55fa204233`. Other code hashes are in `RESULT.json` and `logs/DATA_CHECKS.json`.

## Per-case registered body / metadata

| Case | PDF / printed pages | Raw span | Body codepoints | SHA-256 UTF-8 | Bounded decision |
|---|---|---|---:|---|---|
| 1 | 63,64 / 59,60 | `[3, 445]` | 442 | `ce92b74895cd46808a99e9db1f5bf5c7859e5aa8f6fa7bf0ab6093d49187e68f` | **PASS** |
| 2 | 65,66 / 61,62 | `[3, 724]` | 721 | `4989c263b0a0a238baf946c0e45b89cd3f39c65624554738059b2c8effc247cd` | **PASS** |
| 3 | 69 / 65 | `[3, 512]` | 509 | `3aa7bee2cafb7545a9fdd2414dd1cb780e0cf3a66446aa6942669f863274b15d` | **PASS** |

Each body is exactly the accepted `raw_bosnian_transcribed_segment` codepoint span after removing **only** its leading printed-number prefix (`1. `, `2. ` or `3. `). The original chain, matn, punctuation, source parentheses, and the case2 distinct `sa posljednjom`/`ili poslednjom` readings are retained. Three stable IDs, volume/edition, narrator/page fields and Prof. Mahmut Karalić credit are retained. Current display is **Human** with source `ai_translation: false` and source provenance `origin: human` preserved; no code attempted to modernize these values. All internal/source/canonical number fields are null, references are empty, unverified counterparts are disabled, standalone Arabic/commentary and footnotes are not added as readings. All release gates stay private/ineligible.

## Actual execution and independent checks

Ran exactly `python run_actual_adapters.py --output execution-independent` using the supplied real production scripts, with a separate output directory. Command exit **0**; registry 1 material / 3 records, loader exact round trip, generated self-contained full reader (378,896 bytes), 3 static occurrence pages / 4 static index pages, 5 Markdown files, and all three source bodies unchanged. Actual search-record JSONL SHA-256: `{result['generated_proof']['search_records_jsonl']['sha256']}`; full reader HTML SHA-256: `{reader['sha256']}`. Exact generated artifact hashes are in `logs/DATA_CHECKS.json`.

| Route | Verdict | Notes |
|---|---|---|
| `input_integrity` | **PASS** | Original ZIP SHA and CRC; 237/237 payload sizes/hashes, complete extraction unchanged |
| `historical_delta_pin` | **PASS** | Exact successor, PDF, records, material manifest and independently passed H2 QC archive pinned |
| `canonical_material_schema` | **PASS** | 1 source manifest and 3 registered canonical records validate against bundled schema |
| `source_span_fidelity` | **PASS** | 3/3 exact full Bosnian body equals frozen reviewed raw codepoint span after only printed-number prefix |
| `registered_metadata` | **PASS** | 3/3 Human/false, narrator/translator/pages/IDs, null numbers and references, no added Arabic/commentary/footnotes |
| `load_public_materials` | **PASS** | Executed actual production registry; 1 material and 3 Bosnian records |
| `load_records` | **PASS** | Executed actual loader; exact three projected records round-trip |
| `full_reader_build` | **PASS** | Executed complete self-contained full reader; exact bodies and no network dependencies |
| `static_build` | **PASS** | Actual static builder; 3 separate record HTML pages and all exact bodies |
| `markdown_export` | **PASS** | Actual builder; 5 Markdown files, all 3 bodies exact |
| `search_record_schema` | **HOLD** | 3 independently identified enum violations at /translation_provenance/origin: preserved `human` is absent from bundled search-record schema enum |
| `desktop_browser` | **PASS** | Genuine Chromium rendering and H2 search, exact body, Human/credit, selected JSON UI export |
| `mobile_reader_content` | **PASS** | Genuine Chromium 390px: H1/H2/H3 exact bodies and metadata; no JS page errors |
| `mobile_reader_layout` | **HOLD** | At 390px, original private proof reader has 71px horizontal overflow from long custom brand title; browser-only shorter-title diagnostic removes it |
| `static_browser` | **PASS** | Actual static HTML/CSS viewed with Chromium at 320,390,1280px; no overflow or JS errors |
| `navigation_live_site` | **NOT_TESTED** | Local browser URL navigation blocked by environment; no external links, site deployment, CI or merged HEAD tested |

## HOLD 1 — Search-record schema contract (3/3)

Independent JSON Schema validation of actual generated `fixture/search/records.jsonl` using pinned `actual-code/schemas/search.record.schema.json` produces **exactly one** error per record, always at **`/translation_provenance/origin`**. The records contain **`"human"`**, while that schema allows only **`"publisher_human_workflow"`, `"human_translator_credited"`, `"legacy_source_history"`, `"unknown"`**. The canonical material-record schema **does** validate all three; the real runtime loader/builder **does** pass. This is a schema-contract mismatch, **not** evidence the reading is AI-generated or that source historical values should be overwritten. Suggested remediation is a separately authorized schema/policy reconciliation preserving original source fields. No schema or code edit made here.

## HOLD 2 — Mobile private proof header (3 tested views)

At 390px viewport width, the generated `PRIVATE bounded adapter execution proof` reader has **461px document scroll width (71px horizontal overflow)** before and after search. Offending nodes include the `.brand`/`#brand-title`, `.site-nav`, and `#offline-download`. This is **caused by the unusually long custom private proof title**, not by Bosnian text; a **browser-only diagnostic** using a short brand string removes overflow (390/390), without changing source, CSS, code or persisted HTML. On 1280px desktop the reader has no overflow. Actual static pages for all three records show zero overflow at 390px, with case2 additionally checked at 320px and 1280px. Exact screenshots, browser geometry and console/page-error checks are provided.

## Real browser interaction and limits

Chromium exercised exact produced full-reader HTML and embedded JS: queries `milostinja`, `poslednjom`, `tekbir` each returned the intended unique occurrence; opening narration showed full matching body, one Bosnian reading, Human label and Prof. Mahmut Karalić; Arabic/English were explicitly unavailable, no canonical number was supplied, and there were **no JavaScript page errors**. The actual **Download selected JSON** UI action for case2 returned one record with identical body and metadata (archived as `evidence/reader-selected-H2-ui-export.json`). Selected static pages used exact HTML/CSS for 320px/390px/1280px checks.

**Environment limit:** Chromium navigation to both `file://` and `http://127.0.0.1/` was denied with `ERR_BLOCKED_BY_ADMINISTRATOR`; HTML was exercised via Chromium `page.set_content` with bundled CSS injected verbatim for static pages. This tests genuine generated DOM/JS/rendering and JSON download but **not live URL navigation, deployment or network dependencies**. No bypass, external network request or tool installation was attempted.

## Historical gates and remaining scope

- Source1/3 initial review and case2 exact spelling-delta approval remain **closed PASS**, without another source/meaning/glyph assessment.
- Earlier old1/3 canonical-object immutability is pinned in the supplied private-stage checkpoint. The historical prior canonical object bytes themselves were not supplied for an independent record-to-record byte comparison; this reviewer independently compared today's frozen canonical bodies/metadata with accepted raw field spans and hashes.
- No rights clearance, narration+variant canonical identity, Arabic/English pairing, merged-HEAD/French-Hindi combined code, full CI, complete 528-page book, or live-site gate is asserted.
- No GitHub/public write, new worker, PDF reacquisition, production-code change or release occurred. Private flags and archive material remain unchanged.

## Reproducibility and checkpoint

The output ZIP includes `RESULT.json`, this report, all independent input/data/browser JSON logs, the unchanged actual-adapter stdout/result, two independent QA scripts, six browser screenshots, downloaded selected-JSON proof and compact copies of generated reader/static/Markdown/search output. Every included output is pinned by `MANIFEST.json` with exact bytes and SHA-256. The 21MB PDF and 222 code files are **referenced by verified input hashes**, not duplicated in this compact QC archive.

**Downstream decision:** accept the three source-body/data projections as scoped PASS; keep complete adapter integration on HOLD pending independent reconciliation of the provenance enum contract and the private-header mobile overflow. Preserve current source text and flags; do not publish automatically.
