# ES-ZAKARIA-N2-FINAL-ADAPTER-QC-001 — frozen independent adapter review

**Exact one-record adapter decision: PASS.** **Public registration/release: HOLD (not assessed and not performed).**

## Verified intake

- Received ZIP: `5c521d455f45bfb30c7b16c38988b0ed427dcdcfa469e3687a82619532a447ad` (6,085,718 bytes). ZIP CRC PASS; manifest **5/5** SHA-256/size PASS.
- Embedded private stage ZIP: `5bdc8c65e205321aba69e9c57de691ea592e452ccb7dfbdece72e7b5b908e191` (6,079,161 bytes). ZIP CRC PASS; staging manifest **7/7** SHA-256/size PASS.
- `selected-hadith2-record.json`: `fd0d565bdeb3efe6e1e4bd7ac3b42ee1a6970890c09228258a4f1db51c2dbd9e` (11,596 bytes).
- `records.json`: `009566d8fd49359c3632b0e74f01e088eeb0e00f64eac23efa58e44990f0e0fa` (5,219 bytes; exactly one record).
- `span-map.json`: `f5c7c07ef3c63615012349f3cfbaf05087042c48cc397598bf2680c3e768f3e1` (3,149 bytes).
- Byte-preserved original PDF: `a2f40956637a0ffbb38595fbd1aecd05c7cb6dfa0436d374e6bfc689ae12bdf2` (6,342,716 bytes).

The inherited `evidence/output-manifest.json` belongs to the **previous source-QC bundle**, not to this seven-file staging manifest. Its 4/16 referenced historical files that are also present in the stage (including the renamed but byte-identical source PDF) match; the other 12 previous-bundle members were not supplied in this packet and were **not** reverified. This does not undermine the separate fully verified intake/staging manifests or the exact adapter projection. The source-fidelity result was already established and is not reopened here.

## Exact narration and field/boundary coverage

- Record ID: `nawawi2-es-zakaria-maza-vielva-source-specific`; Spanish `es`, Nawawi, the specific Zakaria Maza Vielva source (not the Isa Garcia edition).
- Actual `text.translation` SHA-256: `1849f31a0a2601f38506533637cfe4d5fbb7719e3a5d5455a9352e4bfb77b9cc`; 1,995 Unicode codepoints.
- Independently reconstructed the body byte-for-byte from **one narrator introduction + ten approved narration paragraphs**, with only ten `LF LF` boundaries. No title or citation inserted into the body. All **11** span-map Unicode offsets, UTF-8 field hashes, and 10 separator boundaries checked PASS.
- Approved structure: **13 source segments / 44 selected lines** (prior source review). Structural segment correspondence checked: heading / narrator / 10 paragraphs / attribution; PDF physical pages 6–8 and printed pages 5–7.
- `HADIZ-2.` remains title, source heading, and source-local number metadata; `Lo relató Muslim.` remains `references.citation_as_printed` and is outside the narration.
- Narrator intro is preserved verbatim in both `text.translation` and `narrator.intro_as_printed`; `narrator.name` is deliberately unnormalized (`null`).

## Metadata and explicit unknowns

The stage maps source title, credited author, URL, imprint, original PDF hash, PDF technical creation date (not a publication date), Zakaria Maza Vielva translator credit, page alignment and source-local number. Edition date remains `null`. The original `ai_translation: unknown` and unaudited production process remain unknown; the owner's separate new-book Human **display** policy is not overwritten here. Canonical number/citation and verified counterpart links remain `null`/`false`; `related_versions` is empty. Rights/reuse and grading remain unassessed; `text.arabic` and both commentary fields remain `null`. Original PDF stays complete.

Archival-only metadata intentionally remains in the untouched approved source object rather than all being duplicated into the Bank adapter: original filename, full 89-page count, source Arabic pages [5,6], exact translator heading, and the 13-segment QC geometry. The required original source bytes and approved object are packaged with the stage.

## Issue disposition and gates

- **Concrete field/boundary mapping issues:** 0.
- **Exact-final adapter:** PASS — 76/76 independent assertions passed.
- **Prior source text review:** acknowledged only; neither repeated nor superseded. Printed text, punctuation and editorial decisions untouched.
- **Provided overlap report:** separate and narrowly scoped; no independent complete corpus rescan, identity merging, or counterpart proof here.
- **Still HOLD outside this review:** canonical/Arabic variant identification, rights/reuse decision, owner/writer integration, complete Bank build, registration, deployment, public/live verification and final release.
- The frozen private candidate intentionally still labels independent adapter QC as `pending_exact_final_adapter` in its original record. This independent PASS report is an external handoff, **not a mutation of that record**.

No source/code/text changes, no translated content generation, no registry or public write, and no certification.
