#!/usr/bin/env python3
"""Recheck this selected source transcription against original PDF and manifest.
Requires PyMuPDF (fitz); visual review is recorded in qc-findings.json, not automatable here.
"""
from pathlib import Path
import json, hashlib, re, fitz
root = Path(__file__).resolve().parent
manifest=json.loads((root/'output-manifest.json').read_text(encoding='utf-8'))
for name,expected in manifest['members'].items():
 data=(root/name).read_bytes()
 assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256'], name
record=json.loads((root/'selected-hadith2-record.json').read_text(encoding='utf-8'))
pdf=fitz.open(root/'source/islamenespanol-mirror.pdf')
assert len(pdf)==89
chunks=[]
for page,lo,hi,expected_count in [(6,360,510,8),(7,120,510,22),(8,120,355,14)]:
 lines=[]
 for block in pdf[page-1].get_text('dict')['blocks']:
  for line in block.get('lines',[]):
   if lo<=line['bbox'][1]<hi:
    s=' '.join(''.join(x['text'] for x in line['spans']).split())
    if s: lines.append((line['bbox'][1],s))
 assert len(lines)==expected_count, (page,len(lines))
 chunks.extend(s for _,s in sorted(lines))
expected=' '.join(chunks)
transcript=(root/'transcription/hadith2-display-paragraphs.txt').read_text(encoding='utf-8')
assert re.sub(r'\s+',' ',transcript).strip()==re.sub(r'\s+',' ',expected).strip()
print('PASS: manifest hashes, original PDF, complete physical 6–8 text-to-source fidelity')
