# Independent deduplication audit — 諸々の徳②

## Result and scope

All57 supplied source occurrences have a proposed existing reader anchor:2exact Japanese copies and55stored Fawaz Arabic report readings. These are **display grouping recommendations**, pending the second review. Every source occurrence, edition, version, source reference and historical review/origin classification remains separate.

`display_grouping_decisions.jsonl` is the57-row mapping. `display_grouping_evidence.json` contains exact Japanese and selected target comparison fields, narrator/content reasoning, competing candidates and prior reference-audit evidence. `binding_validation.json` confirms all57target IDs and complete-record audit hashes still match the stored records.

## Matching strategy actually used

1. Read repository AGENTS.md, counterpart identity/resolution rules and the review contract. No Git or repository mutation was performed.
2. Enumerate all25Japanese catalog datasets (3463source occurrences). Verify canonical record file hashes against the catalog. Preserve snapshot and edition identities.
3. Generate candidates from Japanese literal quotations, excerpts and character trigrams; collection/reference information only supplies search hints. Remove honorific/formatting differences only in comparison keys, never source text. Semantic similarity alone does not authorize a binding.
4. Compare each book occurrence with the preferred collection explicitly named in its footnote. Fawaz provider `hadithnumber` and `arabicnumber` are kept separate. Muslim1728corresponds to provider4517after narrator/matn comparison, not provider1728.
5. Actually read the Japanese and selected Arabic/English fields; compare terminal narrator, participants, sequence, distinctive clauses, excerpt boundaries and material wording alternatives. No complete isnad identity or word-for-word translation certification is claimed.
6. Prefer the two full exact Japanese copies already in the legacy bank. Keep research-v3 counterpart holds intact even where literal wording overlaps. Do not use a research witness as approved source identity.
7. Where the same report occurs repeatedly within a collection, retain all candidate IDs. Notes27/28/45use parent-directed representative reading anchors2374/1190/363, with6182/7471/4729explicitly preserved. Note52proposes1894as representative alongside1895. These choices do not claim which repeated collection position the Japanese compiler used.

## Concrete findings

- Note3is byte-identical to `legacy.ja.765357f44b3bf75ff31f1753`; note7is byte-identical to `legacy.ja.c0edb05a856775443066c58a`. Existing credits identify this book. Attach new edition/source provenance without erasing the historical legacy Unknown classification.
- Notes13,21,32,41have literal quotation overlaps with held Japanese research-v3 records. No held target is selected or promoted.
- Notes21and41have the same printed collection-number family but distinguish the brother-only Bukhari wording from the brother/neighbor Muslim alternative. Their selected anchors remain separate.
- Notes9and42share a mercy theme but have different narrators and quoted formulations. Do not merge them by theme or short text.
- Note31uses Bukhari5988for its direct wording; Muslim2554is a broader supporting parallel. Note35uses Sahl/Bukhari5304; Muslim2983is an Abu Hurayra parallel. The two Muslim citations are not grouping bindings.
- Notes3,9,16,23,28,36,44,45,48,50,54and related short/source-context cases retain their excerpt/context qualifications. A fuller target is not represented as exact Japanese coverage.
- Note55is Talha’s narrated dialogue with Ibn Abi Awfa, whose answer describes the Prophet’s will. The speaker correction is retained, and the dialogue is not relabelled as direct Prophetic speech.
- Source interpretive qualifications at10,18,30and Fawaz English’s shortened narrator name at38are retained in the decision rationale. This audit does not rewrite either publisher’s wording.

## Limits

The accepted-material canonical files, their catalog hashes, and preserved earlier reference audit were inspected. The full remote collection universe was not newly browsed. Arabic original fields of the Japanese source remain null. Mapping a reader card does not approve new counterpart publication, certify authenticity, clear rights, or establish equality of full chains. The primary transcript, editorial edition and old bank bytes remain unchanged.
