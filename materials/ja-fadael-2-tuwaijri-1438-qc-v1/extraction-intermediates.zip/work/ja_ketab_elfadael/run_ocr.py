from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import fitz, subprocess, os, json, hashlib, time

BASE = Path(__file__).resolve().parent
SOURCE = BASE.parents[1] / 'upload/ja_ketab_elfadael.pdf'
IMAGES = BASE / 'ocr_images'
OUTPUT = BASE / 'ocr'
IMAGES.mkdir(exist_ok=True)
OUTPUT.mkdir(exist_ok=True)
doc = fitz.open(SOURCE)
for n, page in enumerate(doc, 1):
    page.get_pixmap(dpi=300, alpha=False).save(str(IMAGES / f'page_{n:03}.png'))

def run(n):
    lang = 'ara+eng' if n == 2 else ('jpn+ara+eng' if n == 4 else 'jpn+eng')
    cmd = ['tesseract', str(IMAGES / f'page_{n:03}.png'), str(OUTPUT / f'page_{n:03}'), '--tessdata-dir', str(BASE / 'tessdata'), '-l', lang, '--psm', '3', '-c', 'tessedit_create_txt=1', '-c', 'tessedit_create_tsv=1']
    started = time.monotonic()
    p = subprocess.run(cmd, capture_output=True, text=True, env={**os.environ, 'OMP_THREAD_LIMIT':'1'})
    return {'pdf_page':n, 'language':lang, 'dpi':300, 'psm':3, 'returncode':p.returncode, 'seconds':round(time.monotonic()-started,2), 'stderr':p.stderr}

records=[]
with ThreadPoolExecutor(max_workers=4) as pool:
    for f in as_completed([pool.submit(run, n) for n in range(1, len(doc)+1)]):
        r=f.result()
        records.append(r)
        print(json.dumps(r), flush=True)
(OUTPUT/'run_log.json').write_text(json.dumps(sorted(records,key=lambda r:r['pdf_page']),indent=2), encoding='utf-8')
