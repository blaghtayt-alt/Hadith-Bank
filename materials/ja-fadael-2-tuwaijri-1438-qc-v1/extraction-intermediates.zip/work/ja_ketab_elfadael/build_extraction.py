from pathlib import Path
import fitz, json, re, hashlib, difflib, unicodedata, csv, shutil, zipfile
from datetime import datetime
from zoneinfo import ZoneInfo

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = ROOT / 'upload/ja_ketab_elfadael.pdf'
OUT = ROOT / 'output/ja_ketab_elfadael'
OUT.mkdir(parents=True, exist_ok=True)
SOURCE_ID = 'JA_KETAB_ELFADAEL_09a7f220e7bc'
NAME = 'ja_ketab_elfadael'
doc = fitz.open(SOURCE)
sha256 = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
reviews = [json.loads(p.read_text()) for p in sorted((BASE/'reviews').glob('review_p*.json'))]
review_by_page = {p['pdf_page']:p for r in reviews for p in r['pages']}
assert sorted(review_by_page) == list(range(1,26))
assert all(p['image_inspected'] for p in review_by_page.values())
assert all(not p['uncertainties'] for p in review_by_page.values())

def write_json(path, data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def normalized(text):
    return ''.join(c for c in text if not c.isspace() and unicodedata.category(c)!='Cf' and not 0xE000<=ord(c)<=0xF8FF)

def comparison_normalized(text):
    # This is used only for an OCR disagreement metric; never for delivered source wording.
    return normalized(unicodedata.normalize('NFKC',text))

def box_union(boxes):
    return [round(min(b[0] for b in boxes),3),round(min(b[1] for b in boxes),3),round(max(b[2] for b in boxes),3),round(max(b[3] for b in boxes),3)]

def language(text):
    if re.search(r'[\u3040-\u30ff\u3400-\u9fff]',text): return 'ja'
    if re.search(r'[\u0600-\u06ff]',text): return 'ar'
    if re.search(r'[A-Za-z]',text): return 'en'
    return 'und'

all_notes=[]
pages=[]
raw_unsorted=[]
comparison=[]
changes=[]
unit_counter=0
for number,page in enumerate(doc,1):
    raw=page.get_text('text',sort=False)
    raw_unsorted.append(raw)
    dictionary=page.get_text('dict',sort=False,flags=fitz.TEXTFLAGS_DICT & ~fitz.TEXT_PRESERVE_IMAGES)
    raw_lines=[]
    for block in dictionary['blocks']:
        for line in block.get('lines',[]):
            text=''.join(s['text'] for s in line['spans']).strip()
            if text:
                raw_lines.append({'text':text,'bbox':list(line['bbox']),'spans':line['spans']})
    lines=[]
    decorations=[]
    hidden=[]
    for line in raw_lines:
        if number==25 and line['bbox'][1]<50:
            hidden.append({'text':line['text'],'bbox':line['bbox'],'reason':'Covered by back-cover artwork; not visible in rendered source.'})
            continue
        # PyMuPDF splits the Arabic title over three adjacent text runs.
        if number==2 and 110<line['bbox'][1]<142:
            if not any(x.get('arabic_title') for x in lines):
                pieces=[l for l in raw_lines if 110<l['bbox'][1]<142]
                lines.append({'text':'كتاب الفضائل','bbox':box_union([l['bbox'] for l in pieces]),'spans':[], 'arabic_title':True,'method':'embedded_text_reconstructed_and_image_verified'})
            continue
        if re.search(r'[\ue000-\uf8ff]',line['text']):
            decorations.append({'text_layer_glyphs':''.join(c for c in line['text'] if 0xE000<=ord(c)<=0xF8FF),'bbox':line['bbox'],'interpretation':'Nonlinguistic ornamental flourishes.'})
            line={**line,'text':re.sub(r'[\ue000-\uf8ff]','',line['text']).strip()}
            if not line['text']: continue
        if number==4 and 'هللا' in line['text']:
            line={**line,'text':'بسم الله الرحمن الرحيم','method':'embedded_text_letter_order_repaired_from_page_image'}
        # Footnote 9 has a separately positioned marker on the same baseline.
        if lines and number==7 and lines[-1]['text']=='9' and abs(lines[-1]['bbox'][1]-line['bbox'][1])<2:
            prev=lines.pop()
            line={**line,'text':prev['text']+' '+line['text'],'bbox':box_union([prev['bbox'],line['bbox']]),'spans':prev['spans']+line['spans']}
        lines.append(line)
    rules=[d['rect'][1] for d in page.get_drawings() if 140<d['rect'].width<146 and d['rect'].height<2 and d['rect'][1]>350]
    footnote_y=rules[0] if rules else None
    units=[]
    for line in lines:
        text=line['text']
        y=line['bbox'][1]
        if number in [1,2]:
            if text=='1438': kind='publication_year'
            elif text=='كتاب الفضائل' or text.startswith('諸々の徳（'): kind='title'
            elif text.startswith(('翻訳者','ترجمة')): kind='translator_credit'
            elif text.startswith(('校閲者','مراجعة')): kind='reviewer_credit'
            elif text.startswith(('編集','تحرير')): kind='editor_credit'
            else: kind='author_credit'
        elif number==25:
            kind='publisher_credit' if 'IslamHouse' in text else ('source_punctuation' if text=='.' else 'back_cover_description')
        elif y<50:
            kind='running_header' if text=='諸々の徳' else 'printed_page_number'
        elif footnote_y is not None and y>footnote_y:
            kind='footnote_line'
        elif number==3:
            kind='contents_title' if text=='目次' else 'contents_entry'
        elif number==4 and language(text)=='ar':
            kind='opening_formula'
        elif text in ['よき品格の徳','親交の徳','聖クルアーンの徳']:
            kind='section_heading'
        elif text.endswith('徳：'):
            kind='subsection_heading'
        elif number==24 and y>200:
            kind='publication_addendum'
        elif number==4 and 120<y<160:
            kind='preface'
        else:
            kind='body_line'
        refs=[]
        if kind not in ['footnote_line','printed_page_number','publication_year']:
            offset=0
            for span in line['spans']:
                s=span['text']
                if span['size']<6 and re.fullmatch(r'\d+',s.strip()):
                    refs.append({'note_number':int(s.strip()),'bbox':span['bbox'],'source_font_size':span['size']})
                offset+=len(s)
        unit_counter+=1
        units.append({'unit_id':f'{SOURCE_ID}_p{number:03}_u{len(units)+1:03}','kind':kind,'language':language(text),'text':text,'bbox_pdf_points':[round(x,3) for x in line['bbox']],'inline_footnote_markers':refs,'method':line.get('method','embedded_pdf_text'),'ai_translation':'unknown'})
    logo={'unit_id':f'{SOURCE_ID}_p{number:03}_logo','kind':'publisher_logo','language':'en','text':'IslamHouse.com','bbox_pdf_points':None,'inline_footnote_markers':[],'method':'visual_transcription_of_image_only_text','ai_translation':'unknown'}
    if number in [1,2,25]:units.insert(0,logo)
    else:units.append(logo)
    notes=[]
    for u in [x for x in units if x['kind']=='footnote_line']:
        m=re.match(r'^(\d+)\s+(.*)$',u['text'])
        if m:
            note_number=int(m.group(1))
            notes.append({'note_id':f'{SOURCE_ID}_note_{note_number:03}','note_number':note_number,'pdf_page':number,'printed_page':number-2,'kind':'translator_commentary' if note_number==19 else 'source_reference_and_attribution','source_lines':[u['text']],'text':m.group(2),'line_ids':[u['unit_id']],'ai_translation':'unknown'})
        else:
            assert notes, (number,u)
            notes[-1]['source_lines'].append(u['text'])
            notes[-1]['text']+=u['text']
            notes[-1]['line_ids'].append(u['unit_id'])
    all_notes.extend(notes)
    previous=None
    visible=[]
    for u in units:
        if previous:
            a=previous['bbox_pdf_points'];b=u['bbox_pdf_points']
            gap=(b[1]-a[1]) if a and b else 0
            if u['kind']!=previous['kind'] or gap>17:
                visible.append('')
        visible.append(u['text'])
        previous=u
    visible_text='\n'.join(visible)+'\n'
    ocr=(BASE/'ocr'/f'page_{number:03}.txt').read_text()
    expected=comparison_normalized(visible_text)
    recognized=comparison_normalized(ocr)
    matcher=difflib.SequenceMatcher(None,expected,recognized,autojunk=False)
    differences=[]
    for op,a,b,c,d in matcher.get_opcodes():
        if op!='equal':differences.append({'operation':op,'visible_text_normalized':expected[a:b],'ocr_normalized':recognized[c:d],'context_before':expected[max(0,a-20):a],'context_after':expected[b:b+20]})
    comparison.append({'pdf_page':number,'sequence_similarity_after_comparison_only_nfkc_whitespace_normalization':round(matcher.ratio(),6),'metric_warning':'OCR agreement is not transcription accuracy. Delivered wording is not NFKC-normalized. Differences include OCR recognition, punctuation, logos, and layout.','disagreements':differences,'adjudication':'Use the embedded text confirmed in the page-image line-by-line review; retain the image-evidenced Arabic repairs, logo transcription and hidden-text filtering.'})
    rv=review_by_page[number]
    for correction in rv['corrections']:changes.append({'pdf_page':number,**correction})
    pages.append({'pdf_page':number,'printed_page_visible':number-2 if 3<=number<=24 else None,'page_role':'front_cover_japanese' if number==1 else ('front_cover_arabic' if number==2 else ('contents' if number==3 else ('back_cover' if number==25 else 'main_text'))),'size_pdf_points':[round(page.rect.width,2),round(page.rect.height,2)],'verified_visible_text':visible_text,'body_text':'\n'.join(u['text'] for u in units if u['kind'] not in ['footnote_line','running_header','printed_page_number','publisher_logo']),'source_units':units,'footnotes':notes,'nonlinguistic_decorations':decorations,'invisible_text_layer_content':hidden,'raw_embedded_text_unsorted':raw,'raw_embedded_text_spatial_sort':(BASE/'raw'/f'page_{number:03}.txt').read_text(),'raw_ocr_text':ocr,'review':rv,'ai_translation':'unknown'})

assert [n['note_number'] for n in all_notes] == list(range(1,59))
inline=[r['note_number'] for p in pages for u in p['source_units'] for r in u['inline_footnote_markers']]
assert inline==list(range(1,59)),inline
assert len(pages)==25
# Confirm every non-decoration embedded character was retained, with only the
# documented Allah letter order repair and covered back-cover header removed.
coverage=[]
for p in pages:
    expected=p['raw_embedded_text_unsorted']
    if p['pdf_page']==4:expected=expected.replace('هللا','الله')
    if p['pdf_page']==25:
        expected=expected.replace('諸々の徳','',1)
        expected=re.sub(r'\uf062\s*23\s*\uf061','',expected, count=1)
    actual=''.join(u['text'] for u in p['source_units'] if u['kind']!='publisher_logo')
    passed=normalized(expected)==normalized(actual)
    if not passed:
        raise AssertionError({'pdf_page':p['pdf_page'],'expected':normalized(expected),'actual':normalized(actual)})
    coverage.append({'pdf_page':p['pdf_page'],'all_source_text_retained_after_documented_repairs':passed})

data={'schema_version':'1.0.0','source_id':SOURCE_ID,'created_at':datetime.now(ZoneInfo('Asia/Tokyo')).isoformat(),'source':{'filename':SOURCE.name,'sha256':sha256,'bytes':SOURCE.stat().st_size,'pdf_page_count':len(doc),'library_file_id':'libfile_fde3_f-66917ed4ae348191a341a988ed775d52_c3a5ae5e9e0c8191af5d21c39948b9f7','pdf_metadata':doc.metadata},'bibliography':{'title_ja':'諸々の徳（ハディース集）②','title_ar':'كتاب الفضائل','author_ja':'ムハンマド・ブン・イブラーヒーム・アッ＝トゥワイジュリー','author_ar':'محمد بن إبراهيم التويجري','translator_ja':'サイード佐藤','translator_ar':'سعيد ساتو','reviewer_ja':'ファーティマ佐藤','editor_ja':'ムハンマド・サーリフ金子','year_as_printed':'1438','publisher_logo':'IslamHouse.com','source_url_as_printed':'https://islamhouse.com/ja/main','metadata_basis':'Visible front covers and publication addendum; source URL recorded, not accessed.'},'processing':{'primary_method':'Embedded PDF text extracted using PyMuPDF and checked against Poppler; full rendered-page line-by-line visual review; independent Tesseract OCR at 300 dpi.','text_is_translation_created_for_this_task':False,'ai_translation':'unknown','ai_translation_explanation':'The original names a translator but does not declare whether AI was used. No new translation was generated.','source_wording_edited':False,'repair_policy':'Repair only image-evidenced extraction/reading-order defects; preserve original spelling, punctuation, references and editorial inconsistencies.','whitespace_policy':'Trim layout-only line padding and reduce blank-line runs; retain source line wrapping, internal spaces, punctuation and digits.','structure_level':'Pages, source lines, headings, and footnotes. No complete hadith-record segmentation or live Bank import performed.','verification_status':'all_pages_line_by_line_image_checked_with_dual_extraction_and_ocr_comparison','independent_character_by_character_certification':False},'counts':{'pages':25,'source_units':sum(len(p['source_units']) for p in pages),'footnotes':58,'source_reference_notes':57,'translator_commentary_notes':1,'image_only_logo_transcriptions':25,'arabic_extraction_repairs_against_spatial_sort':6,'pages_with_hidden_text_filtered':1,'unresolved_visible_transcription_issues':0},'pages':pages,'footnotes':all_notes}
write_json(OUT/f'{NAME}_pages.json',data)
text_parts=[]
for p in pages:
    label=f'PDF PAGE {p["pdf_page"]:03} / 025'
    if p['printed_page_visible'] is not None:label+=f' | PRINTED PAGE {p["printed_page_visible"]}'
    text_parts.append(f'===== {label} =====\n\n'+p['verified_visible_text'].rstrip()+'\n')
(OUT/f'{NAME}_extracted.txt').write_text('\n\f\n'.join(text_parts),encoding='utf-8')
(BASE/'raw'/'pymupdf_unsorted.txt').write_text('\f'.join(raw_unsorted),encoding='utf-8')
write_json(BASE/'ocr'/'comparison_with_visible_text.json',comparison)
qc={'source_id':SOURCE_ID,'source_sha256':sha256,'page_coverage':coverage,'embedded_extractors':json.loads((BASE/'raw'/'dual_extractor_comparison.json').read_text()),'visual_reviewed_pages':list(range(1,26)),'ocr_processed_pages':list(range(1,26)),'ocr_run_log':json.loads((BASE/'ocr'/'run_log.json').read_text()),'source_notes_present':list(range(1,59)),'inline_note_markers_present':inline,'source_wording_preserved':True,'japanese_lexical_edits':0,'corrections_and_filters':changes,'source_editorial_oddities_preserved':[{'pdf_page':5,'text':'5253','context':'Footnote 5 source reference.'},{'pdf_page':8,'text':'彼に','context':'Second Aisha paragraph.'},{'pdf_page':10,'text':'間際らしい','context':'Source spelling.'},{'pdf_page':12,'text':'なおざり / アッラーに見える','context':'Source wording.'},{'pdf_page':19,'text':'必用事 / 必要事','context':'Both original forms retained.'},{'pdf_page':23,'text':'すると（タルハは）言いました','context':'Source wording.'},{'pdf_page':24,'text':'（1300）文章は','context':'No punctuation inserted.'},{'pdf_page':25,'text':'イバーダ―トの徳','context':'Original dash retained.'}],'unresolved_visible_transcription_issues':[],'limits':['One complete line-by-line image comparison pass across 25 pages; not an independent certified character-by-character edition.','OCR raw text contains recognition errors and is retained for comparison, not substituted for verified text.','Hadith references and source editorial claims were not authenticated against external collections.','No scholarly corrections, new translations, complete hadith-record segmentation, or Bank publication performed.','Decorative backgrounds and flourishes are inventoried as nonlinguistic graphics; no speculative transcription of background patterns.']}
assert all(r['returncode']==0 for r in qc['ocr_run_log'])
assert len(qc['ocr_run_log'])==25
assert all((BASE/'ocr'/f'page_{n:03}.tsv').is_file() for n in range(1,26))
write_json(OUT/f'{NAME}_verification.json',qc)

readme='''JA KETAB EL FADAEL — FULL TEXT EXTRACTION / OCR CROSS-CHECK

Source: ja_ketab_elfadael.pdf, 25 PDF pages.
Title: 諸々の徳（ハディース集）② / كتاب الفضائل

START HERE
- ja_ketab_elfadael_extracted.txt: readable UTF-8 visible transcript, with explicit PDF-page boundaries.
- ja_ketab_elfadael_pages.json: structured pages, source lines, coordinates, original and OCR text, and separated footnotes.
- ja_ketab_elfadael_verification.json: scope, corrections, hidden-text handling, coverage checks and limitations.

METHOD AND COVERAGE
All 25 pages were extracted with both PyMuPDF and Poppler. All 25 rendered source pages received a direct line-by-line image comparison. Independent Tesseract OCR was run at 300 dpi using Japanese/English and Arabic as appropriate. Raw OCR is retained as evidence, not treated as authoritative.
There are 58 footnotes: 57 source-reference/attribution notes and one translator commentary (note 19). These counts are NOT a count of verified hadith records.
All inline footnote markers 1–58 and footnote texts 1–58 are present. No page was skipped.

TEXT POLICY
Japanese source wording, source reference numbers, punctuation, and original editorial inconsistencies are preserved. Arabic reading-order defects are repaired from the visible page. The visible IslamHouse.com logo is transcribed on each page. Decorative flourishes are stored separately from language. The back-cover running title/page 23 exists in the underlying PDF text layer but is covered by artwork: it is preserved in raw data and excluded from the visible transcript. Poppler's extra cover-page 8 characters are also absent from the image and are not included in the transcript.
The body and footnotes remain separate in JSON. Source line wrapping is preserved in TXT. Page boundary labels are editorial, not original book text. Layout padding and excessive blank lines are simplified. All original unmodified extraction data remains in raw/.

AI TRANSPARENCY
No new translation was generated. The PDF names its translator but does not establish the use or absence of AI, so ai_translation is unknown. The task used AI-assisted visual transcription/review of the source and automated text extraction/OCR.

LIMITS
This is an extraction with complete page/line visual coverage, not a certified character-by-character critical edition. Source references were not authenticated against external collections. Hadith occurrences have not been segmented for a specific live importer, and nothing was published to the Bank.

PACKAGE
source/: unchanged original PDF.
raw/: unchanged extractor outputs and per-page text/span data.
ocr/: raw Tesseract text and TSV coordinates/confidence, comparison results, run log and model provenance.
reviews/: page-specific image-review findings.
scripts/: the extraction/verification and OCR workflow used for this task; original workspace layout is expected if rerunning without modification.

Source SHA-256: '''+sha256+'\n'
(OUT/'README.txt').write_text(readme,encoding='utf-8')
manifest={'source_sha256':sha256,'files':[]}
package_entries=[]
for p in sorted(OUT.iterdir()):
    if p.is_file() and p.suffix!='.zip' and p.name!='MANIFEST.json':package_entries.append((p,p.name))
package_entries.append((SOURCE,'source/'+SOURCE.name))
for directory in ['raw','ocr','reviews']:
    for p in sorted((BASE/directory).glob('*')):
        if p.is_file() and p.suffix in ['.txt','.json','.tsv']:package_entries.append((p,directory+'/'+p.name))
package_entries.append((BASE/'tessdata/models.json','ocr/model_provenance.json'))
for script in ['build_extraction.py','run_ocr.py']:package_entries.append((BASE/script,'scripts/'+script))
for p,name in package_entries:
    manifest['files'].append({'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
write_json(OUT/'MANIFEST.json',manifest)
with zipfile.ZipFile(OUT/f'{NAME}_ocr_package.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for p,name in package_entries:z.write(p,name)
    z.write(OUT/'MANIFEST.json','MANIFEST.json')
with zipfile.ZipFile(OUT/f'{NAME}_ocr_package.zip') as z:
    assert z.testzip() is None
    for f in manifest['files']:
        assert hashlib.sha256(z.read(f['path'])).hexdigest()==f['sha256']
print(json.dumps({'counts':data['counts'],'txt_characters':len((OUT/f'{NAME}_extracted.txt').read_text()),'output_files':[{ 'name':p.name,'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file()]},ensure_ascii=False,indent=2))
