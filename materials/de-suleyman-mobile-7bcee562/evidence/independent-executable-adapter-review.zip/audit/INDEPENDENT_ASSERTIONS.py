#!/usr/bin/env python3
"""Read-only independent bounded DE3 actual-adapter QC; pinned code and fixture only.

Usage:
  python INDEPENDENT_ASSERTIONS.py <extracted_input_dir> <executed_output_dir> <json_result_path>

Never mutates code, fixture or executed output; only writes its JSON result.
"""
import base64
from collections import Counter
import gzip
import hashlib
from html import unescape
import json
from pathlib import Path
import sys
import zipfile
from bs4 import BeautifulSoup

INPUT=Path(sys.argv[1]).resolve()
EXEC=Path(sys.argv[2]).resolve()
REPORT=Path(sys.argv[3]).resolve()
DATA=INPUT/'registered-private-fixture'
SCRIPTS=INPUT/'actual-code/scripts'
sys.path.insert(0,str(SCRIPTS))
import material_registry
import build_reader
from current_provenance import classification
from language_display import language_readings

H=lambda b: hashlib.sha256(b).hexdigest()
CHECKS=[]
def check(name,condition,**evidence):
    status='PASS' if condition else 'HOLD'
    CHECKS.append(dict(check=name,status=status,**evidence))
    if not condition:
        raise AssertionError(f'Independent check failed: {name} evidence={evidence}')
    return True

target=json.loads((INPUT/'TARGET.json').read_text(encoding='utf-8'))
manifest=json.loads((INPUT/'MANIFEST.json').read_text(encoding='utf-8'))
check('exact_target',target['tag']=='DE3' and target['records']==3 and target['language']=='de' and len(target['recordFiles'])==1)
check('manifest_all_239',len(manifest['payloads'])==239 and all((INPUT/x['path']).is_file() and len((INPUT/x['path']).read_bytes())==x['bytes'] and H((INPUT/x['path']).read_bytes())==x['sha256'] for x in manifest['payloads']),verifiedPayloads=len(manifest['payloads']))
fixture_path=DATA/target['recordFiles'][0]['path']
check('record_file_unchanged',H(fixture_path.read_bytes())==target['recordFiles'][0]['sha256'],sha256=H(fixture_path.read_bytes()))
raw=json.loads(fixture_path.read_text(encoding='utf-8'))
check('exact_canonical_ids',len(raw)==3 and [r['id'] for r in raw]==[
  'de-suleyman-nawawi-01-7bcee562','de-suleyman-nawawi-02-7bcee562','de-suleyman-nawawi-03-7bcee562'])
source_manifest_path=DATA/'materials/de-suleyman-mobile-7bcee562/manifest.json'
sm=json.loads(source_manifest_path.read_text(encoding='utf-8'))
check('source_material_manifest_matches',sm['schema']=='hadith-bank-material-v1' and sm['adapter']=='records-v1' and sm['records']['sha256']==target['recordFiles'][0]['sha256'] and sm['records']['count']==3 and sm['counterpart_policy']['mode']=='disabled',sha256=H(source_manifest_path.read_bytes()))
source_path=DATA/sm['source']['path']
check('original_pdf_source_binding',H(source_path.read_bytes())==sm['source']['sha256'] and source_path.stat().st_size==933533 and sm['source']['pdf_pages']==120,sha256=H(source_path.read_bytes()))
check('source_dates_distinct',sm['source']['edition_date'] is None and sm['source']['translation_preface_date']=='2017-07-02' and 'not publication date' in sm['source']['pdf_creation_metadata'])
check('source_credits_distinct',sm['source']['translator_credit_as_printed']=='Abū Suleyman' and sm['source']['reviser_credit_as_printed']=='Muḥammad S. Al-Almany')
for supporting in sm['supporting_files']:
    p=DATA/supporting['path']
    check('supporting_file_'+p.name,H(p.read_bytes())==supporting['sha256'] and len(p.read_bytes())==supporting['size_bytes'],sha256=H(p.read_bytes()))
reg=material_registry.load_public_materials(DATA)
projection=[r for group in reg['groups'] for r in group]
check('registry_actual_code',len(reg['materials'])==1 and len(projection)==3 and H((SCRIPTS/'material_registry.py').read_bytes())=='0aafebef031e952e45d4a426692976a184cd362babd63e63fbcfb0d1595001d0',materials=len(reg['materials']),records=len(projection))
loaded,cat,info=build_reader.load_records(EXEC/'fixture')
check('load_records_actual_code',loaded==projection and len(loaded)==3 and cat['search']['count']==3 and cat['search']['records_sha256']==H((EXEC/'fixture/search/records.jsonl').read_bytes()),searchStreamSHA256=H((EXEC/'fixture/search/records.jsonl').read_bytes()))
check('code_pins',all(H((SCRIPTS/p).read_bytes())==expected for p,expected in {
  'build_reader.py':'3be859ea6b7ce807b750a07969cdd19c3d4f3581f49f0cc3afe5e972728e9d44',
  'build_discovery.py':'42474d02cd14526e6d1bedd0823044a2306254550895006b1b818bfb29503069',
  'language_display.py':'909279a48e0521167a3ff1f7022e8159b1737eba20395202378dd966792bd18f',
  'current_provenance.py':'ab2e4a45eba6a5cb3b580da2a2e9c3b6ec84c8d1a07d5355a2e4c0bab4220243'
}.items()))
result=json.loads((EXEC/'RESULT.json').read_text(encoding='utf-8'))
check('actual_executed_result_exists',result['records']==3 and result['registryMaterials']==1 and result['roundTripExact'] and result['static']['record_pages']==3 and result['reader']['record_count']==3 and result['reader']['source_text_modified'] is False and result['reader']['self_contained'] is True and result['static']['source_texts_unchanged'] is True)
check('exact_executed_module_paths',all(Path(path).resolve()==(SCRIPTS/(k+'.py')).resolve() for k,path in result['codeModulePaths'].items()),codeModulePaths={k:str(Path(v).relative_to(INPUT)) for k,v in result['codeModulePaths'].items()})
html_doc=(EXEC/'private-reader.html').read_text(encoding='utf-8')
html_soup=BeautifulSoup(html_doc,'html.parser')
payload=html_soup.find('script',{'id':'hadith-records'})
check('standalone_record_encoding',payload is not None and payload.get('data-encoding')=='gzip-base64',htmlSHA256=H((EXEC/'private-reader.html').read_bytes()),htmlBytes=(EXEC/'private-reader.html').stat().st_size)
embedded=json.loads(gzip.decompress(base64.b64decode(payload.get_text())))
check('reader_embeds_all_original_projected_objects_exactly',embedded==projection,embeddedCount=len(embedded))
snapshot=json.loads(html_soup.find('script',{'id':'hadith-snapshot'}).get_text())
check('reader_snapshot_consistent',snapshot['record_count']==3 and snapshot['records_sha256']==cat['search']['records_sha256'] and snapshot['data_delivery']['self_contained'] is True)
markdown_files=list((EXEC/'markdown').rglob('*.md'))
mdp=EXEC/'markdown/de/nawawi/suleyman-mobile-7bcee562/page-0001.md'
mdtext=mdp.read_text(encoding='utf-8')
mdsoup=BeautifulSoup(mdtext,'html.parser')
mdsections=mdsoup.select('section.language-reading')
check('markdown_actual_page_and_files',len(markdown_files)==5 and len(mdsections)==3 and (EXEC/'markdown/reader-manifest.json').is_file(),markdownFiles=len(markdown_files),markdownManifestSHA256=H((EXEC/'markdown/reader-manifest.json').read_bytes()))
staticfiles=list((EXEC/'static/hadith').rglob('*.html'))
check('static_actual_three_pages',len(staticfiles)==3 and result['static']['static_record_pages_dom_verified']==3,staticPages=len(staticfiles))
source_text=(DATA/'materials/de-suleyman-mobile-7bcee562/evidence/original-de.txt').read_text(encoding='utf-8')
spans=json.loads((DATA/'materials/de-suleyman-mobile-7bcee562/evidence/selected-source-spans.json').read_text(encoding='utf-8'))
seen_pages=set();entries=[]
for index,(r,e,mdsection) in enumerate(zip(projection,spans,mdsections),1):
    body=r['text_translation'];original=raw[index-1]
    expected_hash=e['source_de_txt_span_sha256_utf8'];actual_hash=H(body.encode('utf-8'))
    prefix=f'entry{index}_'
    check(prefix+'body_verbatim_and_controls',body==original['text']['translation'] and H(body.encode())==expected_hash and len(body)==e['body_codepoints'] and body.count('\f')==e['body_contains_formfeeds'] and sum(x in ('\u202a','\u202b','\u202c','\u202d','\u202e','\u2066','\u2067','\u2068','\u2069') for x in body)==e['body_contains_bidi_controls'],bodySHA256=actual_hash,formfeeds=body.count('\f'),bidiControls=e['body_contains_bidi_controls'],linefeeds=body.count('\n'))
    a,b=e['source_de_txt_span'];ca,cb=e['citation_span']
    check(prefix+'source_span_and_citation_separation',body==source_text[a:b] and original['references']['citation_as_printed']==source_text[ca:cb] and ca>b and source_text[b:ca]=='\n' and original['references']['citation_as_printed'] not in body)
    check(prefix+'stable_identity_number_page',r['id']==e['record_id']==original['id'] and r['number']==original['number'] and r['number']['in_book']==index and r['number']['canonical'] is None and r['page']==original['page'] and r['page']['pdf']==e['source_pdf_pages'] and r['source']['record_locator']['json_pointer']=='/'+str(index-1))
    check(prefix+'original_pdf_and_credit',r['source']['sha256']==sm['source']['sha256'] and r['source']['original_file']==sm['source']['path'] and r['source']['original_metadata']['translation_reviser']==sm['source']['reviser_credit_as_printed'] and r['translator']['name']==sm['source']['translator_credit_as_printed'] and r['source']['original_metadata']['edition_date'] is None)
    check(prefix+'historical_current_policy_distinct',r['ai_translation']=='unknown' and r['translation_provenance']['ai_translation']=='unknown' and r['translation_provenance']['origin']=='unknown' and r['translation_provenance']['current_policy']['classification']=='human' and classification(r)=='human')
    check(prefix+'scope_no_arabic_commentary_counterparts',r['text_arabic'] is None and r['commentary']['arabic'] is None and r['commentary']['translation'] is None and r['counterpart_policy']['mode']=='disabled' and not r.get('language_versions') and not r['related_versions'] and r['references']['counterpart_verified'] is False and r['references']['canonical'] is None)
    readings=language_readings(r)
    check(prefix+'single_de_reading',len(readings)==1 and readings[0]['language']=='de' and readings[0]['text']==body and not readings[0]['comments'] and readings[0]['translation_origin']=='human')
    check(prefix+'markdown_exact_visible_body',mdsection.get('lang')=='de' and mdsection.find('p').get_text()==body and 'Translation origin: Human' in mdsection.get_text(' ',strip=True) and '<h3>de</h3>' in str(mdsection))
    # Source-specific citations must render in the references details, not be appended to the quotation.
    matched=[]
    for filepath in staticfiles:
        sp=BeautifulSoup(filepath.read_text(encoding='utf-8'),'html.parser')
        quot=sp.select('details.language-reading .text.quotation')
        if len(quot)==1 and quot[0].get_text()==body:
            matched.append((filepath,sp))
    check(prefix+'one_static_page_exact_quote',len(matched)==1,staticPage=matched[0][0].relative_to(EXEC).as_posix() if matched else None)
    sp=matched[0][1]
    visible=sp.get_text(' ',strip=True)
    check(prefix+'static_credit_human_and_source_pdf', 'Translator: Abū Suleyman' in visible and 'Translation origin: Human' in visible and 'Translation: Human' in visible and sm['source']['url'] in str(sp))
    check(prefix+'static_one_de_no_arabic_commentary',len(sp.select('details.language-reading'))==1 and len(sp.select('details.language-reading .text.quotation'))==1 and len(sp.select('details.language-reading .reading-translator'))==1 and not sp.select('details.language-reading [lang=ar]') and 'Arabic source text' not in visible and 'notes and commentary' not in visible)
    check(prefix+'printed_citation_rendered_in_separate_details',original['references']['citation_as_printed'] in sp.get_text() and original['references']['citation_as_printed'] not in sp.select_one('.text.quotation').get_text())
    check(prefix+'review_not_release_certification',r['review']['release_eligible'] is False and r['review']['certified_release_eligible'] is False and r['publication']['independent_qc_asserted'] is False and r['publication']['rights_clearance_asserted'] is False)
    entries.append(dict(id=r['id'],number=r['number']['in_book'],bodySHA256=actual_hash,pagePDF=r['page']['pdf'],formfeedCount=body.count('\f'),bidiControlCount=e['body_contains_bidi_controls'],linefeedCount=body.count('\n'),visibleTranslator='Abū Suleyman',currentDisplay='Human',historicalAIFlag=r['ai_translation'],historicalOrigin=r['translation_provenance']['origin'],staticPage=matched[0][0].relative_to(EXEC).as_posix(),staticSHA256=H(matched[0][0].read_bytes())))
check('static_no_extra_generated_records',set(r['id'] for r in projection)==set(e['id'] for e in embedded) and result['static']['languages']=={'de':3} and result['static']['shared_reader_occurrences']==0 and result['reader']['discovery_statistics']['reading_families']==3 and result['reader']['discovery_statistics']['grouped_occurrences']==0)
check('post_execution_all_inputs_identical_to_manifest',all(H((INPUT/x['path']).read_bytes())==x['sha256'] for x in manifest['payloads']))
result_obj={'task':'DE-NAWAWI-THREE-FINAL-ADAPTER-QC-001 missing executable Python scope continuation',
 'verdict':'PASS_BOUNDED_EXECUTABLE_SCOPE',
 'independentAssertions':len(CHECKS),'passes':sum(c['status']=='PASS' for c in CHECKS),'holds':sum(c['status']=='HOLD' for c in CHECKS),
 'scope':'Provided offline pinned actual-code subtree, German Nawawi 1-3 only; not fresh HEAD, full corpus, French/Hindi integration, or live site',
 'input':{'archiveSHA256':'e212e64d47fb51201747e10b8706d7e4088a49f05ea92a0b0742f4165407c050','manifestSHA256':H((INPUT/'MANIFEST.json').read_bytes()),'payloadsVerified':239,'targetSHA256':H((INPUT/'TARGET.json').read_bytes()),'recordsSHA256':H(fixture_path.read_bytes()),'materialManifestSHA256':H(source_manifest_path.read_bytes()),'originalPDFSHA256':H(source_path.read_bytes()),'sourceTextSHA256':H((DATA/'materials/de-suleyman-mobile-7bcee562/evidence/original-de.txt').read_bytes()),'harnessSHA256':H((INPUT/'run_actual_adapters.py').read_bytes()),'codeSHA256':{k:H((SCRIPTS/k).read_bytes()) for k in ['material_registry.py','build_reader.py','build_discovery.py','language_display.py','current_provenance.py']}},
 'actualRoutes':{'load_public_materials':'PASS','load_records':'PASS','readerBuild':'PASS','staticBuild':'PASS','markdownBuild':'PASS'},
 'generated':{'readerHTMLSHA256':H((EXEC/'private-reader.html').read_bytes()),'readerHTMLBytes':(EXEC/'private-reader.html').stat().st_size,'projectedSearchJSONLSHA256':H((EXEC/'fixture/search/records.jsonl').read_bytes()),'markdownPageSHA256':H(mdp.read_bytes()),'staticRecordPages':3,'markdownMdFiles':5,'readerManifestTotalFiles':result['reader']['markdown_files'],'staticReportSHA256':H((EXEC/'static/discovery-info.json').read_bytes())},
 'entries':entries,'checks':CHECKS,
 'limitations':['Source-fidelity review remains closed; this test independently checks bytes but not translation meaning.', 'This isolated fixture marks authorized pending public in its registration; no shared site was modified or deployed.', 'Pinned 2038/French002 ancestry is supplied as metadata but not independently proved from a separate ancestral packet.', 'Fresh HEAD/full-corpus CI, French/Hindi combined integration, hosted PDF retrieval and live publication are not tested.'],
 'publicWrite':False,'sourceRecordChanged':False}
REPORT.parent.mkdir(parents=True,exist_ok=True)
REPORT.write_text(json.dumps(result_obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS_BOUNDED_EXECUTABLE_SCOPE','assertions':len(CHECKS),'holds':0,'readerSHA256':result_obj['generated']['readerHTMLSHA256'],'streamSHA256':result_obj['generated']['projectedSearchJSONLSHA256'],'result':str(REPORT)},ensure_ascii=False))
