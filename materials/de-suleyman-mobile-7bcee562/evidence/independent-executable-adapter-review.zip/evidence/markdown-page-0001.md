# de / Forty Hadith of an-Nawawi

Edition: `suleyman-mobile-7bcee562` · Narrations 1–3 of 3.

[Edition index](README.md)

## Narration 1

[Open this narration online](https://blaghtayt-alt.github.io/Hadith-Bank/hadith/de/nawawi/suleyman-mobile-7bcee562/4b4f1b12f7eee630040f98b7.html)

<p dir="auto"><strong>Ḥadīth 01: Die Taten sind (nur)
entsprechend den Absichten</strong></p>

<p><strong>Hadith</strong> · A narration preserved from the source.</p>

<section class="language-reading" lang="de">
<h3>de</h3>

<p dir="auto">Vom Führer der Gläubigen, Abū-<br>
Ḥafṣ ʿUmar Ibn Al-Khaṭṭāb - möge<br>
Aḷḷāh mit ihm zufrieden sein -, wurde<br>
berichtet, dass er sagte: Ich hörte den<br>
Gesandten Aḷḷāhs - Aḷḷāhs Segen und<br>
Frieden auf ihm - sagen:<br>
„Die Taten sind nur entsprechend der<br>
Absichten und jedem (Menschen)<br>
gebührt nur das, was er beabsichtigte.<br>
Wer also seine Auswanderung zu<br>
Aḷḷāh und Seinem Gesandten vollzog,<br>
dessen Auswanderung ist zu Aḷḷāh<br>
und Seinem Gesandten (und wird<br>
entsprechend vergolten); und wer<br>
seine Auswanderung für einen Teil<br>
(einen Vorteil) des diesseitigen<br>
Lebens unternimmt oder (für) eine<br>
Frau, um sie zu heiraten, so ist seine<br>
Auswanderung zu dem, zu dem er<br>
ausgewandert ist (und wird<br>
entsprechend bewertet).&quot;</p>

<p dir="auto">[Sahih al-Bukhari · 1; Sahih Muslim · 1907]</p>

<p><strong>Source:</strong> <a href="https://reader.islamhouse.com/storage/downloads/pdf-mobile/de_2828850.pdf" target="_blank" rel="noopener noreferrer">Fassung der Vierzig An-Nawawiyyah (Aḥādīth) und den zusätzlichen acht Aḥādīth von Ibn Rajab</a> · Translation origin: Human</p>

<details class="reading-references">
<summary>de · references (2)</summary>

<p><strong>Sahih al-Bukhari · 1</strong><br>Citation for this quotation</p>

<p dir="auto">Dies überlieferten die beiden Imāme<br>
unter den Ḥadīth-Gelehrten: Imām<br>
Muḥammad Ibn Ismāʿīl Ibn Ibrāhīm<br>
Ibn Al-Muġīrah Ibn Bardizbah Al-<br>
Bukhārī Al-Juʿfī (Nr. 1) und Abū Al-<br>
Ḥusayn Muslim Ibn Al-Ḥajjāj Ibn<br>
Muslim Al-Quschayrī An-Naisābūrī<br>
(Nr. 1907) - möge Aḷḷāh mit beiden<br>
zufrieden sein - in ihren beiden<br>
authentischen Werken, welche die<br>
authentischsten (von Menschenhand)<br>
geschriebenen Bücher sind.</p>

<p dir="auto">Canonical mapping: printed source citation only no variant identity approval</p>

<p><strong>Sahih Muslim · 1907</strong><br>Citation for this quotation</p>

<p dir="auto">Dies überlieferten die beiden Imāme<br>
unter den Ḥadīth-Gelehrten: Imām<br>
Muḥammad Ibn Ismāʿīl Ibn Ibrāhīm<br>
Ibn Al-Muġīrah Ibn Bardizbah Al-<br>
Bukhārī Al-Juʿfī (Nr. 1) und Abū Al-<br>
Ḥusayn Muslim Ibn Al-Ḥajjāj Ibn<br>
Muslim Al-Quschayrī An-Naisābūrī<br>
(Nr. 1907) - möge Aḷḷāh mit beiden<br>
zufrieden sein - in ihren beiden<br>
authentischen Werken, welche die<br>
authentischsten (von Menschenhand)<br>
geschriebenen Bücher sind.</p>

<p dir="auto">Canonical mapping: printed source citation only no variant identity approval</p>

</details>

</section>

<p><strong>Source:</strong> <a href="https://reader.islamhouse.com/storage/downloads/pdf-mobile/de_2828850.pdf">Fassung der Vierzig An-Nawawiyyah (Aḥādīth) und den zusätzlichen acht Aḥādīth von Ibn Rajab</a><br>
<strong>Collection:</strong> Forty Hadith of an-Nawawi · <strong>Edition:</strong> suleyman-mobile-7bcee562<br>
<strong>Number:</strong> Number in collection 1 · Source entry Ḥadīth 01<br>
<strong>Page:</strong> PDF page 16, 17<br>
<strong>Translator:</strong> Abū Suleyman<br>
<strong>Narrator:</strong> Not named in the supplied source<br>
<strong>Translation origin:</strong> Human</p>

<details><summary>Source translation-origin history</summary>

<p dir="auto">Preserved source label: Unknown</p>
<p dir="auto">Preserved source AI-translation flag: unknown</p>
<p dir="auto">Original source metadata is preserved; current translation classification follows the recorded provenance evidence and owner policy.</p>

</details>

<p><strong>Source headings:</strong> Ḥadīth 01: Die Taten sind (nur)
entsprechend den Absichten</p>

<details><summary>Original import and review history</summary>

<p>Historical import status: source_fidelity_pass_final_adapter_pending · Historical independent Pro QC: pending_exact_final_adapter · Release: private_candidate</p>

<p dir="auto">No source-alignment issues listed.</p>

</details>

<details>
<summary>References</summary>

<p><strong>citation as printed</strong></p>
<p dir="auto">Dies überlieferten die beiden Imāme<br>
unter den Ḥadīth-Gelehrten: Imām<br>
Muḥammad Ibn Ismāʿīl Ibn Ibrāhīm<br>
Ibn Al-Muġīrah Ibn Bardizbah Al-<br>
Bukhārī Al-Juʿfī (Nr. 1) und Abū Al-<br>
Ḥusayn Muslim Ibn Al-Ḥajjāj Ibn<br>
Muslim Al-Quschayrī An-Naisābūrī<br>
(Nr. 1907) - möge Aḷḷāh mit beiden<br>
zufrieden sein - in ihren beiden<br>
authentischen Werken, welche die<br>
authentischsten (von Menschenhand)<br>
geschriebenen Bücher sind.</p>

<p><strong>Sahih al-Bukhari · 1</strong><br>Citation for this quotation</p>

<p dir="auto">Dies überlieferten die beiden Imāme<br>
unter den Ḥadīth-Gelehrten: Imām<br>
Muḥammad Ibn Ismāʿīl Ibn Ibrāhīm<br>
Ibn Al-Muġīrah Ibn Bardizbah Al-<br>
Bukhārī Al-Juʿfī (Nr. 1) und Abū Al-<br>
Ḥusayn Muslim Ibn Al-Ḥajjāj Ibn<br>
Muslim Al-Quschayrī An-Naisābūrī<br>
(Nr. 1907) - möge Aḷḷāh mit beiden<br>
zufrieden sein - in ihren beiden<br>
authentischen Werken, welche die<br>
authentischsten (von Menschenhand)<br>
geschriebenen Bücher sind.</p>

<p dir="auto">Canonical mapping: printed source citation only no variant identity approval</p>

<p><strong>Sahih Muslim · 1907</strong><br>Citation for this quotation</p>

<p dir="auto">Dies überlieferten die beiden Imāme<br>
unter den Ḥadīth-Gelehrten: Imām<br>
Muḥammad Ibn Ismāʿīl Ibn Ibrāhīm<br>
Ibn Al-Muġīrah Ibn Bardizbah Al-<br>
Bukhārī Al-Juʿfī (Nr. 1) und Abū Al-<br>
Ḥusayn Muslim Ibn Al-Ḥajjāj Ibn<br>
Muslim Al-Quschayrī An-Naisābūrī<br>
(Nr. 1907) - möge Aḷḷāh mit beiden<br>
zufrieden sein - in ihren beiden<br>
authentischen Werken, welche die<br>
authentischsten (von Menschenhand)<br>
geschriebenen Bücher sind.</p>

<p dir="auto">Canonical mapping: printed source citation only no variant identity approval</p>

</details>

<details>
<summary>Narrator and supplied tags</summary>

<pre>{&quot;narrator&quot;:{&quot;name&quot;:null,&quot;intro_as_printed&quot;:&quot;Vom Führer der Gläubigen, Abū-\nḤafṣ ʿUmar Ibn Al-Khaṭṭāb - möge\nAḷḷāh mit ihm zufrieden sein -, wurde\nberichtet, dass er sagte: Ich hörte den\nGesandten Aḷḷāhs - Aḷḷāhs Segen und\nFrieden auf ihm - sagen:\n&quot;},&quot;topic_tags&quot;:[],&quot;editorial_tags&quot;:[]}</pre>

</details>

<details>
<summary>Source locators and review issues</summary>

<p><strong>Occurrence ID:</strong> <code>de-suleyman-nawawi-01-7bcee562</code><br><strong>Canonical record:</strong> <a href="../../../../fixture/materials/de-suleyman-mobile-7bcee562/records.json">materials/de-suleyman-mobile-7bcee562/records.json</a><br><strong>JSON pointer:</strong> <code>/0</code><br><strong>Original file:</strong> <a href="../../../../fixture/materials/de-suleyman-mobile-7bcee562/source.pdf">materials/de-suleyman-mobile-7bcee562/source.pdf</a><br><strong>Original SHA-256:</strong> <code>7bcee56271a39c090d2cb1311f31b2fd3b2337f8d8a2b7eca4bbaa9f87926961</code></p><p><a href="https://github.com/blaghtayt-alt/Hadith-Bank/raw/main/materials/de-suleyman-mobile-7bcee562/source.pdf">Download PDF</a></p>

<p><strong>Review issues:</strong></p>
<p dir="auto">None listed in this record.</p>

</details>

---

## Narration 2

[Open this narration online](https://blaghtayt-alt.github.io/Hadith-Bank/hadith/de/nawawi/suleyman-mobile-7bcee562/09b96f19cf79de7c905d772e.html)

<p dir="auto"><strong>Ḥadīth 02: Das Eintreffen von
Gabriel, um die Muslime in ihrer
religiösen Angelegenheit zu
unterrichten</strong></p>

<p><strong>Hadith</strong> · A narration preserved from the source.</p>

<section class="language-reading" lang="de">
<h3>de</h3>

<p dir="auto">‫‪Ebenfalls von ʿUmar - möge Aḷḷāh‬‬<br>
‫‪mit ihm zufrieden sein - wird‬‬<br>
‫‪berichtet, dass er sagte:‬‬<br>
„Während wir an jenem Tag beim<br>
Gesandten Aḷḷāhs - Aḷḷāhs Segen und<br>
Frieden auf ihm - saßen, erschien vor<br>
uns ein Mann mit strahlend weißer<br>
Kleidung und nachtschwarzem Haar.<br>
Weder waren an ihm Spuren der<br>
Reise zu erkennen noch war er einem<br>
von uns bekannt. Schließlich setzte er<br>
sich zum Propheten - Aḷḷāhs Segen<br>
und Frieden auf ihm -, wobei er mit<br>
seinen Knien die Knie des Propheten<br>
- Aḷḷāhs Segen und Frieden auf ihm -<br>
berührte und die Handflächen auf<br>
seine Oberschenkel legte und (zu<br>
Ihm) sprach: ‚O Muḥammad, berichte<br>
mir vom Islām!’ Der Gesandte Aḷḷāhs<br>
- Aḷḷāhs Segen und Frieden auf ihm -<br>
antwortete daraufhin: ‚Der Islām ist<br>
deine Bezeugung, dass es keine<br>
anbetungswürdige Gottheit gibt,<br>
außer Aḷḷāh und dass Muḥammad der<br>
Gesandte Aḷḷāhs ist, dass du das<br>
Gebet verrichtest, die Almosensteuer<br>
(Zakāh) entrichtest, den Ramaḍān<br>
fastest und zu dem Haus (Aḷḷāhs, der<br>
Kaʿbah) pilgerst, sofern dir dies<br>
möglich ist.’<br>
Er (der Mann) sagte: ‚Du hast recht<br>
gesprochen,’ und wir wunderten uns<br>
über ihn, dass er ihn (zuerst) fragt<br>
und seine Worte dann selbst für wahr<br>
erklärt. Er sagte (weiter): ‚So berichte<br>
mir von der Überzeugung/dem<br>
Glaube (Al-Īmān)!’ Er antwortete:<br>
‚Dass du an Aḷḷāh, Seine Engel,<br>
Seine Bücher, Seine Gesandten und<br>
den Jüngsten Tag glaubst und dass du<br>
an die göttliche Vorherbestimmung<br>
(Al-Qadr), sowohl im Guten als auch<br>
im Schlechten glaubst.’<br>
Er (der Mann) sagte: ‚Du hast recht<br>
gesprochen. So berichte mir von der<br>
Vollkommenheit im Gottesdienst<br>
(Al-Iḥsān)!’ Er (der Prophet)<br>
antwortete: ‚Dass du Aḷḷāh (in solch<br>
einer Art und Weise) dienst, als<br>
würdest du Ihn sehen, und wenn du<br>
Ihn (auch) nicht siehst, so sieht Er<br>
doch dich.’<br>
Er (der Mann) sagte: ‚So berichte mir<br>
von der Stunde!’ Er (der Prophet)<br>
antwortete: ‚Der Befragte weiß nicht<br>
mehr darüber als der Fragende.’ Er<br>
(der Mann) sagte: ‚So berichte mir<br>
von ihren Anzeichen.’ Er (der<br>
Prophet) erwiderte: ‚(Zu ihren<br>
Anzeichen gehört), dass die Sklavin<br>
ihre eigene Herrin gebärt und dass du<br>
siehst, wie barfüßige, nackte und<br>
bedürftige Schafhirten sich (mit<br>
einem Mal) gegenseitig im Bauen<br>
von Hochhäusern zu übertreffen<br>
versuchen.’ Anschließend ging er fort<br>
und wir verblieben eine Weile. Dann<br>
sagte er (der Prophet): ‚O ʿUmar,<br>
weißt du wer der Fragende war?’ Ich<br>
antwortete: ‚Aḷḷāh und Sein<br>
Gesandter wissen es am besten.’ Er<br>
sagte: ‚Das war tatsächlich (der<br>
Engel) Gabriel, der zu euch<br>
gekommen ist, um euch in eurer<br>
Religion zu belehren.’“</p>

<p dir="auto">[Sahih Muslim · 8]</p>

<p><strong>Source:</strong> <a href="https://reader.islamhouse.com/storage/downloads/pdf-mobile/de_2828850.pdf" target="_blank" rel="noopener noreferrer">Fassung der Vierzig An-Nawawiyyah (Aḥādīth) und den zusätzlichen acht Aḥādīth von Ibn Rajab</a> · Translation origin: Human</p>

<details class="reading-references">
<summary>de · references (1)</summary>

<p><strong>Sahih Muslim · 8</strong><br>Citation for this quotation</p>

<p dir="auto">Überliefert von Muslim (8)</p>

<p dir="auto">Canonical mapping: printed source citation only no variant identity approval</p>

</details>

</section>

<p><strong>Source:</strong> <a href="https://reader.islamhouse.com/storage/downloads/pdf-mobile/de_2828850.pdf">Fassung der Vierzig An-Nawawiyyah (Aḥādīth) und den zusätzlichen acht Aḥādīth von Ibn Rajab</a><br>
<strong>Collection:</strong> Forty Hadith of an-Nawawi · <strong>Edition:</strong> suleyman-mobile-7bcee562<br>
<strong>Number:</strong> Number in collection 2 · Source entry Ḥadīth 02<br>
<strong>Page:</strong> PDF page 18, 19, 20, 21, 22<br>
<strong>Translator:</strong> Abū Suleyman<br>
<strong>Narrator:</strong> Not named in the supplied source<br>
<strong>Translation origin:</strong> Human</p>

<details><summary>Source translation-origin history</summary>

<p dir="auto">Preserved source label: Unknown</p>
<p dir="auto">Preserved source AI-translation flag: unknown</p>
<p dir="auto">Original source metadata is preserved; current translation classification follows the recorded provenance evidence and owner policy.</p>

</details>

<p><strong>Source headings:</strong> Ḥadīth 02: Das Eintreffen von
Gabriel, um die Muslime in ihrer
religiösen Angelegenheit zu
unterrichten</p>

<details><summary>Original import and review history</summary>

<p>Historical import status: source_fidelity_pass_final_adapter_pending · Historical independent Pro QC: pending_exact_final_adapter · Release: private_candidate</p>

<p dir="auto">No source-alignment issues listed.</p>

</details>

<details>
<summary>References</summary>

<p><strong>citation as printed</strong></p>
<p dir="auto">Überliefert von Muslim (8)</p>

<p><strong>Sahih Muslim · 8</strong><br>Citation for this quotation</p>

<p dir="auto">Überliefert von Muslim (8)</p>

<p dir="auto">Canonical mapping: printed source citation only no variant identity approval</p>

</details>

<details>
<summary>Narrator and supplied tags</summary>

<pre>{&quot;narrator&quot;:{&quot;name&quot;:null,&quot;intro_as_printed&quot;:&quot;‫‪Ebenfalls von ʿUmar - möge Aḷḷāh‬‬\n‫‪mit ihm zufrieden sein - wird‬‬\n‫‪berichtet, dass er sagte:‬‬\n\f&quot;},&quot;topic_tags&quot;:[],&quot;editorial_tags&quot;:[]}</pre>

</details>

<details>
<summary>Source locators and review issues</summary>

<p><strong>Occurrence ID:</strong> <code>de-suleyman-nawawi-02-7bcee562</code><br><strong>Canonical record:</strong> <a href="../../../../fixture/materials/de-suleyman-mobile-7bcee562/records.json">materials/de-suleyman-mobile-7bcee562/records.json</a><br><strong>JSON pointer:</strong> <code>/1</code><br><strong>Original file:</strong> <a href="../../../../fixture/materials/de-suleyman-mobile-7bcee562/source.pdf">materials/de-suleyman-mobile-7bcee562/source.pdf</a><br><strong>Original SHA-256:</strong> <code>7bcee56271a39c090d2cb1311f31b2fd3b2337f8d8a2b7eca4bbaa9f87926961</code></p><p><a href="https://github.com/blaghtayt-alt/Hadith-Bank/raw/main/materials/de-suleyman-mobile-7bcee562/source.pdf">Download PDF</a></p>

<p><strong>Review issues:</strong></p>
<p dir="auto">None listed in this record.</p>

</details>

---

## Narration 3

[Open this narration online](https://blaghtayt-alt.github.io/Hadith-Bank/hadith/de/nawawi/suleyman-mobile-7bcee562/92dc57f6c804db32c1298235.html)

<p dir="auto"><strong>Ḥadīth 03: Der Islām wurde auf
fünf (Säulen) gebaut</strong></p>

<p><strong>Hadith</strong> · A narration preserved from the source.</p>

<section class="language-reading" lang="de">
<h3>de</h3>

<p dir="auto">Abū ʿAbdir-Raḥmān ʿAbduḷḷāh Ibn<br>
ʿUmar Ibn Al-Khaṭṭāb - möge Aḷḷāh<br>
mit beiden zufrieden sein - berichtete,<br>
dass er sagte: Ich hörte den<br>
Gesandten Aḷḷāhs - Aḷḷāhs Segen und<br>
Frieden auf ihm - sagen:<br>
„Der Islām wurde auf fünf (Säulen)<br>
gebaut: (auf) dem Bekenntnis, dass es<br>
keine anbetungswürdige Gottheit<br>
gibt, außer Aḷḷāh und dass<br>
Muḥammad der Gesandte Aḷḷāhs ist,<br>
dem Verrichten des Gebets, der<br>
Abgabe der Almosensteuer (Zakāt),<br>
der Pilgerfahrt zum Hause (Aḷḷāhs)<br>
und dem Fasten im Ramaḍān.&quot;</p>

<p dir="auto">[Sahih al-Bukhari · 8; Sahih Muslim · 16]</p>

<p><strong>Source:</strong> <a href="https://reader.islamhouse.com/storage/downloads/pdf-mobile/de_2828850.pdf" target="_blank" rel="noopener noreferrer">Fassung der Vierzig An-Nawawiyyah (Aḥādīth) und den zusätzlichen acht Aḥādīth von Ibn Rajab</a> · Translation origin: Human</p>

<details class="reading-references">
<summary>de · references (2)</summary>

<p><strong>Sahih al-Bukhari · 8</strong><br>Citation for this quotation</p>

<p dir="auto">Überliefert von Al-Bukhārī (8) und<br>
Muslim (16)</p>

<p dir="auto">Canonical mapping: printed source citation only no variant identity approval</p>

<p><strong>Sahih Muslim · 16</strong><br>Citation for this quotation</p>

<p dir="auto">Überliefert von Al-Bukhārī (8) und<br>
Muslim (16)</p>

<p dir="auto">Canonical mapping: printed source citation only no variant identity approval</p>

</details>

</section>

<p><strong>Source:</strong> <a href="https://reader.islamhouse.com/storage/downloads/pdf-mobile/de_2828850.pdf">Fassung der Vierzig An-Nawawiyyah (Aḥādīth) und den zusätzlichen acht Aḥādīth von Ibn Rajab</a><br>
<strong>Collection:</strong> Forty Hadith of an-Nawawi · <strong>Edition:</strong> suleyman-mobile-7bcee562<br>
<strong>Number:</strong> Number in collection 3 · Source entry Ḥadīth 03<br>
<strong>Page:</strong> PDF page 24, 25<br>
<strong>Translator:</strong> Abū Suleyman<br>
<strong>Narrator:</strong> Not named in the supplied source<br>
<strong>Translation origin:</strong> Human</p>

<details><summary>Source translation-origin history</summary>

<p dir="auto">Preserved source label: Unknown</p>
<p dir="auto">Preserved source AI-translation flag: unknown</p>
<p dir="auto">Original source metadata is preserved; current translation classification follows the recorded provenance evidence and owner policy.</p>

</details>

<p><strong>Source headings:</strong> Ḥadīth 03: Der Islām wurde auf
fünf (Säulen) gebaut</p>

<details><summary>Original import and review history</summary>

<p>Historical import status: source_fidelity_pass_final_adapter_pending · Historical independent Pro QC: pending_exact_final_adapter · Release: private_candidate</p>

<p dir="auto">No source-alignment issues listed.</p>

</details>

<details>
<summary>References</summary>

<p><strong>citation as printed</strong></p>
<p dir="auto">Überliefert von Al-Bukhārī (8) und<br>
Muslim (16)</p>

<p><strong>Sahih al-Bukhari · 8</strong><br>Citation for this quotation</p>

<p dir="auto">Überliefert von Al-Bukhārī (8) und<br>
Muslim (16)</p>

<p dir="auto">Canonical mapping: printed source citation only no variant identity approval</p>

<p><strong>Sahih Muslim · 16</strong><br>Citation for this quotation</p>

<p dir="auto">Überliefert von Al-Bukhārī (8) und<br>
Muslim (16)</p>

<p dir="auto">Canonical mapping: printed source citation only no variant identity approval</p>

</details>

<details>
<summary>Narrator and supplied tags</summary>

<pre>{&quot;narrator&quot;:{&quot;name&quot;:null,&quot;intro_as_printed&quot;:&quot;Abū ʿAbdir-Raḥmān ʿAbduḷḷāh Ibn\nʿUmar Ibn Al-Khaṭṭāb - möge Aḷḷāh\nmit beiden zufrieden sein - berichtete,\ndass er sagte: Ich hörte den\nGesandten Aḷḷāhs - Aḷḷāhs Segen und\nFrieden auf ihm - sagen:\n&quot;},&quot;topic_tags&quot;:[],&quot;editorial_tags&quot;:[]}</pre>

</details>

<details>
<summary>Source locators and review issues</summary>

<p><strong>Occurrence ID:</strong> <code>de-suleyman-nawawi-03-7bcee562</code><br><strong>Canonical record:</strong> <a href="../../../../fixture/materials/de-suleyman-mobile-7bcee562/records.json">materials/de-suleyman-mobile-7bcee562/records.json</a><br><strong>JSON pointer:</strong> <code>/2</code><br><strong>Original file:</strong> <a href="../../../../fixture/materials/de-suleyman-mobile-7bcee562/source.pdf">materials/de-suleyman-mobile-7bcee562/source.pdf</a><br><strong>Original SHA-256:</strong> <code>7bcee56271a39c090d2cb1311f31b2fd3b2337f8d8a2b7eca4bbaa9f87926961</code></p><p><a href="https://github.com/blaghtayt-alt/Hadith-Bank/raw/main/materials/de-suleyman-mobile-7bcee562/source.pdf">Download PDF</a></p>

<p><strong>Review issues:</strong></p>
<p dir="auto">None listed in this record.</p>

</details>

---


[Edition index](README.md)
