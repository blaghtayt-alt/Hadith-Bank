# DE-NAWAWI-THREE-FINAL-ADAPTER-QC-001 — executable Python continuation

**Verdict: PASS — bounded executable scope.** An independently executed run of the actual pinned production registry, reader, static and Markdown code completed with exit code 0 and empty stderr. An additional **67 independent assertions passed; 0 holds**. No source or code input was modified. This completes only the missing executable Python scope of the existing review; it is not release approval.

## Scope and boundaries

- Source and meaning review, six desktop/mobile browser checks, punctuation and historical Arabic glyph issues were already closed and were **not re-reviewed**.
- Pinned, supplied actual-code subtree with the isolated German Nawawi 1–3 fixture. Full 50-entry source not assessed.
- Root's supporting execution JSON was used only as a claim to compare with independently reproduced outputs.
- No external network, package installation, API secret, repository mutation, public write, worker or deployment was used. Internet/hosted links appearing in output were not visited.

## Exact input integrity

| Item | Independently calculated SHA-256 |
|---|---|
| Uploaded runnable ZIP | `e212e64d47fb51201747e10b8706d7e4088a49f05ea92a0b0742f4165407c050` |
| ZIP MANIFEST.json | `8eed98b228f8419d935984302bbb686095d8874805d4e034e37746e6e5542685` |
| TARGET.json | `07132b132096a1e4a91dbc731447e7437a4f070378c7000a72eadaea090150c3` |
| Canonical three records | `def2c3569b7b1d93e6b3fbd7f4687d2f43431f87eee3c1a6c876bd704f668732` |
| Material manifest | `373690b0ba8708d1da00277047525544ef56d4852d1506bf32ba16d57a508e0d` |
| Original 120-page mobile PDF | `7bcee56271a39c090d2cb1311f31b2fd3b2337f8d8a2b7eca4bbaa9f87926961` |
| Original extracted German source text | `7e08e2defed73dc1081088c2f49b26bf51f5a08b5306a37de8c75bcc92d29be5` |
| Supplied execution harness | `ff9229eafdadbd87840aa1caef66570489876ada8a59ea749c50c06f161380a5` |

The input archive is 3,005,851 bytes. All 240 ZIP members passed CRC; all 239 of 239 manifest payloads passed exact-byte size and SHA-256 checks before and after execution. There were no extra or missing manifest files.

### Pinned actual Python module hashes

| Module | SHA-256 |
|---|---|
| `material_registry.py` | `0aafebef031e952e45d4a426692976a184cd362babd63e63fbcfb0d1595001d0` |
| `build_reader.py` | `3be859ea6b7ce807b750a07969cdd19c3d4f3581f49f0cc3afe5e972728e9d44` |
| `build_discovery.py` | `42474d02cd14526e6d1bedd0823044a2306254550895006b1b818bfb29503069` |
| `language_display.py` | `909279a48e0521167a3ff1f7022e8159b1737eba20395202378dd966792bd18f` |
| `current_provenance.py` | `ab2e4a45eba6a5cb3b580da2a2e9c3b6ec84c8d1a07d5355a2e4c0bab4220243` |

The ancestry statement that this exact subtree was also used in the prior 2038/French002 run is recorded in TARGET.json; that ancestry was **not independently re-proved** because the separate ancestor packet was not supplied. All supplied local code hashes were independently verified against the current packet manifest.

## Actual executable run

Run: `PYTHONDONTWRITEBYTECODE=1 python run_actual_adapters.py --output execution-independent-reviewer` from the extracted packet root. Execution used Python 3.13.5. The output folder was new and isolated, all original payloads remained byte-identical.

| Route | Result / observed output |
|---|---|
| `material_registry.load_public_materials` | PASS; 1 registered material, 3 projected German records |
| `build_reader.load_records` | PASS; 3 records, exact projected-object equality |
| `build_reader.build` | PASS; standalone 385,297-byte gzip-base64 self-contained reader, 3 readings |
| `build_discovery.build` | PASS; 3 static record pages, 3 DOM-verified, 12 output files, 46,941 site bytes |
| Reader Markdown generation | PASS; 1 three-narration page + 4 Markdown index/README pages + 1 JSON reader manifest |

The build reader reports `markdown_files: 6` inclusive of `reader-manifest.json` while the harness counts **5 Markdown files** ending in .md; these reports are consistent. The generated search stream SHA-256 is `9435e561d9e2f3d41e96c81198bfc34cc8409b25b681866ae6d1f43f7eb3be16`; the standalone reader HTML SHA-256 is `c892ead35ff7f3db55791561710af0a5744ad9e79669b9e14813e5a265441ef4`. Its gzip-base64 payload was independently decoded and checked for complete object equality with the three projected records.

## Independent records, boundaries and presentation checks

| Source Nawawi entry | Stable occurrence ID | Exact German body SHA-256 | Formfeeds | Bidi controls | Linefeeds |
|---|---|---|---:|---:|---:|
| 1 | `de-suleyman-nawawi-01-7bcee562` | `c41356ca27bbdf340958eb30f21342b80df70fc703ce6801d5df0cc9d71f0800` | 1 | 0 | 20 |
| 2 | `de-suleyman-nawawi-02-7bcee562` | `158ee711006a56238c2c044fa5b2212282f8a7bdd813cfc5448fdeb906a0a3e8` | 4 | 12 | 74 |
| 3 | `de-suleyman-nawawi-03-7bcee562` | `724f6856c6f524362d9b1e64ddbfd49f54d19073e606b8178964311563320678` | 1 | 0 | 14 |

All three German texts are still verbatim contiguous source-text spans from the archived `original-de.txt`, with exact UTF-8 hashes. Each separately stored printed citation also matches its disjoint source-text span. Citation references are rendered outside the quotation body on generated static record pages.

- Exact local Nawawi number, stable occurrence ID, PDF page arrays (16–17, 18–22, 24–25), source-file hash, per-record source locator and canonical-null mapping preserved. Source and reader report 3 distinct reading families, no asserted grouped/counterpart identity.
- Translator display credits **Abū Suleyman**; the separate revision credit **Muḥammad S. Al-Almany** is retained in original source metadata. The PDF preface date (2 July 2017) and PDF creation metadata (8 December 2020) do not become a publication date, which remains null.
- The current owner policy resolves display to **Human** via actual `classification`. Historical per-record `ai_translation: unknown` and `translation_provenance.origin: unknown` are preserved unchanged.
- Actual `language_readings` yields exactly one de reading for each source; `text_arabic` is null, commentary fields null, related versions empty, counterpart mode disabled, canonical identity null, and no unapproved Arabic or commentary reading appears.
- Each generated static HTML quotation was extracted by independent DOM parsing and is **codepoint-for-codepoint equal** to its original body, as is each generated Markdown quotation. This verifies original punctuation, parentheses, line breaks, formfeeds and all 12 entry-2 bidi controls were not modified by these routes.
- The local fixture has publication authorization metadata for a pending-review build, but per-record `review.release_eligible` and `certified_release_eligible` stay false. No external public release occurred.

## Test files and evidence

- `audit/INDEPENDENT_ASSERTIONS.py`: independently authored, read-only assertions against the actual modules and all generated artifacts.
- `audit/INDEPENDENT_RESULTS.json`: all 67 test results, per-entry evidence, source/code/output hashes and scoped limitations.
- `logs/ACTUAL-PYTHON-ROUTES.stdout.log`, `logs/ACTUAL-PYTHON-ROUTES.stderr.log`: literal actual-run console logs.
- `logs/INDEPENDENT_ASSERTIONS.stdout.log`, `logs/INDEPENDENT_ASSERTIONS.stderr.log`: independently run assertions.
- `evidence/private-reader.html`, `evidence/static-hadith-*.html`, `evidence/markdown-page-0001.md`, `evidence/registered-projected-records.jsonl`, `evidence/ACTUAL-PYTHON-ROUTES-RESULT.json`: actual generated code-route outputs, not simulated previews.

The first version of **our separate audit script** failed on a harmless `Path + str` assertion typo *after* the production harness had already passed. We corrected only that newly authored audit script, preserved the initial traceback in `logs/INDEPENDENT_ASSERTIONS.initial-audit-typo.stderr.log`, and reran it successfully (67/67). Production code and fixture were unchanged.

## Explicit non-coverage

Fresh repository HEAD, full-corpus CI, combined French/Hindi integration and code reconciliation, hosted PDF link retrieval, live UI, global counterpart-matching behavior, rights clearance, release certification and deployment were **not tested or approved** by this result. The archived Arabic source extraction/font-`t` defect is unchanged; no Arabic transcription or repair occurred.

**Final disposition: PASS for the sole missing executable Python adapter scope; all other previously stated publication/integration gates remain separate.**
