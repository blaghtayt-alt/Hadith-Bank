# German Nawawi 1–3 — bounded independent source-fidelity report

**Status:** Source-fidelity sampling of entries 1–3 completed; **NOT** full-book QC, an import approval, or publication clearance. **No repository writes, no AI-translated Hadith, no textual fixes, no license rechecks.**

## Verified input and provenance

- Submitted ZIP: `german-sample-packet.zip` — **908,081** bytes; SHA-256 `26b1855a06ddf611b9b5f1831e80da9ced331bf85591c9c12b2436115fea8e47`. All eight ZIP members CRC-valid. All seven listed manifest digests match their extracted bytes.
- Source: `de_mobile.pdf`, **933,533 bytes**, **120 physical PDF pages**, SHA-256 `7bcee56271a39c090d2cb1311f31b2fd3b2337f8d8a2b7eca4bbaa9f87926961`.
- Exact `de.txt`: **141,225 bytes**, SHA-256 `7e08e2defed73dc1081088c2f49b26bf51f5a08b5306a37de8c75bcc92d29be5`; reproduced **byte for byte** with `pdftotext -layout -enc UTF-8` on the attached PDF. This **does not** guarantee correct extracted Arabic order.
- Source **PDF page 13** states **“Übersetzung von Abū Suleyman”**, **“Überarbeitung von Muḥammad S. Al-Almany”**. Page 15 signs the preface **“Abū Suleymān, 08. Schawwāl 1438 / 02.07.2017”**. PDF metadata created `2020-12-08 20:31:39 UTC` by Microsoft Word 2010.
- Evidence supports a named historical translation lineage distinct from Hadithsammlung.de. It does **not** prove all historical production steps or the exact underlying Arabic print edition.
- This edition numbers **50** texts: **Nawawi 01–42** and **Ibn Rajab supplement 43–50**. Supplement must never be mapped to primary Nawawi.
- The packet's page-13 image visibly matches a fresh render of the same PDF page, though sizes differ; pixel identity is not claimed. The independently rendered local sample pages and online reader screenshots agree in the assessed passages. An online direct-download byte comparison was not possible in this runtime (DNS unavailable), so remote byte identity is **unverified**.

## Exactly what was screened

| Nawawi | Physical PDF pages | Boundaries and checks | Bounded German conclusion |
|---|---:|---|---|
| 1, *Actions / intentions* | **15–18** | Preface/title p15, German body pp16–17, Arabic pp17–18; narrator Umar; Bukhari **1**, Muslim **1907** | No material meaning defect established; parenthetical translator explanations must stay differentiated from literal Arabic. |
| 2, *Gabriel / Islam, iman and ihsan* | **18–24** | German pp18–22; Arabic pp22–24; narrator Umar; Muslim **8** | All core episodes checked; plural **فلبثنا** corresponds to German plural; not a demonstrated mistranslation; all three building-sign descriptors present. |
| 3, *Five pillars* | **24–25** | German pp24–25, Arabic p25; narrator Abdullah ibn Umar; Bukhari **8**, Muslim **16** | No material meaning defect established; source pillar order includes pilgrimage then fasting, matching German and reference. |

Page 25 also starts entry 4; its text was **not** reviewed as part of this scope.

## Evidence-backed issue and observation ledger

### DE-N02-AR-VARIANT-01 — Arabic plural/singular; do not silently harmonize

- **German source p22:** `wir verblieben eine Weile.`
- **Source-image Arabic p23:** `فَلَبِثْنَا مَلِيًّا` — first-person plural.
- **Standard Nawawi 2 as displayed on Sunnah.com:** `فَلَبِثْتُ مَلِيًّا` — first-person singular. Primary Muslim 8a also presents a singular narrator in its English rendering.
- **Independent evidence of plural tradition:** An Arabic IslamHouse Nawawi commentary prints `فلبثنا مليًا` in hadith 2. An Arabic textual study also identifies a plural variant in manuscript witnesses; no claim is made that this exact German edition derives from those particular witnesses.
- **Finding:** **source-specific translation is faithful at this clause**. There is an edition-dependent Arabic variant. Preserve both source witnesses and mark the canonical alignment as variant/undetermined; **do not mark “wir” as a typo**.
- **Hold:** Canonical Arabic/reference normalization only, not original German wording.

### DE-AR-EXTRACTION-01 — machine-extracted Arabic not usable verbatim

- **PDF pp17–18, 22–25**: rendered Arabic is readable, but `de.txt` has split/reordered tokens and U+202B/U+202C bidi controls. For example, p23 raw extracted context surrounding the visually verified `فَلَبِثْنَا` is fragmented rather than a faithful contiguous Arabic transcription.
- `de.txt` matches a fresh Poppler extraction SHA exactly, ruling out a later packet conversion error but **not** establishing accurate Arabic text.
- **Hold:** Arabic raw-extraction components for **all three entries**; use source images plus native verification before creating any Arabic bank field. **Do not** treat this as a German translation error.

### DE-AR-NARRATOR-GLYPH-01 — isolated `t` character in Arabic narrator areas

- **PDF p17**, after the Arabic Umar ibn al-Khattab narrator line; **PDF p22**, alongside the Arabic `عن عمر` line. The source image displays a Latin-looking `t`, and raw text extraction contains `t`.
- The intended sign/honorific is uncertain. **No expansion or substitution** is justified from the German file alone. This does not establish missing prophetic matn.
- **Hold:** those narrator/honorific components only, within the broader Arabic extraction hold.

### DE-N01-GLOSS-01 — German explanatory additions are source text, not extra Arabic matn

- **PDF p16:** `(und wird entsprechend vergolten)`; **p17:** `(und wird entsprechend bewertet)`; other green-parenthesized clarifications occur in entry 1.
- These are printed translator explanations alongside a substantially matching standard Arabic hadith; not demonstrated semantic errors.
- **Decision:** Preserve exactly in the German source. If future field models separate explanatory glosses, retain their provenance and alignment; **do not delete parentheses**.

### DE-N02-N03-GLOSS-01 — explanatory phrase boundaries

- **Entry 2, PDF p22:** `(mit einem Mal)`.
- **Entry 3, PDF p24:** `(Säulen)` and `(auf)` and further parenthetical explanatory wording.
- These are visible source additions, not exact Arabic word-for-word tokens; no meaning failure proven.
- **Decision:** Preserve verbatim; optionally tag as translator interpretation only in a structured data model; no replacement.

### DE-PREF-TYPO-01 — ancillary preface typo, not a Hadith defect

- **PDF p15:** `inlusive` (as printed). This is outside hadith 1–3 narration and should not be silently corrected or imported into a hadith record.

## Important negative results

- **No missing `العراة` descriptor** in German entry 2. PDF p22 explicitly prints `barfüßige, nackte und bedürftige Schafhirten`, corresponding to Arabic p23 `الحفاة العراة العالة رعاء الشاء`.
- Entry 3 retains the five pillars and printed Bukhari/Muslim references. Entry 1 retains the Umar attribution and intentions/hijra subject matter.
- There is **no independently confirmed substantive German mistranslation** in this **bounded** sample. This is not a guarantee of faultless German or approval of unseen entries.

## Honest coverage, non-actions, and outstanding limits

Only **3/50** numbered texts received this bounded comparison (3/42 Nawawi; **0/8 Ibn Rajab supplement**). Source/provenance PDF pages **13–15** were additionally inspected; the source body reviewed was restricted to entries **1–3**, which intersect physical PDF pages **15–25**. This is not a full-book reading or full-page Arabic glyph QC.

The same-PDF Arabic-to-German comparisons were done from source images, not only raw extracted text, against the cited Nawawi 1–3 reference. There is **no** original print-edition binary, independently validated translator workflow, all-branch overlap audit, or release authorization. The prior `overlap.json` assertion about commit `bc0ef56b2358e20f425e961f0bac6511f30fed20` was inspected as **provided evidence**, not a fresh repository verification. No repo writes, PRs, publication, license checks or machine-generated Hadith translations occurred.

## Cited reference points

1. Attached original: `de_mobile.pdf`, pp13, 15–25; extracted file `de.txt` (byte-identical Poppler regeneration); attached `german-manifest.json` and `de-page13.png`.
2. Institutional source mobile reader: https://reader.islamhouse.com/storage/downloads/pdf-mobile/de_2828850.pdf
3. Nawawi 1: https://sunnah.com/nawawi40:1
4. Nawawi 2: https://sunnah.com/nawawi40:2
5. Nawawi 3: https://sunnah.com/nawawi40:3
6. Original-source parallel: https://sunnah.com/muslim:8a
7. Arabic commentary evidencing plural wording: https://d1.islamhouse.com/data/ar/ih_books/single9/ar_alnawawy.pdf (PDF p5, index4).
8. Arabic manuscript-variant editorial note: https://files.a-alqasim.com/books/mutoon/0402MutoonHawaashee.pdf (the larger external PDF could not be independently screenshot due remote size; use as secondary context, not conclusive source-edition identification).

Hashes, exact raw byte offsets and page hashes are in the companion JSON ledger and manifest. All wording decisions are **annotation-only**; source inputs have not been edited.
