#!/usr/bin/env python3
"""Read-only German Nawawi 1-3 private adapter evidence verifier.
Usage: python verify_data_adapter.py MAIN_PACKET.zip SUPPLEMENT_PACKET.zip
Requires: Python 3.10+, pdftotext/pdfinfo (Poppler), BeautifulSoup4.
No external services, repository writes, or source changes.
"""
from __future__ import annotations
import hashlib, io, json, re, subprocess, sys, unicodedata, zipfile
from pathlib import Path
from bs4 import BeautifulSoup
H=lambda b:hashlib.sha256(b).hexdigest()
EXPECTED={
    'main': {'bytes': 2185213, 'sha256': '65488cb8d29e288a9a0a504e8ad6199d266db9c1bbc1f7d2560ff0b3337da47e'},
    'supp': {'bytes': 613048, 'sha256': '86550ad77a03ab173d4f5d7d318100fe90d4a4a9d7851b4e20314482135c6c7c'},
    'candidate': {'bytes': 1849713, 'sha256': 'a68589ef3f3d3c9c2ac0c0d75f356461074df666e8b69df68957e77f0e1b5046'},
    'records': {'bytes': 19199, 'sha256': 'def2c3569b7b1d93e6b3fbd7f4687d2f43431f87eee3c1a6c876bd704f668732'},
    'source_pdf': {'bytes': 933533, 'sha256': '7bcee56271a39c090d2cb1311f31b2fd3b2337f8d8a2b7eca4bbaa9f87926961'},
    'de_txt': {'bytes': 141225, 'sha256': '7e08e2defed73dc1081088c2f49b26bf51f5a08b5306a37de8c75bcc92d29be5'}
}

def require(cond, msg):
    if not cond:raise AssertionError(msg)

def identity(name, data):
    expect=EXPECTED[name]
    require(len(data)==expect['bytes'],f'{name}: incorrect byte size')
    require(H(data)==expect['sha256'],f'{name}: incorrect SHA')
    return {'bytes':len(data),'sha256':H(data),'status':'PASS'}

def validate_manifest(z, key):
    m=json.loads(z.read('MANIFEST.json'))
    entries=m['payloads'] if isinstance(m.get('payloads'),list) else [dict(path=k,**v) for k,v in m.items()]
    for item in entries:
        data=z.read(item['path'])
        require(len(data)==item['bytes'] and H(data)==item['sha256'],f'{key}: mismatch {item["path"]}')
    return {'status':'PASS','payload_count':len(entries),'manifest_sha256':H(z.read('MANIFEST.json'))}

def validate_stage_manifest(z):
    base='materials/de-suleyman-mobile-7bcee562/'
    m=json.loads(z.read(base+'PRIVATE_STAGE_MANIFEST.json'))
    for entry in m['payloads']:
        d=z.read(base+entry['path'])
        require(len(d)==entry['bytes'] and H(d)==entry['sha256'],'Stage mismatch: '+entry['path'])
    return {'status':'PASS','payload_count':len(m['payloads']),'manifest_sha256':H(z.read(base+'PRIVATE_STAGE_MANIFEST.json'))}

def main(a,b):
    results={'taskId':'DE-NAWAWI-THREE-FINAL-ADAPTER-QC-001','scope':'private candidate N1–N3 only','archive_integrity':{},'pdf_reproduction':{},'candidate':{},'records':[],'projection':{},'limitations':[]}
    for key,path in [('main',a),('supp',b)]:
        results['archive_integrity'][key]=identity(key,Path(path).read_bytes())
    with zipfile.ZipFile(a) as main,zipfile.ZipFile(b) as supp:
        require(main.testzip() is None and supp.testzip() is None,'CRC error in outer ZIP')
        results['archive_integrity']['main']['manifest']=validate_manifest(main,'main')
        results['archive_integrity']['supp']['manifest']=validate_manifest(supp,'supp')
        with zipfile.ZipFile(io.BytesIO(main.read('candidate/German_Nawawi_Three_Private_Bank_Stage_v001.zip'))) as stage:
            results['archive_integrity']['candidate']=identity('candidate',main.read('candidate/German_Nawawi_Three_Private_Bank_Stage_v001.zip'))
            require(stage.testzip() is None,'candidate CRC fail')
            results['archive_integrity']['candidate']['manifest']=validate_stage_manifest(stage)
            root='materials/de-suleyman-mobile-7bcee562/'
            raw_bytes=stage.read(root+'evidence/original-de.txt')
            src=stage.read(root+'source.pdf')
            records_bytes=stage.read(root+'records.json')
            results['candidate']['record_bytes']=identity('records',records_bytes)
            results['candidate']['pdf_bytes']=identity('source_pdf',src)
            results['candidate']['raw_de_bytes']=identity('de_txt',raw_bytes)
            original_source_qc=stage.read(root+'evidence/original-source-qc.zip')
            require(H(original_source_qc)=='769598a660b88f29737eedfc4a38b2ab5657bf60060efc6f850b57b32e1f975f','old QC ZIP mismatch')
            with zipfile.ZipFile(io.BytesIO(original_source_qc)) as z:
                require(z.testzip() is None,'old QC CRC fail')
            with zipfile.ZipFile(io.BytesIO(stage.read(root+'evidence/original-input-packet.zip'))) as z:
                require(z.testzip() is None,'old input CRC fail')
            records=json.loads(records_bytes)
            spans=json.loads(stage.read(root+'evidence/selected-source-spans.json'))
            doc=json.loads(stage.read(root+'document_metadata.json'))
            main_req=json.loads(main.read('REQUEST.json'))
            require(len(records)==len(spans)==len(main_req['privateStage']['recordsMappings'])==3,'not 3 records')
            raw=raw_bytes.decode('utf-8')
            require(raw.count('\f')==120,'unexpected formfeed page count')
            require(doc['originalGermanSourceMetadata']['pages']==120,'source page metadata mismatch')
            require(doc['originalGermanSourceMetadata']['sha256']==H(src),'source PDF hash mismatch')
            require(doc['originalGermanSourceMetadata']['translator']=='Abū Suleyman','wrong source credit')
            require(doc['originalGermanSourceMetadata']['reviewer']=='Muḥammad S. Al-Almany','wrong reviser')
            require(doc['originalGermanSourceMetadata']['translation_preface_date']=='2017-07-02','wrong preface date')
            require(doc['originalGermanSourceMetadata']['pdf_creation_metadata']=='2020-12-08 UTC','wrong pdf metadata date')
            # Independent source-to-text reproduction: no OCR or linguistic editing.
            with __import__('tempfile').TemporaryDirectory() as td:
                pdf=Path(td)/'original.pdf';pdf.write_bytes(src)
                out=subprocess.run(['pdftotext','-layout','-enc','UTF-8',str(pdf),'-'],capture_output=True,check=True).stdout
                info=subprocess.run(['pdfinfo',str(pdf)],capture_output=True,text=True,check=True).stdout
            require(out==raw_bytes,'pdftotext PDF source not byte-exact to archived de.txt')
            pages=int(re.search(r'^Pages:\s*(\d+)',info,re.M).group(1))
            require(pages==120,'PDF page count mismatch')
            results['pdf_reproduction']={'status':'PASS','pdftotext_output_sha256':H(out),'exact_original_de_txt':True,'page_count':pages,'source_pdf_sha256':H(src),'pdf_creation_date_is_not_published_date':True}
            seen=set()
            for i,(r,s,req) in enumerate(zip(records,spans,main_req['privateStage']['recordsMappings']),1):
                rid=f'de-suleyman-nawawi-{i:02d}-7bcee562'
                require(r['id']==s['record_id']==req['record_id']==rid,'record ID not stable')
                require(rid not in seen,'duplicate id');seen.add(rid)
                require(r['language']=='de' and r['book_key']=='nawawi','wrong language/book')
                require(r['record_type']=='hadith_occurrence','wrong record type')
                require(r['number']=={'source_entry_id':f'Ḥadīth {i:02d}','in_book':i,'canonical':None},'wrong numbering')
                require(r['page']['pdf']==s['source_pdf_pages']==req['source_pdf_pages'],'page binding changed')
                start,end=s['source_de_txt_span']
                require([start,end]==[r['extraction']['raw_source_start_codepoint'],r['extraction']['raw_source_end_codepoint_exclusive']],'offset mismatch')
                body=r['text']['translation']; require(body==raw[start:end],'not contiguous verbatim raw source')
                require(len(body)==end-start==s['body_codepoints'],'codepoint length mismatch')
                require(H(body.encode())==s['source_de_txt_span_sha256_utf8']==req['source_de_txt_span_sha256_utf8'],'body SHA mismatch')
                require(raw[:start].count('\f')+1==min(r['page']['pdf']) and raw[:end].count('\f')+1==max(r['page']['pdf']),'actual text-page binding mismatch')
                require(r['narrator']['intro_as_printed']==body[:len(r['narrator']['intro_as_printed'])],'narrator intro not prefix')
                ff=body.count('\f');bidi=sum(ord(c) in (0x202a,0x202b,0x202c) for c in body)
                require(ff==s['body_contains_formfeeds'] and bidi==s['body_contains_bidi_controls'],'source control chars changed')
                require(not re.search(r'(?<!\w)t(?!\w)',body),'standalone Latin t in German')
                require(not any(0x0600<=ord(c)<=0x06ff for c in body),'Arabic glyph present in German')
                require(r['text']['arabic'] is None and r['commentary']=={'arabic':None,'translation':None} and r['footnotes']==[],'standalone Arabic/commentary present')
                require(not r['related_versions'] and r['references']['canonical'] is None and r['references']['counterpart_verified'] is False,'canonical counterpart incorrectly enabled')
                require(r['ai_translation']=='unknown' and r['translation_provenance']['ai_translation']=='unknown' and r['translation_provenance']['origin']=='unknown','historical flags modified')
                require(r['translator']['name']=='Abū Suleyman' and r['source']['translation_reviser']=='Muḥammad S. Al-Almany','credit modified')
                require(r['source']['sha256']==H(src) and r['source']['edition_date'] is None,'source identity or date error')
                require(r['source']['url']==doc['originalGermanSourceMetadata']['download'],'PDF URL changed')
                require(r['source']['format'].startswith('Exact reviewed mobile derivative'),'print PDF claimed')
                require(r['review']['release_eligible'] is False and r['review']['certified_release_eligible'] is False and r['review']['release_status']=='private_candidate','candidate release status modified')
                require(r['rights']['status']=='not_assessed_for_publication','rights status modified')
                cita_start,cita_end=s['citation_span']
                require(cita_start==end+1 and raw[end]=='\n','citation not outside by one line break')
                require(r['references']['citation_as_printed']==raw[cita_start:cita_end],'citation not verbatim source interval')
                require(not body.endswith(r['references']['citation_as_printed']),'citation inside body')
                require(all(ref['canonical_mapping_status']=='printed_source_citation_only_no_variant_identity_approval' for ref in r['references']['items']),'canonical identity implied')
                expected={1:[('Sahih al-Bukhari','1'),('Sahih Muslim','1907')],2:[('Sahih Muslim','8')],3:[('Sahih al-Bukhari','8'),('Sahih Muslim','16')]}
                require([(x['collection'],x['number']) for x in r['references']['items']]==expected[i],'printed reference mismatch')
                # Verified source_heading strictly separate; allow PDF bidi marks around heading.
                require(r['source_headings'][0] in ''.join(ch for ch in raw[max(0,start-250):start] if ord(ch) not in (0x202a,0x202b,0x202c)),'heading not before body after comparison-only bidi unwrap')
                if i==2:require('wir verblieben eine Weile' in body and 'barfüßige, nackte und\nbedürftige' in body,'required printed wording absent')
                results['records'].append({'id':rid,'status':'PASS','source_body_span_cp_exclusive':[start,end],'source_pdf_pages':r['page']['pdf'],'source_body_sha256':H(body.encode()),'body_codepoints':len(body),'newline_count':body.count('\n'),'formfeed_count':ff,'bidi_controls':bidi,'citation_span_cp_exclusive':[cita_start,cita_end],'printed_references':expected[i],'narrator_prefix_exact':True,'headings_outside':True,'arabic_field':None,'commentary_field':None,'canonical_number':None,'counterparts_verified':False,'historical_ai_process':'unknown','release_eligible':False})
            html=supp.read('German_Nawawi_Three_Actual_Production_Reading_v003.html').decode('utf-8')
            soup=BeautifulSoup(html,'html.parser')
            fixture=json.loads(soup.select_one('#hadith-records').text)
            snapshot=json.loads(soup.select_one('#hadith-snapshot').text)
            require(len(fixture)==snapshot['record_count']==3,'supplement HTML count mismatch')
            require(snapshot['records_sha256']==H(records_bytes),'supplement not bound to raw three-record SHA')
            require(soup.title and 'PRIVATE' in soup.title.text,'HTML is not explicitly private fixture')
            require('window.__de3_private_hooks={openNarrationWorkspace,languageReadings,state,records}' in html,'reader JS production hook absent')
            meta_checks=[]
            for i,(original,p) in enumerate(zip(records,fixture)):
                require(p['id']==original['id'],'projection ID changed')
                require(p['text_translation']==original['text']['translation'],'projection body changed')
                require(p['text_arabic'] is None,'projection includes Arabic')
                require(p['translator']['name']==original['translator']['name'],'projection translator changed')
                require(p['source']['sha256']==H(src) and p['source']['original_file']=='materials/de-suleyman-mobile-7bcee562/source.pdf','source PDF file/hash binding changed')
                require(p['page']==original['page'],'PDF page range changed')
                require(p['references']==original['references'],'source citations changed in projection')
                require(p['number']==original['number'],'source numbering changed')
                require(p['translation_provenance']['origin']=='unknown' and p['translation_provenance']['ai_translation']=='unknown' and p['ai_translation']=='unknown','historic unknown process changed in projection')
                require(p['translation_provenance']['current_policy']['classification']=='human','current owner policy missing')
                require(p.get('counterpart_policy',{}).get('mode')=='disabled' and 'counterparts' not in p and 'language_versions' not in p,'counterparts enabled')
                require(p['publication']['independent_qc_asserted'] is False and p['publication']['rights_clearance_asserted'] is False,'fixture asserts final certification')
                require(p['publication']['visibility']=='public' and p['publication']['authorized'] is True,'fixture rendering authorization status changed from evidence baseline')
                require(p['review']['release_eligible'] is False,'review status reset')
                meta_checks.append({'id':p['id'],'original_unknown_flags':True,'current_owner_display_human':True,'counterpart_mode':'disabled','fixture_publication_flag_only':True})
            results['projection']={'status':'PASS','html_sha256':H(supp.read('German_Nawawi_Three_Actual_Production_Reading_v003.html')),'snapshot_raw_records_sha256':snapshot['records_sha256'],'record_count':len(fixture),'record_metadata_cases':meta_checks,'private_preview_not_live_registration':True,'fixture_public_flag_not_release_approval':True}
            results['limitations']=['Actual full Python registration/static/Markdown pipeline was executed by producer and its proof included; not independently replayed from supplement because source modules and fixture dependencies are not bundled. Pinned module source was separately inspected read-only.','Production-JS browser and actual stylesheet were independently tested in an isolated three-record fixture; no combined-corpus, mixed-code CI, real GitHub Pages or final registration.','No global auto-matching guarantees can be derived from an isolated record fixture; counterpart policy remains disabled in metadata pending exact narration and variant identity review.','Original PDF download path in private HTML targets future GitHub raw material location; live link not verified.', 'Preview projection includes simulated public/published_pending_review metadata to exercise registered renderer; original canonical records remain private, with release_eligible false.']
    return results

if __name__=='__main__':
    if len(sys.argv)!=3:
        print(__doc__); sys.exit(2)
    print(json.dumps(main(Path(sys.argv[1]),Path(sys.argv[2])),ensure_ascii=False,indent=2))
