#!/usr/bin/env python3
"""Read-only browser replay of the actual-production-style German 3-entry fixture.
Usage: python verify_browser.py MAIN_PACKET.zip SUPPLEMENT_PACKET.zip OUTPUT_DIRECTORY
Dependencies: playwright, beautifulsoup4, installed Chromium (set CHROMIUM_PATH optionally).
No web requests, GitHub writes or canonical-source modifications.
"""
import asyncio,hashlib,io,json,os,sys,zipfile
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright
H=lambda t:hashlib.sha256(t.encode('utf-8')).hexdigest()

def run(main_path,supp_path,out_dir):
    out_dir=Path(out_dir);out_dir.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(main_path) as main:
        with zipfile.ZipFile(io.BytesIO(main.read('candidate/German_Nawawi_Three_Private_Bank_Stage_v001.zip'))) as st:
            original=json.loads(st.read('materials/de-suleyman-mobile-7bcee562/records.json'))
    with zipfile.ZipFile(supp_path) as supp:
        markup=supp.read('German_Nawawi_Three_Actual_Production_Reading_v003.html').decode('utf-8')
        projected=json.loads(BeautifulSoup(markup,'html.parser').select_one('#hadith-records').text)
    assert len(projected)==len(original)==3
    return asyncio.run(browser_replay(markup,original,projected,out_dir))

async def browser_replay(markup,original,records,out_dir):
    results=[]
    executable=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium')
    async with async_playwright() as pw:
        browser=await pw.chromium.launch(headless=True,executable_path=executable,args=['--no-sandbox','--disable-dev-shm-usage'])
        version=browser.version
        for viewport,wide,tall in [('desktop',1365,900),('mobile',390,844)]:
            page=await browser.new_page(viewport={'width':wide,'height':tall},device_scale_factor=1)
            errors=[];network=[]
            page.on('pageerror',lambda e:errors.append(str(e)))
            page.on('request',lambda q:network.append(q.url))
            # No external loading is needed for the self-contained, isolated HTML.
            await page.route('http://**/*',lambda route:route.abort())
            await page.route('https://**/*',lambda route:route.abort())
            await page.set_content(markup,wait_until='domcontentloaded',timeout=25000)
            await page.wait_for_function('!!window.__de3_private_hooks',timeout=10000)
            for i,(o,p) in enumerate(zip(original,records)):
                await page.evaluate('async i=>await window.__de3_private_hooks.openNarrationWorkspace(i,null,{updateURL:false})',i)
                await page.locator('#workspace-content .language-reading[data-language="de"]').wait_for()
                await page.evaluate('document.fonts.ready')
                dom=await page.locator('#workspace-content').evaluate('''el=>({
                   readings:[...el.querySelectorAll('.language-reading')].map(s=>({
                      language:s.dataset.language,
                      text:[...s.querySelectorAll('.reading-content > .narration')].map(n=>n.textContent).join(''),
                      credit:s.querySelector('.reading-translator')?.textContent||'',
                      origin:s.querySelector('.reading-origin')?.textContent||'',
                      commentCount:s.querySelectorAll('.reading-notes').length,
                      citation:s.querySelector('.reading-citation')?.textContent||'',
                      verbatimCitations:[...s.querySelectorAll('.citation-verbatim')].map(e=>e.textContent),
                      sourceLinks:[...s.querySelectorAll('a')].map(a=>a.getAttribute('href'))
                   })),
                   originalPDFLinks:[...el.querySelectorAll('a')].filter(a=>/original PDF/i.test(a.textContent)).map(a=>a.getAttribute('href')),
                   overflow:document.documentElement.scrollWidth>innerWidth,
                   documentScrollWidth:document.documentElement.scrollWidth,
                   innerWidth:innerWidth,
                   langReadingsCount:el.querySelectorAll('.language-reading').length,
                   notesCount:el.querySelectorAll('.reading-notes').length
                })''')
                assert len(dom['readings'])==1
                rd=dom['readings'][0]
                assert rd['language']=='de' and rd['text']==o['text']['translation']==p['text_translation']
                assert rd['origin']=='Human translation' and 'Abū Suleyman' in rd['credit']
                assert not dom['overflow'] and rd['commentCount']==0 and dom['notesCount']==0
                assert o['references']['citation_as_printed'] in rd['verbatimCitations']
                assert o['references']['citation_as_printed'] not in rd['text']
                assert len(dom['originalPDFLinks'])==1 and '/materials/de-suleyman-mobile-7bcee562/source.pdf' in dom['originalPDFLinks'][0]
                assert p['counterpart_policy']['mode']=='disabled'
                assert p['text_arabic'] is None and p['ai_translation']=='unknown'
                assert p['translation_provenance']['current_policy']['classification']=='human'
                assert len(rd['verbatimCitations'])>=len(o['references']['items'])
                if i==1:
                    await page.screenshot(path=str(out_dir/f'chromium-{viewport}-entry2.png'),full_page=True,animations='disabled')
                results.append({'viewport':viewport,'width':wide,'height':tall,'record_id':o['id'],'status':'PASS','body_sha256':H(rd['text']),'body_SHA_matches_original':True,'German_only':True,'source_verbatim_citation_in_References':True,'source_citation_excluded_from_body':True,'current_policy_display':'Human translation','historical_ai_process':'unknown','translator':'Abū Suleyman','comments':0,'horizontal_overflow':False,'document_scroll_width':dom['documentScrollWidth'],'original_pdf_link_in_fixture':dom['originalPDFLinks'][0],'dom_formfeed_count':rd['text'].count('\f'),'dom_bidi_control_count':sum(ord(c) in (0x202a,0x202b,0x202c) for c in rd['text'])})
            assert not errors,f'JavaScript exceptions: {errors}'
            assert not network,f'Unexpected external requests: {network}'
            await page.close()
        await browser.close()
    report={'status':'PASS','browser':'Chromium '+version,'total_cases':len(results),'javascript_exceptions':[],'browser_network_requests':[],'checks':results,'limitations':['Three-record isolated preview only; PDF link not opened; static Python modules not rerun.','Screenshot parity to original Windows Chromium156 not asserted.']}
    (out_dir/'browser-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    return report

if __name__=='__main__':
    if len(sys.argv)!=4:
        print(__doc__);sys.exit(2)
    results=run(Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3]))
    print(json.dumps({'status':results['status'],'chromium':results['browser'],'cases':results['total_cases'],'network_requests':len(results['browser_network_requests'])},indent=2))
