# DE-NAWAWI-THREE-FINAL-ADAPTER-QC-001 — bounded final adapter review

## Decision

**PASS — private N1–N3 source-data / metadata / boundary / isolated actual-production-JS adapter checks.** No blocking defect found in those independently tested surfaces.

**HOLD — registration/release/deployment.** The independent reviewer has **not** run the complete Python production pipeline, nor full-corpus CI, final French/Hindi combined-code reconciliation, live download verification, or publisher-rights assessment. A producer's Python-pass receipt is supporting evidence, *not an independently rerun test*. This verdict does not change any original review/rights/publication flags.

Source-fidelity and German meaning reviews remained closed, as requested. No source, translation, Arabic extraction, candidate, repository, or published site was edited.

## Exact inputs

| Input | Bytes | SHA-256 | CRC/manifest |
|---|---:|---|---|
| `DE-NAWAWI-THREE-FINAL-ADAPTER-QC-001.zip` | 2,185,213 | `65488cb8d29e288a9a0a504e8ad6199d266db9c1bbc1f7d2560ff0b3337da47e` | PASS 9/9 |
| `DE-NAWAWI-THREE-ACTUAL-PRODUCTION-ASSETS-SUPPLEMENT-v003.zip` | 613,048 | `86550ad77a03ab173d4f5d7d318100fe90d4a4a9d7851b4e20314482135c6c7c` | PASS 7/7 |
| Nested private stage ZIP | 1,849,713 | `a68589ef3f3d3c9c2ac0c0d75f356461074df666e8b69df68957e77f0e1b5046` | PASS 8/8 |
| Candidate three-record `records.json` | 19,199 | `def2c3569b7b1d93e6b3fbd7f4687d2f43431f87eee3c1a6c876bd704f668732` | PASS |
| Original mobile PDF | 933,533 | `7bcee56271a39c090d2cb1311f31b2fd3b2337f8d8a2b7eca4bbaa9f87926961` | PASS / 120 pages |
| Archived `de.txt` | 141,225 | `7e08e2defed73dc1081088c2f49b26bf51f5a08b5306a37de8c75bcc92d29be5` | Exact Poppler reproduction |

Both preserved original input/reviewer ZIP archives passed CRC. Supplement v003's rendered HTML SHA-256 is `87ed2d974f18c0952262419831f5e44eb190f94a91aae057bc9af36af24d8b71` (333,659 bytes); it binds to the exact unchanged record hash above. Supplement neither introduces new raw candidate records nor changes the stage manifest.

## Exact body and boundary review

| Entry | Body source codepoint span `[start,end)` | Body SHA-256 | Physical PDF pages | Citation span `[start,end)` | Printed source references |
|---|---|---|---|---|---|
| 1 | `[7118,7815)` | `c41356ca27bbdf340958eb30f21342b80df70fc703ce6801d5df0cc9d71f0800` | 16–17 | `[7816,8215)` | Bukhari 1, Muslim 1907 |
| 2 | `[10040,12559)` | `158ee711006a56238c2c044fa5b2212282f8a7bdd813cfc5448fdeb906a0a3e8` | 18–22 | `[12560,12586)` | Muslim 8 |
| 3 | `[15839,16329)` | `724f6856c6f524362d9b1e64ddbfd49f54d19073e606b8178964311563320678` | 24–25 | `[16330,16376)` | Bukhari 8, Muslim 16 |

Every German `text.translation` equals its **contiguous source-archive `de.txt` interval codepoint for codepoint**. Each printed citation equals a distinct, immediately following source interval, separated by exactly one newline; no heading or standalone Arabic follows into the body. Narrator opening text is a prefix of that exact body (not a separate inserted quote). No content from Nawawi 4 onward or Ibn Rajab supplements appears.

Original formfeed counts are **1, 4, 1**; bidi control counts are **0, 12, 0**; no extra `t` honorific token in the selected German and no separate Arabic glyph-text. Entry 2's **“wir verblieben eine Weile”**, explanatory parentheses, punctuation, newlines and formfeeds are preserved. The unwrapped heading comparison for entry 2 strips bidi markers *only in the testing expression*; original source bytes remain unchanged. The separate Arabic extraction/font-t issue is not repaired or reopened.

## Identity, credit, and provenance

- Stable IDs: `de-suleyman-nawawi-01-7bcee562` through `03-7bcee562` (three distinct occurrences).
- `book_key=nawawi`; `number.in_book=1,2,3`; corresponding `Ḥadīth 01–03` source numbers; canonical numbers remain `null`.
- `references.canonical=null`, `references.counterpart_verified=false`, `related_versions=[]`. Reference items are **printed source citations only**, not exact narration/variant mapping approvals. The fixture's `counterpart_policy.mode=disabled`; no `language_versions`, `counterparts`, Arabic reading, or commentary reading was supplied.
- Translator: **Abū Suleyman**; reviser: **Muḥammad S. Al-Almany**. Original PDF/hash/mobile derivative status retained. Date of preface **2017-07-02** and PDF creation metadata **2020-12-08 UTC** have not been promoted to a publication/edition date; `source.edition_date=null`.
- Historical `ai_translation=unknown` and `translation_provenance.origin=unknown` are unchanged in canonical records **and** projected browser records. The separate current owner policy has `classification=human`, and the displayed reading says **Human translation**.
- The original candidate remains `private_candidate`, both `release_eligible` and `certified_release_eligible` false. Rights remain `not_assessed_for_publication`. No approval was manufactured.

## Independent rendering and code evidence

**Six of six actual HTML browser cases passed**, Chromium **144.0.7559.96**, at **1365 × 900 desktop** and **390 × 844 mobile**, using the production-style CSS/JavaScript **as shipped inside** the exact v003 HTML. Each reading has the exact source body SHA-256, one German reading only, the translator credit, owner-policy Human label, no Arabic/commentary sections, no horizontal overflow, and verbatim printed citations retained in the References panel **outside the quotation**. The DOM preserves all source formfeeds/bidi controls; **zero uncaught JavaScript exceptions, zero external HTTP requests**. New screenshots of entry 2 are included. No screenshots are represented as pixel-identical to the source Chromium 156 images.

Read-only GitHub inspection of pinned code ref `1a8c79f2609186f6f8366d7570084a92274e2108` confirms relevant implementations in `scripts/material_registry.py`, `scripts/language_display.py`, `scripts/current_provenance.py`, `scripts/build_discovery.py`, and `scripts/build_reader.py`; exact Git blob hashes and functions are in `results/pinned_code_inspection.json`. Prior producer artifacts claim static Python/Markdown 3/3, but the supplied reproduction script requires an unavailable Windows `E:/.../repo` checkout and unbundled fixture work files. Therefore those Python routes were inspected, not **independently executed**. Full final registration is still a separate gate.

## Dispositions and outstanding gates

1. **PASS** for this narrowly scoped private data/boundary/projection/isolated-browser adapter; no source changes indicated.
2. **NOT CERTIFIED** for combined-corpus counterpart suppression: the isolated three-record fixture does not test external automatic matching; the production JavaScript does not independently consult `counterpart_policy` in the fixture. Keep all counterpart links disabled until exact narration **and** variant identities are reviewed.
3. **NOT CERTIFIED** for the fixture `publication.visibility=public/authorized=true` projection as real publication authority. Those fields allow a private registered-render preview; the underlying candidate remains held. No publisher release/rights inference.
4. **NOT TESTED**: future live raw-file PDF link, full bank CI, French/Hindi software integration, live deployment, actual GitHub Pages assets, provenance licensing/rights, print-edition equivalence. Only the reviewed mobile PDF is in the archive.

This ZIP is **evidence**, not a replacement or edit of the original private candidate ZIP. Reproduction commands require the two exact original input ZIPs:

```bash
python reproduction/verify_data_adapter.py /path/to/DE-NAWAWI-THREE-FINAL-ADAPTER-QC-001.zip /path/to/DE-NAWAWI-THREE-ACTUAL-PRODUCTION-ASSETS-SUPPLEMENT-v003.zip
python reproduction/verify_browser.py /path/to/DE-NAWAWI-THREE-FINAL-ADAPTER-QC-001.zip /path/to/DE-NAWAWI-THREE-ACTUAL-PRODUCTION-ASSETS-SUPPLEMENT-v003.zip /tmp/de3-browser-results
```

See `results/issue_ledger.json` for individual PASS/limit dispositions, `results/data_adapter_results.json` for all interval and identity checks, and `results/browser_checks.json` for six independent chromium assertions.
