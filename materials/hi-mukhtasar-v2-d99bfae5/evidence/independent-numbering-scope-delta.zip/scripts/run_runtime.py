#!/usr/bin/env python3
from pathlib import Path
import sys,json,hashlib,collections,traceback,time,zipfile,os,shutil
ROOT=Path('/mnt/data/hindi2038_delta_qc_002');OUT=ROOT/'results';FIX=ROOT/'work/registered-private-fixture';CODE=Path('/mnt/data/hindi2038_qc_independent/input/actual-code');sys.path.insert(0,str(CODE/'scripts'))
from citation_search import record_citation_pairs,has_noncanonical_numbering
import material_registry,build_reader,build_discovery,hadith_search
from current_provenance import classification
H=lambda b:hashlib.sha256(b).hexdigest()
J=lambda x:json.dumps(x,ensure_ascii=False,indent=2)+'\n'
oldzip=zipfile.ZipFile('/mnt/data/HI-MSB-PART1-2038-CONTROL-ADAPTER-QC-001.zip')
result={'module_sha256':{x:H((CODE/'scripts'/x).read_bytes()) for x in ('citation_search.py','material_registry.py','build_reader.py','build_discovery.py','hadith_search.py')},'source_original_archive_hash':'5059b7623074ca7d83d6a2fda3dc26c73d188cafcb54e7f351eef1ec76305024','actual_routes':{},'errors':[],'samples':[]}
start=time.monotonic()
try:
 reg=material_registry.load_public_materials(FIX);rows=[r for g in reg['groups'] for r in g]
 original=[]
 for vol,name in enumerate(('hi-mukhtasar-v1-4785913c','hi-mukhtasar-v2-d99bfae5','hi-mukhtasar-v3-1cd9232b'),1):
  original.extend(json.loads(oldzip.read(f'registered-private-fixture/materials/{name}/records.json')))
 oldpairs=collections.Counter();newpairs=collections.Counter();issues=[];number_labels=collections.Counter();null=[];printed=[]
 for r in original:oldpairs.update(record_citation_pairs(r))
 for r in rows:
  pair=record_citation_pairs(r);newpairs.update(pair)
  label=build_reader.number_label(r)
  number_labels[label.split(' ',3)[0] if label else 'empty']+=1
  if r['number']['in_book'] is None:
   null.append(r['id']);
   if label!='Source entry '+r['provider_entry_id']: issues.append({'id':r['id'],'problem':'null label', 'label':label})
  else:
   printed.append(r['id']);
   if label!='Number in source '+str(r['number']['in_book'])+' · Source entry '+r['provider_entry_id']:issues.append({'id':r['id'],'problem':'wrong source-local number label','label':label})
  if pair:issues.append({'id':r['id'],'problem':'canonical pair present','pairs':sorted(pair)})
  if not has_noncanonical_numbering(r['number']):issues.append({'id':r['id'],'problem':'missing noncanonical flag'})
  if r['references']['canonical'] is not None or r['references']['counterpart_verified'] is not False:issues.append({'id':r['id'],'problem':'canonical/counterpart identity changed'})
 result['actual_routes']['material_registry']={'material_groups':len(reg['groups']),'projected_count':len(rows),'unique_ids':len({r['id'] for r in rows}), 'volumes':dict(collections.Counter(r['edition'] for r in rows)), 'private_audit_registered':any('private-audit' in x['path'] for x in reg['manifests']), 'translation_classification':dict(collections.Counter(classification(r) for r in rows)),'historical_ai_translation':dict(collections.Counter(str(r['translation_provenance'].get('ai_translation')) for r in rows)), 'historical_origin':dict(collections.Counter(str(r['translation_provenance'].get('origin')) for r in rows)),'counterparts_present':sum(bool(r.get('counterparts')) for r in rows),'arabic_nonempty':sum(bool(r.get('text_arabic')) for r in rows)}
 result['actual_routes']['citation_search']={'old_total_pairs':sum(oldpairs.values()),'old_distinct_pairs':len(oldpairs),'new_total_pairs':sum(newpairs.values()),'new_distinct_pairs':len(newpairs),'old_record_count_with_pair':sum(bool(record_citation_pairs(r)) for r in original),'new_record_count_with_pair':sum(bool(record_citation_pairs(r)) for r in rows),'number_label_ok_count':len(printed),'null_number_cases':null,'number_label_examples':[{'id':r['id'],'in_book':r['number']['in_book'],'number_label':build_reader.number_label(r),'pairs':sorted(':'.join(p) for p in record_citation_pairs(r))} for r in rows[:2]],'mismatches':issues}
 # Genuine verified search stream + source paths in isolated workspace.
 stream=FIX/'search/records.jsonl';stream.parent.mkdir(parents=True,exist_ok=True)
 stream.write_bytes(b''.join(json.dumps(r,ensure_ascii=False,separators=(',',':')).encode()+b'\n' for r in rows))
 catalog=FIX/'catalog/materials.json';catalog.parent.mkdir(parents=True,exist_ok=True)
 descriptor={'title':'Global Hadith Library','record_count':len(rows),'scope':'private_isolated_test','materials':reg['materials'],'by_language':{'hi':len(rows)},'search':{'records_path':'search/records.jsonl','records_sha256':H(stream.read_bytes()),'count':len(rows)},'publication':{'claim':'NOT_PUBLISHED_PROOF'}}
 catalog.write_text(J(descriptor))
 roundtrip,metadata,info=build_reader.load_records(FIX)
 result['actual_routes']['reader_load_records']={'records':len(roundtrip),'exact_equal_to_registered':rows==roundtrip,'archive_file_sha256':H(stream.read_bytes())}
 tests=[('Bukhari 1','',None,None),('Sahih al-Bukhari no. 1','',None,None),('صحيح البخاري رقم ۱','',None,None),('Bukhari 18','',None,None),('Bukhari 770','',None,None)]
 source_m='hi-mukhtasar-v1-4785913c';first=rows[0];samples=[rows[0],next(r for r in rows if r['id']=='HI-MSB-V2-P0086-N0833-HI'),next(r for r in rows if r['id']=='HI-MSB-V3-P0539-N2108-HI'),next(r for r in rows if r['number']['in_book'] is None)]
 real_search=[]
 for q,_,sr,entry in tests:
  res=hadith_search.search(FIX,q,source=sr,entry_id=entry,limit=4)
  real_search.append({'query':q,'matched':res['matched'],'shown':res['shown'],'citation_pairs':res['query_interpretation']['citation_pairs'],'result_ids':[x['id'] for x in res['results']],'cache_rebuilt':res['cache']['rebuilt'],'cache_engine':res['cache']['engine']})
 for row in samples:
  res=hadith_search.search(FIX, '',source=row['source_id'],entry_id=row['id'],limit=5)
  label=hadith_search.format_results(res)
  real_search.append({'query':'source+entry_id','source_id':row['source_id'],'entry_id':row['id'],'matched':res['matched'],'result_ids':[x['id'] for x in res['results']], 'body_exact':res['results'][0]['text_translation']==row['text_translation'] if res['results'] else False,'cli_local_number_label':'Source number: '+str(row['number']['in_book']) in label if row['number']['in_book'] is not None else ('Provider entry: '+row['id'] in label and 'Source number: ' not in label),'cache_engine':res['cache']['engine']})
 result['actual_routes']['hadith_search_real_calls']={'tests':real_search,'citation_queries_absent':all(x['matched']==0 for x in real_search[:len(tests)]),'scoped_record_id_lookup_good':all(x['matched']==1 and x['body_exact'] and x['cli_local_number_label'] for x in real_search[len(tests):])}
 # Genuine reader + static builder on isolated fixture, without modifying vendor code.
 page=ROOT/'work/numbering-scope-delta-reader.html'; md=ROOT/'work/numbering-scope-delta-reader.md'
 built=build_reader.build(FIX,page,markdown_output=md,compress=True)
 result['actual_routes']['reader_build']={'record_count':built.get('record_count'),'source_text_modified':built.get('source_text_modified'),'self_contained':built.get('self_contained'),'html_bytes':built.get('html_bytes'),'html_sha256':H(page.read_bytes()),'source_body_count':built.get('grouped_reading_count'),'markdown_pages':built.get('markdown_pages'),'markdown_files':len(list(md.rglob('*.md')))}
 static=ROOT/'work/numbering-scope-static'
 if static.exists():shutil.rmtree(static)
 built2=build_discovery.build(FIX,static)
 result['actual_routes']['static_build']={k:v for k,v in built2.items() if k in ('record_pages','shared_reader_occurrences','generated_files','static_record_pages_dom_verified','generated_bytes')}
 result['actual_routes']['static_build']['build_succeeded']=True
 result['actual_routes']['static_build']['sample_files']=[str(p.relative_to(static)) for p in list(static.rglob('*.html'))[:4]]
except Exception as exc:
 result['errors'].append({'error':str(exc),'traceback':traceback.format_exc()})
finally:
 result['duration_s']=round(time.monotonic()-start,2)
 (OUT/'REAL-PYTHON-ADAPTER-RESULTS.json').write_text(J(result))
 print('REAL-ADAPTERS',json.dumps({'registered':result['actual_routes'].get('material_registry',{}).get('projected_count'),'citation':result['actual_routes'].get('citation_search'),'real_search':result['actual_routes'].get('hadith_search_real_calls'),'reader':result['actual_routes'].get('reader_build'),'static':result['actual_routes'].get('static_build'),'errors':result['errors'],'duration_s':result['duration_s']},ensure_ascii=False)[:6000])
