import json,zipfile,hashlib,os,pathlib,collections,copy,shutil,sys
BASE=pathlib.Path('/mnt/data/hindi2038_delta_qc_002'); OUT=BASE/'results';WORK=BASE/'work'
OLD=pathlib.Path('/mnt/data/HI-MSB-PART1-2038-CONTROL-ADAPTER-QC-001.zip')
DELTA=pathlib.Path('/mnt/data/HI-MSB-PART1-2038-NUMBERING-SCOPE-DELTA-QC-002.zip')
PRIOR=pathlib.Path('/mnt/data/HI-MSB-PART1-2038-INDEPENDENT-CONTROL-ADAPTER-QC-RESULT.zip')
old=zipfile.ZipFile(OLD);delta=zipfile.ZipFile(DELTA);zman=json.loads(delta.read('MANIFEST.json'))
sha=lambda b:hashlib.sha256(b).hexdigest()
status={'task_id':'HI-MSB-PART1-2038-NUMBERING-SCOPE-DELTA-QC-002','input_outer_size':DELTA.stat().st_size,'input_sha256':sha(DELTA.read_bytes()),'input_crc':delta.testzip() is None,'manifest_items':len(zman['payloads']),'manifest_mismatches':[],'original_fixture_sha256':sha(OLD.read_bytes()),'prior_qc_sha256':sha(PRIOR.read_bytes()),'volume_checks':[],'mismatches':[]}
paths=set(delta.namelist());status['inventory_match']=paths==set([x['path'] for x in zman['payloads']]+['MANIFEST.json'])
for x in zman['payloads']:
 f=delta.read(x['path']);
 if len(f)!=x['bytes'] or sha(f)!=x['sha256']:status['manifest_mismatches'].append(x['path'])
assert status['input_crc'] and status['inventory_match'] and not status['manifest_mismatches']
assert status['input_outer_size']==1634750 and status['input_sha256']=='9d397c1ea3ec64932bb17652c19c9008d0e07a5edd20e28040bfce8d1f9f876e'
assert status['original_fixture_sha256']=='5059b7623074ca7d83d6a2fda3dc26c73d188cafcb54e7f351eef1ec76305024'
assert status['prior_qc_sha256']=='6173c719a137b70f1b172cf4f9d046defd3eaccf49097958856a2c8f63eeb63c'
# Reconstruct from original exact bytes in a NEW directory. Do not touch original/archive/prior work.
fixture=WORK/'registered-private-fixture'
if fixture.exists():shutil.rmtree(fixture)
for item in old.infolist():
 if item.is_dir() or not item.filename.startswith('registered-private-fixture/'):continue
 path=WORK/item.filename;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(old.read(item.filename))
old_file_hashes={x:sha(old.read(x)) for x in old.namelist() if x.startswith('registered-private-fixture/') and not x.endswith('/')}
for n in delta.namelist():
 if not n.startswith('registered-private-fixture/') or n.endswith('/'):continue
 path=WORK/n;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(delta.read(n))
changed_existing=[];new_file_paths=[]
for n in [x for x in delta.namelist() if x.startswith('registered-private-fixture/')]:
 if n not in old_file_hashes: new_file_paths.append(n)
 elif old_file_hashes[n]!=sha(delta.read(n)): changed_existing.append(n)
status['overlaid_existing_files']=changed_existing;status['new_audit_files']=new_file_paths
status['untouched_original_files_count']=len(old_file_hashes)-len(changed_existing)
for n,h in old_file_hashes.items():
 if n not in changed_existing and sha((WORK/n).read_bytes())!=h:status['mismatches'].append({'file':n,'problem':'unrelated originally frozen file modified'})
EXPECTED='abridgment_source_local_not_canonical'
manual=json.loads(pathlib.Path('/mnt/data/hindi-2038-closed-manual14-exclusion-guard-v001.json').read_bytes())
closed={v['textRecordId'] for v in manual['checks']};all_ids=set();all_records=[];nil=[];noncanon=[];other_diffs=[]
for vol in (1,2,3):
 vcode=['4785913c','d99bfae5','1cd9232b'][vol-1];material=f'hi-mukhtasar-v{vol}-{vcode}';p=f'registered-private-fixture/materials/{material}'
 prev=json.loads(old.read(p+'/records.json'));new=json.loads(delta.read(p+'/records.json'))
 man=json.loads(delta.read(p+'/manifest.json'));review=json.loads(delta.read(p+'/registered-scoped-review.json'));receipt=json.loads(delta.read(p+'/evidence/numbering-scope-delta-v003.json'))
 oldman=json.loads(old.read(p+'/manifest.json'))
 pairsA={r['id']:r for r in prev};pairsB={r['id']:r for r in new}
 assert len(pairsA)==len(prev) and len(pairsB)==len(new)
 assert set(pairsA)==set(pairsB)
 change_map={v['id']:v for v in receipt['changes']}
 vol_status={'volume':vol,'material':material,'records':len(new),'file_prior_sha256':sha(old.read(p+'/records.json')),'file_new_sha256':sha(delta.read(p+'/records.json')),'file_manifest_sha256':sha(delta.read(p+'/manifest.json')),'number_scope_exact':0,'unchanged_field_trees':0,'receipt_valid':0,'null_in_book':0,'receipt_top_level_records_sha256':review.get('records_sha256'),'receipt_successor_new_hash':review.get('numberingScopeSuccessor',{}).get('recordsSHA256'),'issues':[]}
 assert set(change_map)==set(pairsB)
 for id in pairsB:
  a=copy.deepcopy(pairsA[id]);b=copy.deepcopy(pairsB[id]);n=a['number'];nn=b['number'];
  if 'numbering_scope' in n:vol_status['issues'].append([id,'numbering_scope already present in prior'])
  if nn.get('numbering_scope')==EXPECTED and set(nn)==set(n)|{'numbering_scope'}:vol_status['number_scope_exact']+=1
  else:vol_status['issues'].append([id,'number field changed beyond permitted scope'])
  del b['number']['numbering_scope']
  if a==b:vol_status['unchanged_field_trees']+=1
  else:vol_status['issues'].append([id,'other fields changed'])
  c=change_map[id]
  if c['field']=='number.numbering_scope' and c['before'] is None and c['after']==EXPECTED and c['inBookUnchanged']==n['in_book'] and c['canonical'] is None and c['bodySHA256Unchanged']==sha(a['text']['translation'].encode('utf8')):
   vol_status['receipt_valid']+=1
  else:vol_status['issues'].append([id,'change evidence inconsistent'])
  if n['in_book'] is None:vol_status['null_in_book']+=1;nil.append(id)
  else:noncanon.append(id)
  all_ids.add(id);all_records.append(pairsB[id])
 assert vol_status['file_prior_sha256']==receipt['priorRecordsSHA256']==review['numberingScopeSuccessor']['priorRecordsSHA256']
 assert vol_status['file_new_sha256']==receipt['newRecordsSHA256']==review['numberingScopeSuccessor']['recordsSHA256']==man['records']['sha256']
 assert vol_status['file_manifest_sha256']==next(x['sha256'] for x in zman['payloads'] if x['path']==p+'/manifest.json')
 assert man['records']['count']==len(new) and review['record_count']==len(new)
 assert man['source']['sha256']==sha(old.read(p+'/source.pdf'))
 assert man['source']==oldman['source'] and man['counterpart_policy']==oldman['counterpart_policy'] and man['publication']==oldman['publication'] and man['adapter']==oldman['adapter']
 for sf in man.get('supporting_files',[]):
  path=sf['path'].removeprefix('materials/')
  content=(fixture/'materials'/path).read_bytes()
  if sha(content)!=sf['sha256'] or len(content)!=sf['size_bytes']:vol_status['issues'].append([sf['path'],'supporting SHA/size mismatch'])
 assert man['current_scoped_review']['sha256']==sha(delta.read(p+'/registered-scoped-review.json'))
 assert receipt['independentSuccessorDeltaQC']=='PENDING' if isinstance(receipt.get('independentSuccessorDeltaQC'),str) else True
 status['volume_checks'].append(vol_status)
 status['mismatches'].extend(vol_status['issues'])
status['all_record_count']=len(all_records);status['unique_ids']=len(all_ids);status['manual_exclusion_overlap']=sorted(closed & all_ids);status['null_source_numbers']=len(nil);status['null_case_ids']=nil;status['non_null_local_numbers']=len(noncanon)
status['all_2038_field_exact']=not status['mismatches'] and all(v['unchanged_field_trees']==v['records']==v['number_scope_exact']==v['receipt_valid'] for v in status['volume_checks'])
status['prior_QC_status_has_original_HOLD']=True
status['manual_closed_guard_sha256']=sha(pathlib.Path('/mnt/data/hindi-2038-closed-manual14-exclusion-guard-v001.json').read_bytes())
status['raw_source_digits_preserved']=status['all_2038_field_exact']
status['status']='PASS' if status['all_2038_field_exact'] and not status['manual_exclusion_overlap'] else 'HOLD'
(OUT/'DELTA-COMPARISON.json').write_text(json.dumps(status,indent=2,ensure_ascii=False)+'\n')
print('DATA-COMPARISON',status['status'], 'records',status['all_record_count'],'scope-only',sum(v['number_scope_exact'] for v in status['volume_checks']),'non-null',status['non_null_local_numbers'],'nil',status['null_source_numbers'],'manual overlap',len(status['manual_exclusion_overlap']),'mismatches',status['mismatches'][:5]); print('changed existing files',changed_existing,'new files',new_file_paths)
