from playwright.sync_api import sync_playwright
from pathlib import Path
import json,hashlib,time,traceback
ROOT=Path('/mnt/data/hindi2038_delta_qc_002');RESULT=ROOT/'results';FIX=ROOT/'work/registered-private-fixture'
HTML=(ROOT/'work/numbering-scope-delta-reader.html').read_text(encoding='utf8')
records={r['id']:r for p in (FIX/'materials').glob('*/records.json') for r in json.loads(p.read_text(encoding='utf8'))}
normal=['HI-MSB-V1-P0040-N0001-HI','HI-MSB-V1-P0065-N0018-HI','HI-MSB-V2-P0041-N0770-HI','HI-MSB-V3-P0042-N1520-HI'];null=['HI-MSB-V1-P0117-N0081-HI','HI-MSB-V2-P0086-N0833-HI','HI-MSB-V3-P0539-N2108-HI']
sha=lambda b:hashlib.sha256(b).hexdigest();out={'scope':'Selected actual Chromium browser queries and record rendering; no public site','viewport_tests':[],'lookup_tests':[],'number_search_tests':[],'screenshots':[],'page_errors':[],'exceptions':[]}
start=time.monotonic()
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']);
 for width in (1365,390,320):
  page=browser.new_page(viewport={'width':width,'height':920},device_scale_factor=1)
  page.on('pageerror',lambda err,w=width:out['page_errors'].append({'width':w,'message':str(err)}))
  page.set_content(HTML,wait_until='load',timeout=90000)
  page.locator('input[name="search-mode"][value="reference"]').check()
  options=page.locator('#source-filter option').evaluate_all('(xs)=>xs.map(x=>({value:x.value,label:x.textContent}))')
  for q in ('Bukhari 1','Sahih al-Bukhari no. 1','Bukhari 18','Bukhari 770'):
   page.locator('#query').fill(q);page.locator('#run-search').click()
   try:page.wait_for_function('() => !document.querySelector("#results .loading") && document.querySelector("#result-count").textContent.includes("matching source occurrences")',timeout=12000)
   except Exception as exc:out['exceptions'].append({'width':width,'query':q,'exception':str(exc)[:300]})
   count=page.locator('#result-count').inner_text()
   bad='Sahih al-Bukhari 1' in page.locator('#results').inner_text() or page.locator('.compact-result[data-occurrence-id="HI-MSB-V1-P0040-N0001-HI"]').count()>0
   test={'width':width,'query':q,'matched_display':count,'result_count':page.locator('.compact-result').count(),'erroneous_candidate_visible':bad,'pass':count.startswith('0 matching') and not bad}
   out['number_search_tests'].append(test)
   if width==1365 and q=='Bukhari 1':
    dest=RESULT/'browser-desktop-bukhari-1-no-false-canonical.png';page.screenshot(path=str(dest),full_page=False);out['screenshots'].append({'file':dest.name,'sha256':sha(dest.read_bytes()),'bytes':dest.stat().st_size})
  # Source scoped bare local number 1; distinguish direct local number search from source ID search.
  local=next((o for o in options if 'Volume 1' in o['label']),None)
  if local:
   page.locator('#filter-disclosure').evaluate('(e)=>e.open=true')
   page.locator('#source-filter').select_option(local['value'])
   page.locator('#query').fill('1');page.locator('#run-search').click()
   try:page.wait_for_function('() => document.querySelector("#result-count").textContent.includes("matching source occurrences")',timeout=12000)
   except Exception as exc:out['exceptions'].append({'width':width,'query':'source-filter+1','exception':str(exc)[:300]})
   out['lookup_tests'].append({'width':width,'route':'source-filter+bare-local-number','source':local,'query':'1','matched_display':page.locator('#result-count').inner_text(),'result_count':page.locator('.compact-result').count()})
   page.locator('#source-filter').select_option('')
  else:out['exceptions'].append({'width':width,'query':'select source','exception':str(options)[:600]})
  for idx,id in enumerate(normal+null):
   r=records[id];page.locator('#query').fill(id);page.locator('#query').press('Enter')
   target=page.locator(f'#workspace-content .record-card[data-occurrence-id="{id}"]')
   try:
    target.locator('p.narration[lang="hi"]').first.wait_for(state='attached',timeout=15000)
    body=target.locator('p.narration[lang="hi"]').first.text_content()
    label=target.inner_text()
    heading=page.locator('#workspace-heading').inner_text()
    is_null=r['number']['in_book'] is None
    row={'width':width,'id':id,'is_null':is_null,'body_sha256':sha(body.encode()) if body else None,'body_exact':body==r['text']['translation'],
         'number_label_visible':('Number in source '+str(r['number']['in_book'])) in label if not is_null else 'Number in source' not in label,
         'source_entry_present':id in label,'no_canonical_style_label':'Sahih al-Bukhari '+str(r['number']['in_book']) not in label and 'Sahih al-Bukhari '+str(r['number']['in_book']) not in heading if not is_null else True,
         'no_arabic_reading':target.locator('p.narration[lang="ar"]').count()==0,'no_counterpart':target.locator('details.language-reading[data-language="ar"],details.language-reading[data-language="en"]').count()==0,
         'human_display':'Human translation' in label,'horizontal_overflow':page.evaluate('document.documentElement.scrollWidth>window.innerWidth+1'),'heading':heading[:150],
         'visible':target.is_visible()}
    row['pass']=all(row[x] for x in ('body_exact','number_label_visible','source_entry_present','no_canonical_style_label','no_arabic_reading','no_counterpart','human_display','visible')) and not row['horizontal_overflow']
    out['viewport_tests'].append(row)
    if (id in ('HI-MSB-V1-P0040-N0001-HI','HI-MSB-V2-P0086-N0833-HI') and width in (1365,390,320)):
     dest=RESULT/f'browser-{width}-{id}.png';page.screenshot(path=str(dest),full_page=False);out['screenshots'].append({'file':dest.name,'sha256':sha(dest.read_bytes()),'bytes':dest.stat().st_size})
   except Exception as exc:
    out['exceptions'].append({'width':width,'id':id,'exception':str(exc)[:500]})
  page.close()
 browser.close()
out['duration_s']=round(time.monotonic()-start,2)
out['pass_browser']=len(out['viewport_tests'])==len(normal+null)*3 and all(v['pass'] for v in out['viewport_tests']) and all(v['pass'] for v in out['number_search_tests']) and not out['page_errors'] and not out['exceptions']
(RESULT/'REAL-JAVASCRIPT-CHROMIUM.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('BROWSER',json.dumps({'pass':out['pass_browser'],'views':len(out['viewport_tests']),'failed_view_cases':[x for x in out['viewport_tests'] if not x['pass']][:4],'Bukhari queries':len(out['number_search_tests']),'query errors':[x for x in out['number_search_tests'] if not x['pass']],'source scoped number':[x for x in out['lookup_tests'] if x['width']==1365], 'exceptions':out['exceptions'][:3],'page errors':out['page_errors'][:3],'screenshots':out['screenshots'],'duration':out['duration_s']},ensure_ascii=False))
