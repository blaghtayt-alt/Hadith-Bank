from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib
OUT=Path('/mnt/data/hindi2038_delta_qc_002/results');HTML=Path('/mnt/data/hindi2038_delta_qc_002/work/numbering-scope-delta-reader.html').read_text()
res=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in (1365,390):
  p=b.new_page(viewport={'width':w,'height':900});errs=[];p.on('pageerror',lambda e:errs.append(str(e)));p.set_content(HTML,wait_until='load',timeout=60000)
  p.locator('#browse-all').click()
  if w==390:p.locator('#filter-disclosure').evaluate('(e)=>e.open=true')
  options=p.locator('#source-filter option').evaluate_all('(xs)=>xs.map(x=>({value:x.value,label:x.textContent}))');option=next(x for x in options if 'Volume 1' in x['label']);p.locator('#source-filter').select_option(option['value'])
  p.wait_for_selector('.compact-result',timeout=10000)
  count=p.locator('#result-count').inner_text();first=p.locator('.compact-result').first.inner_text();allhtml=p.locator('.compact-result').first.get_attribute('data-occurrence-id')
  matches=p.locator('.compact-result[data-occurrence-id="HI-MSB-V1-P0040-N0001-HI"]').count()
  x={'width':w,'source_filter':option,'count':count,'first_occurrence_id':allhtml,'first_result_sample':first[:320],'contains_source_1_label':'Number in source 1' in first,'contains_canonical_style':'Sahih al-Bukhari 1' in first,'matching_number_1_id_visible':matches>0,'page_error':errs}
  p.locator('.compact-result').first.locator('a.open-narration').click()
  p.wait_for_selector('#workspace-content .record-card[data-occurrence-id="HI-MSB-V1-P0040-N0001-HI"]',timeout=10000)
  x['detail_number_visible']='Number in source 1' in p.locator('#workspace-content').inner_text()
  x['detail_record_id_visible']='HI-MSB-V1-P0040-N0001-HI' in p.locator('#workspace-content').inner_text()
  x['detail_still_no_canonical']='Sahih al-Bukhari 1' not in p.locator('#workspace-content').inner_text()
  res.append(x)
  if w==1365:
   file=OUT/'source-scoped-browse-volume1-first-page.png';p.screenshot(path=str(file),full_page=False)
  p.close()
 b.close()
(OUT/'SOURCE-LOCAL-BROWSE.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(res,ensure_ascii=False,indent=2)[:4000])
