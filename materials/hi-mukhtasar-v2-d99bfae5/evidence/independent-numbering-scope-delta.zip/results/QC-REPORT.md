# HI-MSB-PART1-2038-NUMBERING-SCOPE-DELTA-QC-002

## Bounded independent disposition

- **PASS — one-field numbering-scope delta, new material manifests, real Python reference index, actual reader displays, canonical-query suppression.** The previous 2,031 erroneous `bukhari:<local-number>` citations are absent from the isolated successor bytes.
- **HOLD — direct *source-scoped local numeric search* is not independently working.** In the real browser, choosing Volume 1 and searching bare `1` returns zero, even though the Volume 1 browse route lists its first occurrence and opening it visibly labels `Number in source 1`. In Python, the bare `1` is not an exact source-local lookup and the phrase `Source number 1` matches unrelated null-number source entries. An exact occurrence ID + edition filter reliably retrieves the correct record. This limitation was not introduced by the one-field delta and no general search-code rewrite is authorized.
- The HOLD applies to numeric lookup, not the fixed canonical mislabelling. **No live, public-release, full-book, or unrelated-software certification.**

## Exact inputs/integrity

| Item | Verified |
|---|---|
| Supplied successor ZIP bytes | 1,634,750 |
| Supplied successor ZIP SHA-256 | `9d397c1ea3ec64932bb17652c19c9008d0e07a5edd20e28040bfce8d1f9f876e` |
| ZIP CRC and payload digest | PASS — 15 / 15 manifest payload hashes and byte lengths; exact inventory |
| Original frozen private fixture ZIP SHA-256 | `5059b7623074ca7d83d6a2fda3dc26c73d188cafcb54e7f351eef1ec76305024` |
| Original independent QC result ZIP SHA-256 | `6173c719a137b70f1b172cf4f9d046defd3eaccf49097958856a2c8f63eeb63c` |
| Reconstruction | New isolated working directory from original ZIP; successor records/manifests/receipts overlaid only |

## Exact deltas

All **2,038 / 2,038** source records compare equal to the frozen original after removing **only** the newly added key `number.numbering_scope = abridgment_source_local_not_canonical`. Source bodies, IDs, raw/field hashes, original source digits, original `source_entry_id`, `in_book`, null `canonical`, PDF/page references, narrator/translator, language, historical unknown provenance flags, controls and holds are unchanged. All 2,038 per-record evidence receipts independently match the actual preserved Hindi body hash, original in-book values and exact permitted field path. The 14 closed manual parent IDs have zero overlap with the 2,038 records; their review is not reopened.

| Volume | Records | Successor records.json SHA-256 | Successor manifest.json SHA-256 |
|---|---:|---|---|
| 1 | 680 | `efb2b4289536fc587faef02f55289900b89a7afb4db194e685af49581ffe3275` | `960e9f6dfc1d290c389797db7ca1cd984025a159f86c9ede69734db28bd954f1` |
| 2 | 732 | `b5a9f38c73b5986269410d637f07762297ee0ffe1e324023a8c4fd5d473e73bd` | `31a94eea84c96c1efabaf80b3f028f0e93318e587e94e1d29564df390f85a711` |
| 3 | 626 | `c3ec5180ed2c317691aeb80215948da3dff6fa2f62a6a381e514a0c42107e57d` | `ec313418cc4d617e9ceecfce434ea15300746218c2942727b543380c2bfe0282` |

Three original source PDFs, three provenance files, the provenance policy, original private-audit files and all unrelated original fixture files retain their original hashes. Across the three materials, only records, manifests and scoped review receipts are replaced; three new delta evidence files are added. Historical top-level `registered-scoped-review.records_sha256` fields deliberately still refer to the prior frozen receipt, while the nested `numberingScopeSuccessor.recordsSHA256` and each new manifest bind the successor bytes. Interpret both fields with their distinct temporal scope.

## Real caller results

| Route | Recomputed result |
|---|---|
| Registered loader and schemas | PASS: 2,038 records / 3 materials; exact roundtrip of projected records |
| Python `citation_search.record_citation_pairs` on original | 2,031 canonical-style pairs across 2,031 records (2,014 unique reference values) |
| Python `citation_search.record_citation_pairs` after overlay | **ZERO** pairs across **all 2,038** records |
| Python `build_reader.number_label` | 2,031 `Number in source` labels; seven source-entry-only labels with no invented number |
| Actual Python `hadith_search.search` | Five sampled canonical Bukhari search variants returned 0; four source-ID-scoped retrievals returned the exact expected body/record |
| Full reader builder | 2,038 reading occurrences; 90 Markdown pages, no source text alteration |
| Real static builder | 2,038 HTML record pages, 2,068 generated files; 2,038 static record DOM checks |
| Chromium reader | **21 / 21** selected detailed views PASS at widths 1365 / 390 / 320; exact body, origin label, scope label, null-number handling and no horizontal overflow |
| Chromium Bukhari reference tests | **12 / 12** checks PASS (four canonical queries × three widths); zero false search results and no previous `Sahih al-Bukhari 1` label |
| Chromium edition browse | 2 / 2 PASS (1365 / 390): Volume 1 shows 680 available occurrences, exact first ID and source number on opening |
| Chromium errors | Zero JavaScript page errors |
| Counterparts and provenance | No registered Arabic/English counterparts; 2,038 `Human` display with 2,038 retained historical unknown/unknown flags |
| Private-audit registration | None |

## Exact remaining HOLD evidence

1. The correct source-local number `1` belongs to `HI-MSB-V1-P0040-N0001-HI` in the separate Volume 1 abridgment. The new Python citation index has no `bukhari:1` pair for this record, correctly preventing false canonical matching.
2. The actual Chromium **reference mode**, with Volume 1 source edition filtered, returns **0 matching source occurrences** for bare `1`. In contrast, using *Browse all* plus Volume 1 displays 680 entries, including the target as the first occurrence; opening the entry shows **Number in source 1**. The compact hit title says canonical reference is unestablished, not a source-local number; the number is visible in the opened reading.
3. The actual Python search with `source=hi-mukhtasar-v1-4785913c` and `query='1'` matches the entire 680-occurrence volume (not an exact local-number match); `query='Source number 1'` matches **two null-number cases**, not the intended number-1 record. Exact `entry_id=HI-MSB-V1-P0040-N0001-HI` plus `source` matches the correct record.
4. Thus **canonical-index correction is fully verified; exact source-number lookup is not**. Fixing exact scoped numeric search requires an independently authorized, source-aware search feature or index; no such code change was performed here.

## Evidence and limits

`DELTA-COMPARISON.json` contains the complete exact-change control summary; `REAL-PYTHON-ADAPTER-RESULTS.json` includes real loader/index/search/static build outcomes; `REAL-JAVASCRIPT-CHROMIUM.json` logs selected browser IDs and rendered assertions; `SOURCE-LOCAL-BROWSE.json` and `SOURCE-LOCAL-NUMERIC-LOOKUP-HOLD.json` preserve the distinct discovery routes; screenshots show actual Chromium renders.

The original 2,038 source/control and 617 census findings remain prior closed PASS; this successor does not reperform them. The closed manual16 decisions and separate Hindi notes repair002/French003 owners remain outside scope. No source-research, transcription, translation edit, repository write, public publication or new worker. The current `(OCR wasn’t clear)` editorial warning was not added to these unaffected records. All test-only modifications were confined to a new isolated fixture and external test scripts; no application source code was modified.
