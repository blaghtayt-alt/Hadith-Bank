#!/usr/bin/env python3
from pathlib import Path
import sys,hashlib,json,copy,collections,shutil,os,traceback,time
IN=Path('/mnt/data/hindi2038_qc_independent/input');CODE=IN/'actual-code';DATA=IN/'registered-private-fixture'
WORK=Path('/mnt/data/hindi2038_qc_independent/work/actual-caller-fixture');R=Path('/mnt/data/hindi2038_qc_independent/results')
sys.path.insert(0,str(CODE/'scripts'))
import material_registry,build_reader,build_discovery,build_book_catalog,hadith_search
from current_provenance import classification

def sha(b):return hashlib.sha256(b).hexdigest()
def write_json(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
start=time.monotonic();result={'actual_module_paths':{x:sys.modules[x].__file__ for x in ('material_registry','build_reader','build_discovery','hadith_search')},'data_root':str(DATA),'script_errors':[]}
try:
 registry=material_registry.load_public_materials(DATA)
 records=[r for g in registry['groups'] for r in g]
 result['real_loader']={'groups':len(registry['groups']),'records':len(records),'by_volume':dict(collections.Counter(x['source_id'] for x in records)),'current_classification':dict(collections.Counter(classification(x) for x in records)),'historical_AI_flag':dict(collections.Counter(str(x['translation_provenance'].get('ai_translation')) for x in records)), 'historical_origin':dict(collections.Counter(x['translation_provenance'].get('origin') for x in records)),'distinct_ids':len(set(r['id'] for r in records)),'material_descriptors':len(registry['materials']),'authorized_file_paths':sorted(registry['authorized_files']),'private_audit_as_registered': any('private-audit' in m['path'] for m in registry['manifests']), 'counterpart_modes': dict(collections.Counter((r.get('counterpart_policy') or {}).get('mode') for r in records)),'source_languages': dict(collections.Counter(r['language'] for r in records)),'publication_status':dict(collections.Counter(r['publication']['status'] for r in records)),'public_claim_independent_qc':dict(collections.Counter(str(r['publication']['independent_qc_asserted']) for r in records)),'all_doc_original_file_sources': sorted({r['source']['original_file'] for r in records}),'all_archive_sources_authorized': set(x['source']['original_file'] for x in records)<=set(registry['authorized_files']),'private_audit_path_in_canonical_projections':sum('private-audit/' in json.dumps(x,ensure_ascii=False) for x in records)}
 print('Real loader', result['real_loader'],flush=True)
 # Build self-contained isolated fixture; never change source/provided controls.
 for kind in ('materials','catalog'):
  src=DATA/kind;dest=WORK/kind;dest.mkdir(parents=True,exist_ok=True)
  for f in src.rglob('*'):
   if f.is_file():
    target=dest/f.relative_to(src);target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():os.link(f,target)
 # Deliberately do not copy private-audit: genuine loader must not need it.
 outstream=WORK/'search/records.jsonl';outstream.parent.mkdir(parents=True,exist_ok=True)
 with outstream.open('wb') as stream:
  for r in records:stream.write(json.dumps(r,ensure_ascii=False,separators=(',',':')).encode()+b'\n')
 catalog={'title':'PRIVATE Hindi 2038 adapter control proof (not a publication)','record_count':len(records),'scope':'offline_private_adapter_qc','materials':registry['materials'],'by_language':{'hi':len(records)},'search':{'records_path':'search/records.jsonl','records_sha256':sha(outstream.read_bytes()),'count':len(records)},'publication':{'claim':'NOT_PUBLISHED_PROOF'}}
 write_json(WORK/'catalog/materials.json',catalog)
 roundtrip,catalog2,info=build_reader.load_records(WORK)
 result['actual_reader_load_records']={'records':len(roundtrip),'records_shipped_hash':catalog['search']['records_sha256'],'catalog_count':catalog2['search']['count'],'exact_roundtrip':roundtrip==records}
 print('Real reader input loaded', len(roundtrip),flush=True)
 # Render self-contained genuine full reader, after source group metadata and UI asset calculations.
 page=WORK/'private-2038-reader.html'
 markdown=WORK/'private-2038-reader.md'
 res=build_reader.build(WORK,page,markdown_output=markdown,compress=True)
 result['actual_reader_build']=res
 result['actual_reader_build']['reader_html_sha256']=sha(page.read_bytes())
 result['actual_reader_build']['markdown_file_count']=len(list(markdown.rglob('*.md')))
 result['actual_reader_build']['markdown_manifest_sha256']=sha(''.join(sorted(str(f.relative_to(markdown))+':'+sha(f.read_bytes())+'\n' for f in markdown.rglob('*') if f.is_file())).encode())
 print('Real reader built', {k:v for k,v in res.items() if k in ('html_bytes','grouped_reading_count','embedded_encoding','source_text_modified','self_contained','discovery_statistics')},flush=True)
 # Static pages / site build with original frozen executable code.
 static=WORK/'static-2038-proof'
 if static.exists():shutil.rmtree(static)
 res2=build_discovery.build(WORK,static)
 result['actual_static_build']=res2
 print('Real static built', {k:v for k,v in res2.items() if k in ('record_pages','shared_reader_occurrences','generated_files','static_record_pages_dom_verified','generated_bytes')},flush=True)
 # Check genuine Markdown and selected rendered pages contain exact source body (normalization allowed HTML escapes/spacing only).
 chosen=['HI-MSB-V1-P0040-N0001-HI','HI-MSB-V1-P0117-N0081-HI','HI-MSB-V1-P0247-N0257-HI','HI-MSB-V2-P0041-N0770-HI','HI-MSB-V2-P0086-N0833-HI','HI-MSB-V2-P0086-N0834-HI','HI-MSB-V2-P0154-N0933-HI','HI-MSB-V3-P0042-N1520-HI','HI-MSB-V3-P0539-N2108-HI','HI-MSB-V3-P0578-N2159-HI','HI-MSB-V3-P0107-N1600-HI','HI-MSB-V3-P0600-N2190-HI']
 chosen=[x for x in chosen if x in {r['id'] for r in records}]
 from html.parser import HTMLParser
 from build_discovery import record_path
 sample=[]
 for id in chosen:
  r=next(r for r in records if r['id']==id)
  pg=static/record_path(r)
  raw=pg.read_text(encoding='utf8') if pg.is_file() else None
  # Do not expect exact body contiguous in HTML; static may break into tags.
  sample.append({'id':id,'body_sha256':sha(r['text_translation'].encode()),'present_in_markdown_source_lines':all(line in '\n'.join(f.read_text(encoding='utf8') for f in markdown.rglob('*.md')) for line in r['text_translation'].splitlines() if len(line)>10),'static_path':str(pg.relative_to(static)),'static_exists':bool(raw),'static_html_sha256':sha(raw.encode()) if raw else None,'html_page_contaminates_arabic':('lang="ar"' in raw) if raw else None,'current_origin_label':classification(r),'number_in_book':r['number']['in_book'],'counterpart_mode':r.get('counterpart_policy',{}).get('mode')})
 result['real_samples']=sample
 print('Samples static/markdown',len(sample),flush=True)
except Exception as exc:
 result['script_errors'].append({'error':repr(exc),'traceback':traceback.format_exc()});print('ERROR',repr(exc),traceback.format_exc(),flush=True)
finally:
 result['elapsed_seconds']=round(time.monotonic()-start,2)
 write_json(R/'adapter-real-caller-results.json',result)
 print('elapsed',result['elapsed_seconds'],flush=True)
