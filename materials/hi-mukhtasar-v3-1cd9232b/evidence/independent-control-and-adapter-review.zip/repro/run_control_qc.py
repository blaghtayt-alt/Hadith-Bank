#!/usr/bin/env python3
"""Independent read-only application/control QC for submitted Hindi 2,038 packet."""
from pathlib import Path
import json, hashlib, re, collections, sys, zipfile, io, time
try: import fitz
except ImportError: fitz=None
D=Path('/mnt/data/hindi2038_qc_independent/input'); O=Path('/mnt/data/hindi2038_qc_independent/results')
Issues=[]; sections={}
def j(p):return json.loads((D/p).read_text(encoding='utf-8'))
def jl(p):return [json.loads(s) for s in (D/p).read_text(encoding='utf-8').splitlines() if s.strip()]
def sh(b):return hashlib.sha256(b).hexdigest()
def th(s):return sh(s.encode('utf8'))
def problem(category,why,record=None,detail=None,level='HOLD'):
 x={'control':category,'severity':level,'mismatch':why}
 if record is not None:x['record_id']=record
 if detail is not None:x['evidence']=detail
 Issues.append(x)
V={1:'hi-mukhtasar-v1-4785913c',2:'hi-mukhtasar-v2-d99bfae5',3:'hi-mukhtasar-v3-1cd9232b'}
allnew=[];allold=[];books={};frozen={};newbyid={};oldbyid={};supp={r['id']:r for r in j('controls/separate-number-only-supplement/records-7.json')}
maprows=j('registered-private-fixture/private-audit/exact-source-binding-map-2038.json')
mapbyid={r['id']:r for r in maprows}
q10base='controls/QC10/'
qcname=['reviewed_main_texts.jsonl','reviewed_source_units.jsonl','reviewed_commentary_fragments.jsonl','reviewed_commentary_occurrences.jsonl','reviewed_annotation_anchors.jsonl','reviewed_related_observations.jsonl','reviewed_frontmatter_pages.jsonl','reviewed_backmatter_pages.jsonl','supplemental_source_units.jsonl']
qc={name:jl(q10base+name) for name in qcname}
main=qc['reviewed_main_texts.jsonl']
raw_lines=(D/(q10base+'reviewed_main_texts.jsonl')).read_bytes().splitlines()
allhi=[(i,r) for i,r in enumerate(main,1) if r.get('language')=='hi']
held=j('controls/original-2031-selection/preserved-record-holds.json')
B03=j('controls/B03-v2/HI_QC12_IR3_B03_v2_RELEASE_EXCLUSIONS.json')
census=jl('controls/QC12/final_census/UNRESOLVED_SOURCE_GLYPH_WITH_NEW_CASES.jsonl');census_by={r['census_id']:r for r in census}
join=j('controls/current-binding-join-617.json'); joinby={r['census_id']:r for r in join}
patch=jl('controls/QC12/corrections/CUMULATIVE_QC11_QC12_FIELD_PATCHES.jsonl')
selector=jl('controls/original-2031-selection/unchanged-hindi-main-source-candidates.jsonl')
recon=j('controls/separate-number-only-supplement/scope-reconciliation-8.json')
selected_ids=set();errors0=len(Issues)
for vol,key in V.items():
 rpath=f'registered-private-fixture/materials/{key}/records.json';fpath=f'original-frozen-2031-records/{key}/records.json'
 rows=j(rpath);old=j(fpath);manifest=j(f'registered-private-fixture/materials/{key}/manifest.json');prov=j(f'registered-private-fixture/materials/{key}/provenance.json')
 pdfp=D/f'registered-private-fixture/materials/{key}/source.pdf'
 pages=fitz.open(str(pdfp)).page_count if fitz else None
 books[vol]={'id':key,'registered_count':len(rows),'original_count':len(old),'supplement_count':len(rows)-len(old),'pdf_pages':pages,'pdf_sha256':sh(pdfp.read_bytes()),'pdf_bytes':pdfp.stat().st_size,'manifest_sha256':sh((D/f'registered-private-fixture/materials/{key}/manifest.json').read_bytes())}
 if pages not in [None,{1:638,2:643,3:640}[vol]]:problem('pdf_pagecount','unexpected PDF page count',key,pages)
 if manifest['records']['count']!=len(rows) or manifest['records']['sha256']!=sh((D/rpath).read_bytes()):problem('material_hash','bad record manifest count/hash',key)
 if manifest['source']['sha256']!=books[vol]['pdf_sha256']:problem('material_hash','bad PDF manifest hash',key)
 if manifest.get('language')!='hi' or manifest.get('book')!='bukhari' or manifest.get('adapter')!='records-v1':problem('material_manifest','invalid identity',key)
 if manifest.get('publication',{}).get('certified_release_eligible') is not False:problem('publication','manifest implies certified release',key)
 if manifest.get('counterpart_policy',{}).get('mode')!='disabled':problem('counterpart','counterpart opt-out not enabled',key)
 if manifest.get('source',{}).get('work_kind')!='Zubaydiabridgment, notfullSahihBukhariCorpus':problem('source work_kind','not abridged metadata',key,manifest['source']['work_kind'])
 allnew+=rows;allold+=old
 for r in rows:
  if r['id'] in newbyid:problem('duplicate_id','duplicate registered record',r['id'])
  newbyid[r['id']]=r
 for r in old:
  if r['id'] in oldbyid:problem('duplicate_frozen','duplicate old record',r['id'])
  oldbyid[r['id']]=r
 bad= len([r for r in rows if r.get('source',{}).get('sha256')!=books[vol]['pdf_sha256']])
 if bad:problem('record_pdf','wrong pdf sha',key,bad)
print('loaded',len(allnew),len(allold),len(allhi),'PDFs',books, flush=True)
if len(allnew)!=2038 or [books[v]['registered_count'] for v in V]!=[680,732,626]:problem('counts','candidate count/splits differ',detail=books)
if len(allold)!=2031 or len(supp)!=7:problem('counts','original 2031 or supplement7 differs',detail=[len(allold),len(supp)])
if set(newbyid)!=set(oldbyid)|set(supp):problem('membership','candidate membership mismatch',detail={'only_new':sorted(set(newbyid)-set(oldbyid)-set(supp))[:30],'missing_old':sorted(set(oldbyid)-set(newbyid))[:30],'missing_supp':sorted(set(supp)-set(newbyid))[:30]})
changed=[]
for id,r in newbyid.items():
 if id in oldbyid and r!=oldbyid[id]:changed.append(id)
 if id in supp and r!=supp[id]:changed.append(id)
if changed:problem('frozen_equality','material records differ from frozen/supplement canonical records',detail=changed[:60])
if len(maprows)!=len(newbyid) or len(mapbyid)!=len(maprows) or set(mapbyid)!=set(newbyid):problem('binding_map','binding map membership mismatches',detail={'n_map':len(maprows),'unique':len(mapbyid)})
if len(allhi)!=2230:problem('source_hindi_count','current QC10 Hindi main count differs',detail=len(allhi))
source_by_id={r['text_record_id']:(i,r) for i,r in allhi}
if len(source_by_id)!=len(allhi):problem('source_hindi_count','duplicate Hindi text record IDs')
if set(source_by_id)!=set(newbyid)|{h+'-HI' for h in held}:problem('selection_partition','source Hindi count is not new pool union preserved holds',detail={'source_not_accounted':sorted(set(source_by_id)-set(newbyid)-{h+'-HI' for h in held})[:50],'missing_from_source':sorted((set(newbyid)|{h+'-HI' for h in held})-set(source_by_id))[:50]})
if len(held)!=199 or len(set(held)-{s['source']['source_parent_record_id'] for s in supp.values()})!=192:problem('preserved_holds','hold numbers differ',detail=[len(held),len(set(held)-{s['source']['source_parent_record_id'] for s in supp.values()})])
if set(newbyid)&({k+'-HI' for k in held}) != set(supp):problem('preserved_holds','unexpected excluded record joined as candidate',detail=sorted(set(newbyid)&({k+'-HI' for k in held})-set(supp)))
# Verify entire record identities, line hash, exact source bodies, source PDF and page bindings.
for id,r in newbyid.items():
 src=r.get('source',{}); par=src.get('source_parent_record_id');e=r.get('extraction',{});n=e.get('source_line_1based');m=mapbyid.get(id)
 if not isinstance(n,int) or n<1 or n>len(main):problem('row_index','source line invalid',id,n);continue
 origin=main[n-1]
 line_hash=sh(raw_lines[n-1]);actual_body=origin.get('reviewed_draft');body=r.get('text',{}).get('translation')
 expected_attrs={'id':id,'parent':par,'volume':src.get('volume'),'sourceLine':n,'sourceLineSHA256':line_hash,'bodySHA256':th(body) if isinstance(body,str) else None,'numberOnlySupplement':id in supp,'printedPagesOmitted':True}
 if m!=expected_attrs:problem('binding_map','binding descriptor differs',id,{'expected':expected_attrs,'actual':m})
 if origin.get('text_record_id')!=id or origin.get('record_id')!=par or origin.get('volume_number')!=src.get('volume') or origin.get('language')!='hi' or origin.get('role')!='source_printed_hindi_translation':problem('row_identity','source QC10 row identity differs',id,{'line':n,'id':origin.get('text_record_id'),'volume':origin.get('volume_number')})
 if e.get('source_raw_line_sha256')!=line_hash or e.get('source_table_sha256')!='e31163f9f43edd2b24e77b555e79fe3236e2c6ed53e42be15f1366f1075d996f':problem('raw_line_sha','bad source line/table hash',id,n)
 if body!=actual_body or th(body)!=origin.get('reviewed_draft_sha256_utf8'):problem('body','source Hindi body differs',id,{'line':n,'expected':origin.get('reviewed_draft_sha256_utf8'),'actual':th(body) if isinstance(body,str) else None})
 if r.get('language')!='hi' or r.get('record_type')!='hadith_occurrence' or r.get('book_key')!='bukhari' or r.get('edition')!='hindi-mukhtasar-v'+str(src.get('volume'))+'-'+V[src.get('volume')].split('-')[-1]:problem('identity','incorrect language/book/record_type/edition',id)
 if r.get('text',{}).get('arabic') is not None or r.get('commentary')!={'arabic':None,'translation':None} or r.get('footnotes') or r.get('references',{}).get('items') or r.get('related_versions'):problem('component_separation','Arabic/commentary/footnote/counterpart contamination',id)
 if r.get('references',{}).get('counterpart_verified') is not False or r.get('number',{}).get('canonical') is not None:problem('counterpart','canonical/counterpart flag not empty',id)
 if r.get('review',{}).get('release_eligible') or r.get('review',{}).get('certified_release_eligible') or r.get('review',{}).get('issues'):problem('review_status','certified released or issues attached',id)
 if r.get('page',{}).get('printed')!=[] or r.get('page',{}).get('pdf')!=origin.get('compared_pdf_pages'):problem('pdf_page','printed page retained or page comparison differs',id,{'field':r.get('page'),'compared':origin.get('compared_pdf_pages')})
 vol=src.get('volume'); pages=books.get(vol,{}).get('pdf_pages')
 if pages is not None and any(not isinstance(p,int) or p<1 or p>pages for p in r.get('page',{}).get('pdf',[])):problem('pdf_page','physical page out of range',id,r.get('page'))
 if src.get('sha256')!=books[vol]['pdf_sha256']:problem('pdf_sha','PDF binding hash differs',id)
 if r.get('ai_translation')!='unknown' or r.get('translation_provenance',{}).get('origin')!='unknown' or r.get('translation_provenance',{}).get('ai_translation')!='unknown':problem('provenance','historical unknown origin/AI process overwritten',id)
 if r.get('translator',{}).get('name')!=r.get('translation_provenance',{}).get('translator',{}).get('name'):problem('translator','source translator fields mismatch',id)
 if r.get('number',{}).get('source_entry_id')!=id:problem('number','source_entry_id not occurrence identifier',id)
 if isinstance(body,str) and ('⟦U' in body or '⟦' in body or 'OCR wasn' in body or 'OCR wasnt' in body):problem('body_uncertainty','unexpected source marker/OCR warning in unchanged Hindi body',id)
 if any('show_in_html_hadith'==k and v is False for k,v in r.items()):problem('explicit_hold','explicit hold exported',id)
# Check 2031 selector/source control rows without relying on producer receipts.
selby={x['text_record_id']:x for x in selector}
if set(selby)!=set(oldbyid) or len(selector)!=2031:problem('original_selection','original selection inventory mismatch',detail={'selected':len(selector),'unique':len(selby),'absent':len(set(oldbyid)-set(selby))})
for id,s in selby.items():
 n=s.get('source_line_1based')
 if not isinstance(n,int) or n<1 or n>len(main):problem('selector_line','bad selector line',id);continue
 q=main[n-1]
 if s.get('source_file')!='reviewed_main_texts.jsonl' or s.get('raw_line_sha256')!=sh(raw_lines[n-1]) or s.get('body_exact')!=q['reviewed_draft'] or s.get('body_sha256')!=th(q['reviewed_draft']) or s.get('text_record_id')!=q['text_record_id'] or s.get('parent_record_id')!=q['record_id'] or s.get('pdf_pages')!=q['compared_pdf_pages']:problem('selector','frozen 2031 selection disagrees with current source',id)
# Closed manual projection guard reuses previous reviewed-text-projections file, no new semantic review.
guardpath=Path('/mnt/data/hindi-2038-closed-manual14-exclusion-guard-v001.json');guard=json.loads(guardpath.read_text())
manual_zip=Path('/mnt/data/HI-MSB-MANUAL16-APPLICATION-QC-001.zip')
with zipfile.ZipFile(manual_zip) as outer,zipfile.ZipFile(io.BytesIO(outer.read('exact-private-application.zip'))) as inner:
  closedbytes=inner.read('reviewed-text-projections-14.json');closed=json.loads(closedbytes)
  closed_sha=sh(closedbytes)
if closed_sha!=guard['closedManualProjectionFileSHA256']:problem('closed_manual_guard','closed reference file hash mismatches',detail=[closed_sha,guard['closedManualProjectionFileSHA256']])
closedids={x['textRecordId'] for x in guard['checks']}
if len(closedids)!=14 or any(x['presentIn2038'] is not False for x in guard['checks']):problem('closed_manual_guard','unexpected guard IDs')
if closedids & set(newbyid):problem('closed_manual_guard','closed manual texts leaked into 2038',detail=list(closedids&set(newbyid)))
if any((r['parentRecordId']+'-HI')!=r['textRecordId'] or r['parentRecordId'] not in held for r in guard['checks']):problem('closed_manual_guard','manual parents not in preserved holds')
# Actual manually reviewed projection object shape checked in later targeted section.
sections['source_body']={'total_current_main_rows':len(main),'total_hindi_main_rows':len(allhi),'registered':len(newbyid),'original_frozen':len(oldbyid),'additional_7':len(supp),'preserved_held_199':len(held),'held_after_7_192':len(held)-len(supp),'split':{V[v]:books[v] for v in V},'mismatches':len(Issues)-errors0,'closed_manual_reference_sha':closed_sha,'closed_manual_guard_overlap':len(closedids&set(newbyid)),'closed_projection_shape':('list' if isinstance(closed,list) else 'dict')}
print('source/body checks',sections['source_body']['mismatches'], 'new issues',len(Issues), 'closed shape',type(closed),flush=True)
# write intermediate; below appended
# Source exclusion, 617-census and nine-table binding proof.
errors0=len(Issues)
whole={x['record_id'] for x in B03['whole_hadith_record_exclusions']}
pg={id for p in B03['conservative_page_export_guards'] for id in p['existing_hadith_record_ids_guarded']}
if len(whole)!=29 or len(pg)!=49 or whole & pg:problem('B03_count','B03 whole and page guards count/overlap',detail=[len(whole),len(pg),sorted(whole&pg)])
if not whole<=set(held) or not pg<=set(held):problem('B03_holds','B03 whole/page exclusions not in archived holds',detail=sorted((whole|pg)-set(held)))
if {r.get('source',{}).get('source_parent_record_id') for r in allnew}&(whole|pg):problem('B03_holds','B03 held parent leaked into candidate')
# Check source selectors of every B03 whole-hadith and conservative page guard; uses actual immutable QC10 files.
b03_sel_checked=0; b03_bad=[];b03_sel_missing=0
for obj in B03['whole_hadith_record_exclusions']+B03['conservative_page_export_guards']:
 sel=obj.get('known_exact_source_record_and_attached_component_selectors',[]) if 'record_id' in obj else obj.get('exact_main_record_selectors',[])
 for s in sel:
  n=s.get('source_line_1based');file=s.get('source_file');expected=s.get('identity',{})
  if file not in qc or not isinstance(n,int) or n<1 or n>len(qc[file]):b03_bad.append({'object':obj.get('record_id') or obj.get('guard_id'),'selector':s,'error':'missing file/line'});continue
  row=qc[file][n-1]
  mismatched={k:[v,row.get(k)] for k,v in expected.items() if k in row and v!=row.get(k)}
  if mismatched:b03_bad.append({'object':obj.get('record_id') or obj.get('guard_id'),'file':file,'line':n,'mismatch':mismatched})
  if s.get('frozen_QC10_file_sha256')!=sh((D/(q10base+file)).read_bytes()):b03_bad.append({'object':obj.get('record_id') or obj.get('guard_id'),'file':file,'line':n,'error':'bad table hash'})
  b03_sel_checked+=1
if b03_bad:problem('B03_selectors','B03 frozen source selectors contain mismatches',detail=b03_bad[:20])
if len(join)!=617 or len(census)!=617 or set(joinby)!=set(census_by):problem('census_join','join census mismatch',detail={'join':len(join),'census':len(census)})
def ptr(x,path):
 if path in ('','/') or path is None:return x
 if not isinstance(path,str) or not path.startswith('/'):raise KeyError(path)
 for raw in path.split('/')[1:]:
  k=raw.replace('~1','/').replace('~0','~')
  x=x[int(k)] if isinstance(x,list) else x[k]
 return x
wrong_join=[];wrong_source=[];bad_hash=[];bad_identity=[];mismatched_parents=[]
bound_n=0;actual_hindi_parents=set();no_bind=[];binding_field_hash_checked=0;binding_parent_rows=set();hindi_binding_ids=set()
for jr in join:
 cid=jr['census_id'];case=census_by.get(cid)
 if not case:continue
 for k1,k2 in [('volume','volume'),('remainingTypes','remaining_uncertainty_types'),('outcome','outcome_normalized')]:
  if jr.get(k1)!=case.get(k2):wrong_join.append([cid,k1,jr.get(k1),case.get(k2)])
 if jr.get('originalRefs')!=case.get('original_authoritative_ref'):wrong_join.append([cid,'originalRefs'])
 if jr.get('actualPages')!=case.get('actual_reviewed_source_pages') and not set(jr.get('actualPages',[]))<=set(case.get('actual_reviewed_source_pages',[])+case.get('actual_target_pages_from_explicit_rebinding',[])):wrong_join.append([cid,'actualPages'])
 if jr.get('category')=='NO_BINDINGS':
  if jr.get('bindings'):wrong_join.append([cid,'unexpected nonempty bindings']);
  no_bind.append(cid)
 for b in jr.get('bindings',[]):
  bound_n+=1
  sourceptr=b.get('source');desc=b.get('binding',{});file=desc.get('reviewed_file');n=desc.get('line_1based')
  try:
   original=ptr(case,sourceptr)
   if original!=desc:wrong_join.append([cid,'source component binding differs',sourceptr])
  except Exception as e:wrong_join.append([cid,'source pointer invalid',sourceptr,str(e)])
  if file not in qc or not isinstance(n,int) or n<1 or n>len(qc[file]):wrong_source.append([cid,file,n,'missing file/line']);continue
  row=qc[file][n-1];ident=b.get('rowIdentity',{})
  for key,val in ident.items():
   if key in row and row[key]!=val:bad_identity.append([cid,file,n,key,val,row[key]])
  p=desc.get('json_pointer_within_line')
  try: value=ptr(row,p)
  except Exception as e:wrong_source.append([cid,file,n,'bad field pointer',p,str(e)]);continue
  checksum=desc.get('current_text_sha256_utf8')
  if checksum is not None:
   binding_field_hash_checked+=1
   if isinstance(value,str) and th(value)!=checksum:bad_hash.append([cid,file,n,p,checksum,th(value)])
   elif not isinstance(value,str):bad_hash.append([cid,file,n,p,'field is not str',type(value).__name__])
  if desc.get('language')=='hi' and file=='reviewed_main_texts.jsonl' and row.get('language')=='hi':
   binding_parent_rows.add(row.get('record_id'))
  if jr.get('category')=='HAS_HINDI_MAIN_BINDING' and file=='reviewed_main_texts.jsonl' and row.get('language')=='hi':
   actual_hindi_parents.add(row.get('record_id'));hindi_binding_ids.add(cid)
 # The category is about any original field link to the Hindi matn, not just a pointer to /reviewed_draft
 if jr.get('category')=='HAS_HINDI_MAIN_BINDING':
  if not jr.get('HindiParents'):mismatched_parents.append([cid,'no HindiParents'])
  for p in jr.get('HindiParents',[]):
   if p+'-HI' not in source_by_id:mismatched_parents.append([cid,'Hindi parent absent from current source',p])
   elif p not in held and p+'-HI' not in supp:mismatched_parents.append([cid,'Hindi-bound issue unexpectedly in candidate',p])
 elif jr.get('HindiParents'):mismatched_parents.append([cid,'unexpected HindiParents',jr.get('HindiParents')])
if wrong_join:problem('617_join','join metadata differs from original 617 rows',detail=wrong_join[:30])
if wrong_source:problem('617_binding_pointer','source/field pointer invalid',detail=wrong_source[:30])
if bad_identity:problem('617_identity','binding identity mismatches actual current QC10 table',detail=bad_identity[:30])
if bad_hash:problem('617_hash','binding field SHA-256 mismatch against actual current table',detail=bad_hash[:30])
if mismatched_parents:problem('617_parent','Hindi parent eligibility/mapping issue',detail=mismatched_parents[:30])
if len(no_bind)!=40:problem('617_unbound','expected 40 genuinely unbound',detail=len(no_bind))
# Review-only patches are never silently re-applied to the 2038 frozen source bodies.
status=collections.Counter(p.get('application_status') for p in patch)
if len(patch)!=141 or status!={'review_only_not_applied':141}:problem('patch','patch counts or statuses differ',detail=dict(status))
for p in patch:
 file=p.get('target_file');n=p.get('line_1based');before=p.get('before');after=p.get('after')
 if file not in qc or not isinstance(n,int) or not (1<=n<=len(qc[file])):problem('patch','patch points outside preserved QC10',detail={'file':file,'line':n});continue
 try: curr=ptr(qc[file][n-1],p.get('json_pointer_within_line'))
 except Exception as e:problem('patch','patch pointer missing',detail={'file':file,'line':n,'pointer':p.get('json_pointer_within_line'),'error':str(e)});continue
 # Exact hash snapshots have separate encoding, many Q12 patches review-only on original QC10; do not autoapply.
 if curr==after and curr!=before:problem('patch','patch after state already present in current source (potential double application)',detail={'file':file,'line':n,'pointer':p.get('json_pointer_within_line'),'change_ids':p.get('change_ids')})
sections['control_exclusions']={'b03_whole_record_holds':len(whole),'b03_conservative_page_records':len(pg),'B03_selectors_checked':b03_sel_checked,'B03_selector_mismatches':len(b03_bad),'held_after_7':192,'census_entries':len(census),'census_join_entries':len(join),'join_category_counts':dict(collections.Counter(x['category'] for x in join)),'binding_refs_tested':bound_n,'binding_field_sha256_checked':binding_field_hash_checked,'binding_pointer_mismatches':len(wrong_source),'binding_field_hash_mismatches':len(bad_hash),'binding_row_identity_mismatches':len(bad_identity),'census_join_metadata_mismatches':len(wrong_join),'census_eligibility_mismatches':len(mismatched_parents),'unbound_cases':len(no_bind),'hindi_parent_ids_bound':len(binding_parent_rows),'review_only_patches':len(patch),'patch_statuses':dict(status),'mismatches':len(Issues)-errors0}
print('binding/control',sections['control_exclusions'],flush=True)
# Number-only eight reconciliation, unknown local source numbers and eighth held word/dot.
errors0=len(Issues)
reconby={x['record_id']:x for x in recon}
if len(recon)!=8 or len(reconby)!=8 or set(reconby)!=({s['source']['source_parent_record_id'] for s in supp.values()}|{'HI-MSB-V1-P0583-N0705'}):problem('number_only','expected seven additions + one held case',detail=sorted(set(reconby)))
sevens=[]
for id,r in supp.items():
 par=r['source']['source_parent_record_id'];rec=reconby.get(par);q=source_by_id.get(id)
 if rec is None:problem('number_only','missing reconciliation',id);continue
 line,bodyhash,rawhash=rec['source_line_1based'],rec['body_sha256'],rec['raw_line_sha256']
 if (not q or q[0]!=line or th(q[1]['reviewed_draft'])!=bodyhash or sh(raw_lines[line-1])!=rawhash):problem('number_only','supplement source IDs/hash mismatches',id,rec)
 if (not rec['number_marker_is_outside_current_body'] or rec['whole_record_B03_or_unknown_page_guard'] or not rec['private_candidate_allowed_without_inferred_number'] or rec['source_digits_inferred'] or rec['release_approved']):problem('number_only','scope/guard policy on included 7 differs',id)
 if r['number']['in_book'] is not None or r['number']['canonical'] is not None or r['number'].get('local_sequence_uncertainty') is None:problem('number_only','number not null or missing uncertainty',id,r['number'])
 if par in whole|pg:problem('number_only','B03 whole/page held record released',id)
 for b in rec['related_broader_bundles']:
  cid=b.get('census_id');c=census_by.get(cid)
  if c is None:problem('number_only','related census ID absent',id,cid)
  if 'source_issue' in b.get('scope_disposition','') and b.get('physical_source_uncertainty_closed'):problem('number_only','physical source uncertainty declared closed',id,cid)
 sevens.append({'record_id':id,'parent':par,'number_issue':rec['accepted_local_number_issue_id'],'source_qc10_line':line,'body_sha256':bodyhash,'pdf_pages':r['page']['pdf'],'in_book':r['number']['in_book'],'canonical':r['number']['canonical'],'related_census_ids':[b['census_id'] for b in rec['related_broader_bundles']]})
excluded8='HI-MSB-V1-P0583-N0705';eighth=reconby.get(excluded8)
if not eighth or eighth.get('private_candidate_allowed_without_inferred_number') or eighth.get('whole_record_B03_or_unknown_page_guard') or excluded8+'-HI' in newbyid or excluded8 not in held:problem('number_only','eighth word/dot case not excluded',excluded8,eighth)
if eighth and not any(x.get('census_id')=='QC06-B-U0012' and x.get('scope_disposition')=='UNRELATED_SOURCE_WORD_UNCERTAINTY_REMAINS_HELD' for x in eighth.get('related_broader_bundles',[])):problem('number_only','eighth unrelated word/dot source hold not explicit',excluded8)
sections['number_only']={'eight_reconciled':len(reconby),'included_unchanged_7':len(sevens),'excluded_eighth':excluded8,'extra_seven':sevens,'mismatches':len(Issues)-errors0}
print('number-only',sections['number_only']['mismatches'],flush=True)
# Independently verify each closed manual projection digest only; zero textual/semantic re-review.
errors0=len(Issues)
closedby={x['text_record_id']:x for x in closed}
if len(closedby)!=14 or set(closedby)!=closedids:
 problem('closed_manual_guard','closed exact projection file contains different ID set',detail=sorted(set(closedby)^closedids))
manualhash=[]
for g in guard['checks']:
 r=closedby.get(g['textRecordId'])
 if not r:
  problem('closed_manual_guard','missing closed manual projection',g['textRecordId']);continue
 actual=r.get('reviewed_text_projection_sha256');recomp=th(r.get('reviewed_text_projection',''))
 if r.get('parent_record_id')!=g['parentRecordId'] or actual!=g['closedReviewedProjectionSHA256'] or recomp!=actual:
  problem('closed_manual_guard','closed immutable digest mismatch',g['textRecordId'],{'guard':g['closedReviewedProjectionSHA256'],'recorded':actual,'recomputed':recomp})
 manualhash.append({'id':g['textRecordId'],'approved_sha256':actual,'recomputed_match':actual==recomp,'in_2038':g['textRecordId'] in newbyid})
sections['closed_manual14_digest_exclusion']={'closed_projection_hashes_checked':len(manualhash),'original_closed_file_sha256':closed_sha,'closed_manual_parents':14,'overlap_2038':len(closedids & set(newbyid)),'all_14_approved_digest_matches':len(Issues)==errors0,'mismatches':len(Issues)-errors0,'digests':manualhash}
print('closed manual14 digest/exclusion',len(Issues)-errors0,flush=True)
# Independent 812 Hindi annotation coordinate/digest checks against actual current QC10 parent source bodies,
# plus distinction between embedded annotations, review source units and registered source records.
errors0=len(Issues)
meta=j('evidence/hindi-current-component-mapping-v001.json');anchors=meta['annotationChecks']; bad=[]
byparent={r['record_id']:r for _,r in allhi}
for a in anchors:
 ident=a['annotation_id'];par=a['record_id'];row=byparent.get(par)
 if not row:
  bad.append([ident,'parent missing',par]);continue
 parent=row['reviewed_draft']; start,end=a['span'];sel=parent[start:end]
 if not (0<=start<end<=len(parent)) or th(parent)!=a['current_parent_sha256'] or th(sel)!=a['selected_sha256']:
  bad.append([ident,'coordinate/parent hash mismatch',par,start,end])
 if a['inUnchangedControlSubset'] and par+'-HI' not in oldbyid:
  bad.append([ident,'reported unchanged control subset parent absent',par])
for b in bad[:30]:problem('annotation_812','anchored source annotation digest mismatch',b[0],b)
embedded=meta['embeddedAnnotationLayerCounts'];layer_sum=sum(embedded.values())
if len(anchors)!=812 or len({a['annotation_id'] for a in anchors})!=812:
 problem('annotation_812','812 source annotation anchors duplicated/missing',detail=[len(anchors),len({a['annotation_id'] for a in anchors})])
if layer_sum!=4152 or meta['embeddedAnnotationRows']!=4152:
 problem('annotation_4152','embedded annotations total/category count mismatch',detail=[layer_sum,meta['embeddedAnnotationRows']])
if any('ANN' in r['id'] for r in allnew) or any(r.get('record_type')!='hadith_occurrence' for r in allnew):
 problem('annotation_count','embedded annotations became Hindi Hadith records')
if len(main)!=4460 or collections.Counter(r['language'] for r in main)!={'hi':2230,'ar':2230}:
 problem('metadata_2230','main rows not 2230 Hindi+2230 Arabic',detail=dict(collections.Counter(r['language'] for r in main)))
# The source-archive 2,388 annotation-anchor rows are separate from precisely these 812 checked coordinate anchors.
sections['component_separation']={'current_main_rows':len(main),'main_language_counts':dict(collections.Counter(r['language'] for r in main)),'anchored_Hindi_annotation_coordinates_checked':len(anchors),'source_annotations_SHA_mismatches':len(bad),'annotations_in_original_2031_subset':sum(a['inUnchangedControlSubset'] for a in anchors),'embedded_annotation_classification_total':layer_sum,'separate_QC10_annotation_anchor_rows':len(qc['reviewed_annotation_anchors.jsonl']),'other_QC10_rows':{k:len(v) for k,v in qc.items() if k!='reviewed_main_texts.jsonl'},'annotations_added_as_Hadith':0,'mismatches':len(Issues)-errors0}
print('metadata/annotations',sections['component_separation']['mismatches'],flush=True)
# Material record+manifest schemas and source bibliographic snapshot/credit flag consistency.
errors0=len(Issues)
try:
 from jsonschema import Draft202012Validator
 recschema=j('actual-code/schemas/material-record.schema.json');manschema=j('actual-code/schemas/material-manifest.schema.json')
 rv=Draft202012Validator(recschema);mv=Draft202012Validator(manschema)
 for vol,key in V.items():
  m=j(f'registered-private-fixture/materials/{key}/manifest.json')
  for err in mv.iter_errors(m):problem('schema_manifest',err.message,key,list(err.path))
 for record in allnew:
  for err in rv.iter_errors(record):problem('schema_record',err.message,record['id'],list(err.path))
 schema_validator='jsonschema Draft202012Validator'; schema_records=len(allnew);schema_manifests=3
except Exception as e:
 problem('schema_runtime','schema validation unavailable',detail=str(e));schema_validator=None;schema_records=0;schema_manifests=0
for vol,key in V.items():
 p=f'registered-private-fixture/materials/{key}/'
 manifest=j(p+'manifest.json');prov=j(p+'provenance.json');support=manifest['supporting_files']
 for item in support:
  f=D/'registered-private-fixture'/item['path']
  if not f.is_file() or sh(f.read_bytes())!=item['sha256'] or f.stat().st_size!=item['size_bytes']:
   problem('manifest_support','material supporting hash missing/mismatched',key,item)
 audit=j(f'registered-private-fixture/private-audit/{key}-original-document_metadata.json')
 # Metadata is retained in private evidence, but the original document metadata is not loaded as a registration source.
 if manifest['publication'].get('authorized') is not True or manifest['publication'].get('rights_clearance_asserted') is not False:
  problem('future_publication_flag','original publication assertions differ',key,manifest['publication'])
 if manifest.get('current_scoped_review',{}).get('final_adapter')!='PENDING_NOT_ASSIGNED':
  problem('adapter_status','material claimed already approved final adapter',key)
 if prov['translator']['source_claim_verification']!='targeted_visual_self_review' or 'independently_verified' not in prov['printed_claims'][0]:
  problem('credit_verification','source credit provenance flags changed',key)
 for r in (x for x in allnew if x['source']['volume']==vol):
  if r['source']['printed_bibliographic_claims']!=prov['printed_claims']:
   problem('metadata_credit','source printed claims diverge from provenance',r['id'])
  if r['translator']!=prov['translator']:
   problem('metadata_credit','source translator differs from evidence metadata',r['id'])
  if r['rights']['status']!='not_assessed_for_publication':
   problem('rights_status','unsupported rights clearance',r['id'])
  if r['review']['release_eligible'] is not False:
   problem('release_status','record eligible for release unexpectedly',r['id'])
sections['schema_credit_policy']={'records_schema_checked':schema_records,'material_manifests_schema_checked':schema_manifests,'schema_validator':schema_validator,'support_files_SHA256_checked':6,'original_document_metadata_private_snapshots':3,'current_classification_policy':'Human as display route, historical origin and AI/process unknown retained','all_reading_rights_not_assessed':all(r['rights']['status']=='not_assessed_for_publication' for r in allnew),'mismatches':len(Issues)-errors0}
print('schema/credit',sections['schema_credit_policy']['mismatches'],flush=True)
res={'taskId':'HI-MSB-PART1-2038-CONTROL-ADAPTER-QC-001','mode':'independent_data_control_metadata_exclusion_only','source_zip_sha256':sh(Path('/mnt/data/HI-MSB-PART1-2038-CONTROL-ADAPTER-QC-001.zip').read_bytes()),'guard_json_sha256':sh(guardpath.read_bytes()),'previous_closed_manual_zip_sha256':sh(manual_zip.read_bytes()),'independent_mismatch_count':len(Issues),'status':'PASS_SCOPED_DATA_CONTROL' if not Issues else 'HOLD_CONTROL','sections':sections,'mismatches':Issues,'unverified_scope':['no source-page ink/canonical/semantic whole-book re-review','no publication/live repository write','no human issue decisions reopened']}
O.mkdir(exist_ok=True,parents=True)
(O/'control-recomputation.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('CONTROL RECOMPUTATION',res['status'],'MISMATCHES',len(Issues),'JSON',O/'control-recomputation.json',flush=True)
