#!/usr/bin/env python3
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib,sys,collections,time
D=Path('/mnt/data/hindi2038_qc_independent/input');R=Path('/mnt/data/hindi2038_qc_independent/results');CODE=D/'actual-code/scripts'
sys.path.insert(0,str(CODE))
from citation_search import record_citation_pairs,has_noncanonical_numbering
import material_registry
source=[r for group in material_registry.load_public_materials(D/'registered-private-fixture')['groups'] for r in group]
viol=[];nil=[]
for r in source:
 n=r['number'].get('in_book');pairs=sorted(':'.join(p) for p in record_citation_pairs(r))
 x={'id':r['id'],'source_parent_record_id':r['id'].removesuffix('-HI'),'source_entry_id':r['number']['source_entry_id'],'source_local_in_book':n,'canonical':r['number']['canonical'],'noncanonical_numbering_scope':has_noncanonical_numbering(r['number']),'actual_python_citation_pairs':pairs,'number_fields':r['number']}
 if n is not None and r['number']['canonical'] is None and 'bukhari:'+str(n) in pairs:viol.append(x)
 elif n is None:nil.append(x)
 else:raise AssertionError('Unexpected record numbering or citation route '+str(x))
assert len(viol)==2031 and len(nil)==7
(R/'canonical-reference-index-mismatches-2031.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in viol),encoding='utf8')
summary={'finding':'HOLD_REFERENCES_LOCAL_ABRIDGMENT_NUMBERS_INDEXED_AS_CANONICAL_BUKHARI','status':'HOLD','cases':len(viol),'null_number_cases_correctly_exempted':len(nil),'python_module':str(CODE/'citation_search.py'),'js_template':str(D/'actual-code/reader/template.html'),'sample_IDs':[x['id'] for x in viol[:8]],'sample_reference_pairs':viol[:3], 'full_evidence_file':'canonical-reference-index-mismatches-2031.jsonl'}
with sync_playwright() as play:
 browser=play.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1365,'height':900});page.set_content(Path('/mnt/data/hindi2038_qc_independent/work/actual-caller-fixture/private-2038-reader.html').read_text(),wait_until='load',timeout=60000)
 probe=page.evaluate('''() => {
   const result={functions:{hasNoncanonicalNumbering:typeof hasNoncanonicalNumbering,recordCitationPairs:typeof recordCitationPairs,records:typeof records},items:[]};
   if(typeof records==='undefined')return result;
   for(const id of ["HI-MSB-V1-P0040-N0001-HI","HI-MSB-V1-P0117-N0081-HI","HI-MSB-V2-P0041-N0770-HI"]){
     const r=records.find(x=>x.id===id);if(!r){result.items.push({id,error:'No real record'});continue;}
     result.items.push({id,number:r.number,recordCitationPairs:[...recordCitationPairs(r)].sort(),hasNoncanonicalNumbering:hasNoncanonicalNumbering(r.number)})
   }
   return result;
 }''')
 summary['javascript_actual_browser_probe']=probe
 try:
  page.locator('input[name="search-mode"][value="reference"]').check();page.locator('#query').fill('Bukhari 1');page.locator('#query').press('Enter');page.wait_for_timeout(2500)
  
  body_text=page.locator('body').inner_text();ui={'mode':'actual search results (not workspace)', 'query':'Bukhari 1', 'results_one_of_one':('1–1 of 1 results' in body_text or '1-1 of 1 results' in body_text), 'misleading_canonical_style_label_visible':('Sahih al-Bukhari 1' in body_text), 'source_Hindi_preview_visible':('उमर बिन खत्ताब रजि.' in body_text), 'html_reference_label_matches_bukhari_number':page.get_by_text('Sahih al-Bukhari 1',exact=True).count()>=1}
  summary['actual_query_bukhari_1']=ui
  path=R/'private-reader-canonical-local-number-mislabel-desktop.png';page.screenshot(path=str(path),full_page=False)
  summary['screenshot']={'file':path.name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 except Exception as e:summary['actual_query_browser_error']=repr(e)
 browser.close()
(R/'citation-reference-hold.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('sample_reference_pairs',)},ensure_ascii=False,indent=2))
