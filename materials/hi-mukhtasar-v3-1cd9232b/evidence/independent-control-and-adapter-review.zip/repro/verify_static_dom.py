from pathlib import Path
import json,hashlib,sys,collections
from bs4 import BeautifulSoup
R=Path('/mnt/data/hindi2038_qc_independent/results');D=Path('/mnt/data/hindi2038_qc_independent/input');sys.path.insert(0,str(D/'actual-code/scripts'))
from build_discovery import record_path
base=Path('/mnt/data/hindi2038_qc_independent/work/actual-caller-fixture/static-2038-proof')
rows=[]
for p in (D/'registered-private-fixture/materials').glob('*/records.json'):rows.extend(json.loads(p.read_text()))
errors=[];verified=0;credit=0;pages=[];n_with_source_number=0
for r in rows:
 p=base/record_path(r);doc=BeautifulSoup(p.read_text(encoding='utf8'),'html.parser')
 text=doc.select('details.language-reading div.reading-content div.text.quotation')
 actual=text[0].get_text() if len(text)==1 else None
 if actual!=r['text']['translation']:errors.append({'id':r['id'],'error':'exact static quotation mismatch','expectedSHA':hashlib.sha256(r['text']['translation'].encode()).hexdigest(),'actualSHA':hashlib.sha256(actual.encode()).hexdigest() if actual else None})
 if len(text)!=1 or text[0].get('lang')!='hi' or doc.select('div.quotation[lang=ar]'):errors.append({'id':r['id'],'error':'wrong quotation/language count'})
 if doc.select('details.language-reading div.commentary'):errors.append({'id':r['id'],'error':'commentary inside quote'})
 if doc.select('details.language-reading .ocr-warning') or '(OCR wasn’t clear)' in doc.get_text():errors.append({'id':r['id'],'error':'unnecessary OCR warning on unchanged no-hold'})
 labels=' '.join(e.get_text(' ',strip=True) for e in doc.select('details.language-reading .reading-source'))
 if 'Human' not in labels or 'ऐजाज़ ख़ान' not in labels:errors.append({'id':r['id'],'error':'wrong Human/translator source label','labels':labels[:150]})
 if r['number']['in_book'] is None:
  n_with_source_number+=1
  numtxt=' '.join(n.get_text(' ',strip=True) for n in doc.select('h1, p.reading-citation'))
  if 'Source number' in numtxt or 'Number in collection' in numtxt:errors.append({'id':r['id'],'error':'null local source number displayed as printed number','labels':numtxt[:250]})
 for a in doc.select('a[href]'):
  if 'private-audit' in a['href']:errors.append({'id':r['id'],'error':'private-audit linked'})
 verified+=1
summary={'records':len(rows),'static_pages_checked':verified,'exact_Hindi_body_matches':verified-sum(e['error']=='exact static quotation mismatch' for e in errors),'number_null_cases_checked':n_with_source_number,'errors_count':len(errors),'errors':errors[:100]}
(R/'static-independent-dom-check.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print({k:v for k,v in summary.items() if k!='errors'});print('first errors',errors[:3])
