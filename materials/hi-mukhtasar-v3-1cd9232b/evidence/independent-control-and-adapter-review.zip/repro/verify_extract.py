from pathlib import Path
import hashlib,json,zipfile,collections,time
p=Path('/mnt/data/HI-MSB-PART1-2038-CONTROL-ADAPTER-QC-001.zip')
out=Path('/mnt/data/hindi2038_qc_independent/input');res=Path('/mnt/data/hindi2038_qc_independent/results')
start=time.time()
with zipfile.ZipFile(p) as z:
 names=z.namelist()
 manifest=json.loads(z.read('MANIFEST.json'))
 errors=[]; verified=[]
 expected={x['path']:x for x in manifest['payloads']}
 if len(expected)!=len(manifest['payloads']):errors.append('duplicate manifest entries')
 if sorted(names)!=sorted([*expected,'MANIFEST.json']):errors.append('manifest ZIP name set differs')
 for info in z.infolist():
  n=info.filename
  if n.startswith('/') or '..' in Path(n).parts:errors.append(f'unsafe {n}');continue
  if n=='MANIFEST.json':continue
  h=hashlib.sha256();size=0
  target=out/n
  target.parent.mkdir(parents=True,exist_ok=True)
  with z.open(n) as src,open(target,'wb') as dst:
   while buf:=src.read(1024*1024):h.update(buf);size+=len(buf);dst.write(buf)
  e=expected.get(n)
  if not e or e['sha256']!=h.hexdigest() or e['bytes']!=size:errors.append(f'hash or length mismatch {n}')
  verified.append({'path':n,'bytes':size,'sha256':h.hexdigest()})
 outer_hash=hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
 if outer_hash!='5059b7623074ca7d83d6a2fda3dc26c73d188cafcb54e7f351eef1ec76305024': errors.append('Outer SHA mismatch')
 if p.stat().st_size!=57177495:errors.append('outer size mismatch')
 result={'packet_sha256':outer_hash,'packet_bytes':p.stat().st_size,'manifest_payloads':len(manifest['payloads']),'verified_payloads':len(verified),'crc': 'PASS' if z.testzip() is None else 'FAIL','issues':errors,'elapsed_seconds':round(time.time()-start,3),'payloads':verified}
 (res/'packet-integrity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print({k:v for k,v in result.items() if k!='payloads'})
