#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,traceback,time
from playwright.sync_api import sync_playwright
D=Path('/mnt/data/hindi2038_qc_independent/input');R=Path('/mnt/data/hindi2038_qc_independent/results');HTML=Path('/mnt/data/hindi2038_qc_independent/work/actual-caller-fixture/private-2038-reader.html').read_text(encoding='utf8')
ids=['HI-MSB-V1-P0040-N0001-HI','HI-MSB-V1-P0117-N0081-HI','HI-MSB-V1-P0247-N0257-HI','HI-MSB-V2-P0041-N0770-HI','HI-MSB-V2-P0086-N0833-HI','HI-MSB-V2-P0086-N0834-HI','HI-MSB-V2-P0154-N0933-HI','HI-MSB-V3-P0042-N1520-HI','HI-MSB-V3-P0539-N2108-HI','HI-MSB-V3-P0578-N2159-HI']
source={}
for p in (D/'registered-private-fixture/materials').glob('*/records.json'):
 for r in json.loads(p.read_text()):source[r['id']]=r
# Two additional normal controls across volumes, guaranteeing 12 real callers.
ids += [next(x for x in source if x.startswith('HI-MSB-V1-P0200-')),next(x for x in source if x.startswith('HI-MSB-V3-P0601-') or x.startswith('HI-MSB-V3-P0602-') or x.startswith('HI-MSB-V3-P0603-'))]
results=[];screens=[];errors=[];start=time.monotonic()
with sync_playwright() as play:
 browser=play.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for mode,width in [('desktop',1365),('mobile',390),('narrow-mobile',320)]:
  page=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1)
  page.on('pageerror',lambda err,m=mode:errors.append({'viewport':m,'pageerror':str(err)}))
  page.set_content(HTML,wait_until='load',timeout=75000)
  page.locator('input[name="search-mode"][value="reference"]').check()
  for i,id in enumerate(ids):
   row=source[id]
   page.locator('#query').fill(id)
   page.locator('#query').press('Enter')
   try:
    page.locator(f'#workspace-content .record-card[data-occurrence-id="{id}"] p.narration[lang="hi"]').wait_for(state='attached',timeout=14000)
    tgt=page.locator(f'#workspace-content .record-card[data-occurrence-id="{id}"]')
    text=tgt.locator('p.narration[lang=hi]').first.text_content()
    headings=page.locator('#workspace-heading').inner_text()
    data={'viewport':mode,'width':width,'id':id,'pass_body':text==row['text']['translation'],'body_sha256':hashlib.sha256(text.encode()).hexdigest() if text else None,
          'language_sections':tgt.locator('details.language-reading').count(),'language_hindi':tgt.locator('details.language-reading[data-language=hi]').count(),
          'arabic_readings':tgt.locator('p.narration[lang=ar], details.language-reading[data-language=ar]').count(),
          'display_human': 'Human translation' in tgt.inner_text(),'translator':row['translator']['name'] in tgt.inner_text(),
          'no_commentary_in_quote':not any(x in tgt.locator('p.narration[lang=hi]').first.text_content() for x in ['[Commentary:', '[Arabic:']),
          'ocr_note_displayed': '(OCR wasn’t clear)' in tgt.inner_text(),
          'canonical_ref_unestablished': 'Canonical reference not established' in headings,
          'text_number_null': row['number']['in_book'] is None,
          'horizontal_overflow':page.evaluate('document.documentElement.scrollWidth>window.innerWidth+1'),
          'headings':headings[:130],
          'workspace_visible':tgt.is_visible()}
    results.append(data)
    if (mode in ('desktop','mobile') and id in ['HI-MSB-V1-P0117-N0081-HI','HI-MSB-V2-P0086-N0833-HI','HI-MSB-V3-P0539-N2108-HI']):
     dest=R/f'private-reader-{mode}-{id}.png';page.screenshot(path=str(dest),full_page=False);screens.append({'path':dest.name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'id':id,'viewport':mode})
   except Exception as exc:
    errors.append({'viewport':mode,'id':id,'error':str(exc)[:2000]})
  page.close()
 browser.close()
summary={'browser':'chromium system /usr/bin/chromium','real_fixture_records':2038,'selected_ids':ids,'viewports':[1365,390,320],'runs':len(results),'expected_runs':len(ids)*3,'mismatches':[x for x in results if not all(x[k] for k in ('pass_body','language_hindi','display_human','translator','no_commentary_in_quote','workspace_visible')) or x['horizontal_overflow'] or x['arabic_readings'] or x['ocr_note_displayed'] or x['language_sections']!=1 or (x['text_number_null'] and not x['canonical_ref_unestablished'])],'errors':errors,'results':results,'screenshots':screens,'duration_seconds':round(time.monotonic()-start,2),'navigation_mode':'actual exact occurrence ID via DOM search and Enter; no static mock'}
(R/'actual-javascript-reader-12x3.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print('test runs',len(results),'expected',len(ids)*3,'mismatch',len(summary['mismatches']),'errors',len(errors),'elapsed',summary['duration_seconds']);print('examples',summary['mismatches'][:3],errors[:3]);print('screenshots',screens)
