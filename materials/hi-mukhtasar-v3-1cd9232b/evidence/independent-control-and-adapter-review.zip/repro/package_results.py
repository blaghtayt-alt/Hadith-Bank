#!/usr/bin/env python3
"""Assemble read-only independent bounded QC report, exact hash manifest and compact ZIP.
Only self-authored test code/results and screenshots are exported; no source/registry writes.
"""
from pathlib import Path
import json,hashlib,zipfile,datetime,shutil
ROOT=Path('/mnt/data/hindi2038_qc_independent');R=ROOT/'results'
OUT=Path('/mnt/data/HI-MSB-PART1-2038-INDEPENDENT-CONTROL-ADAPTER-QC-RESULT.zip')
def sha(b):return hashlib.sha256(b).hexdigest()
control=json.loads((R/'control-recomputation.json').read_text());packet=json.loads((R/'packet-integrity.json').read_text());adapter=json.loads((R/'adapter-real-caller-results.json').read_text());browser=json.loads((R/'actual-javascript-reader-12x3.json').read_text());cite=json.loads((R/'citation-reference-hold.json').read_text());static=json.loads((R/'static-independent-dom-check.json').read_text())
html=ROOT/'work/actual-caller-fixture/private-2038-reader.html';fixture_catalog=ROOT/'work/actual-caller-fixture/catalog/materials.json'
input_hash={'fixture_reader_html_sha256':sha(html.read_bytes()),'fixture_reader_html_bytes':html.stat().st_size,'fixture_catalog_json_sha256':sha(fixture_catalog.read_bytes()),'fixture_catalog_title':json.loads(fixture_catalog.read_text())['title'],'initial_fixture_html_sha256_from_initial_build_log':adapter['actual_reader_build']['reader_html_sha256'],'note':'Initial actual-loader build used a long test-only heading causing mobile width overflow; HTML rebuilt from unchanged 2,038 source records with normal-length Global Hadith Library heading and full real CSS; this is the exact hash browser tested. No packet/source/record modification.'}
(R/'exact-browser-input-hashes.json').write_text(json.dumps(input_hash,ensure_ascii=False,indent=2)+'\n')
assert packet['verified_payloads']==292 and not packet['issues']
assert control['independent_mismatch_count']==0 and control['status']=='PASS_SCOPED_DATA_CONTROL'
assert not adapter['script_errors'] and adapter['real_loader']['records']==2038
assert static['errors_count']==0 and static['exact_Hindi_body_matches']==2038
assert browser['runs']==36 and browser['expected_runs']==36 and not browser['errors'] and not browser['mismatches']
assert cite['cases']==2031 and cite['null_number_cases_correctly_exempted']==7
assert all(cite['actual_query_bukhari_1'][k] is True for k in ('results_one_of_one','misleading_canonical_style_label_visible','source_Hindi_preview_visible','html_reference_label_matches_bukhari_number'))
statuses={
'input_manifest_integrity':{'status':'PASS','tested':'57,177,495-byte packet; SHA-256, CRC, exactly 292 payloads including every SHA-256 and byte length'},
'source_bodies_identity_pdf_binding':{'status':'PASS','tested':'2,038 exact unchanged bodies, raw lines, page bindings and three original PDF hashes; 2,031 frozen plus 7 supplementation'},
'617_issue_census_join_B03_holds':{'status':'PASS','tested':'617 census, 1,879 source pointers, 1,803 field hashes, 262 B03 source selectors, 29 whole and 49 page holds, 192 remaining held parents, 141 unapplied patches'},
'closed_manual14_exclusion':{'status':'PASS','tested':'14 previous approved SHA-256 projections match previous closed archive and remain out of candidate pool'},
'number_only_cases':{'status':'PASS','tested':'seven null-local-number records, eighth HI-MSB-V1-P0583-N0705 excluded'},
'credit_component_schema_controls':{'status':'PASS','tested':'2,038 material-record schemas, 3 material-manifest schemas, 6 support hashes, 812 annotation coordinates, 4,152 embedded annotation categories; original process unknown retained'},
'actual_private_python_static_markdown':{'status':'PASS','tested':'load_public_materials 2,038, reader 2,038, 2,038 independent static HTML bodies, 90 Markdown .md files and one reader-manifest.json, no source edit'},
'actual_javascript_and_browser_sample':{'status':'PASS','tested':'22+48 JS tests and source panel test; 12 source IDs at desktop 1365, mobile 390 and narrow 320, 36/36 body/human/no-AR/no-overflow checks'},
'canonical_reference_adapter':{'status':'HOLD','tested':'2,031 local abridgment numbers interpreted as bukhari:<in_book> reference; Python citation_search and real reader Bukhari 1 search show collision-prone canonical-like index label'},
'final_live_and_public_release':{'status':'NOT_REVIEWED_HOLD','tested':'no source-page ink/semantic/complete-reader/live-repository/rights/publication certification performed; original private fixture used only'} }
status={'taskId':'HI-MSB-PART1-2038-CONTROL-ADAPTER-QC-001','overall':'HOLD_REFERENCE_ADAPTER_ONLY','data_control':'PASS','actual_body_static_browser':'PASS_SCOPED','candidate_count':2038,'candidate_split':[680,732,626],'frozen':2031,'supplement':7,'citation_adapter_affected':2031,'reference_null_unaffected':7,'other_independently_found_mismatches':0,'statuses':statuses,'unmodified_source_and_repo':True,'publication':False,'evidence':{'control':'control-recomputation.json','reference':'citation-reference-hold.json','all_reference_affected_IDs':'canonical-reference-index-mismatches-2031.jsonl','browser_screenshot':'private-reader-canonical-local-number-mislabel-desktop.png'}}
(R/'QC-STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
report='''# HI-MSB-PART1-2038-CONTROL-ADAPTER-QC-001 — independent bounded report

**Overall: HOLD — citation/reference adapter. DATA/CONTROL/unchanged bodies: PASS.** The sole independently reproduced adapter mismatch is not a changed Hindi source body or a human decision; it is a 2,031-record *indexing/presentation* defect. This private fixture was not published or registered to the live corpus.

## Integrity and immutable source controls

- Outer ZIP: **57,177,495 bytes**; SHA-256 `5059b7623074ca7d83d6a2fda3dc26c73d188cafcb54e7f351eef1ec76305024`; CRC PASS; **292/292** payload manifest hashes, byte lengths and inventory exact. The closed-manual guard JSON is independently hashed in `control-recomputation.json`.
- Candidate records: **2,038** exactly, **680/732/626** by source volume, no duplicate IDs. Original **2,031** are byte-for-field equal to frozen canonical material records (678/729/624), supplemented by exactly seven exact separate source candidates (2/3/2). All **2,038 bodies** match the actual current QC10 Hindi `reviewed_draft` field and UTF-8 body hash, source JSONL raw-line SHA and immutable selected source binding map.
- Original PDF SHA-256 and physically parsed page counts:
  - V1: `4785913cafaa60e2e19e3fa0467055fcedd1be08877c2cafad72bdc73057c339`, **638 pages**.
  - V2: `d99bfae5390146f120d45e07abaf5006e0df67b9a4ab55ef2091b2a88213f3fb`, **643 pages**.
  - V3: `1cd9232b8ba489477f26133772a404b36deabe1fc72e4732fb7bb42278947d9a`, **640 pages**.
- Current QC10 main table SHA-256 `e31163f9f43edd2b24e77b555e79fe3236e2c6ed53e42be15f1366f1075d996f`. **2,230 Hindi + 2,230 Arabic** main rows. Registered 2,038 Hindi candidates plus preserved 192 Hindi held parents account for all 2,230. Only Hindi translated bodies enter the candidate material records; Arabic, commentary, front/back matter, footnotes and metadata are not incorrectly added as independent Hindi Hadith readings.

## Census, exclusion and manual boundary

- **617/617** source census-to-join entries recomputed from current 9 QC10 JSONL tables: **1,879** field/source bindings, **1,803** individual field SHA checks, **0** pointer/identity/hash mismatches; category partition **149 Hindi-main-linked / 428 other-component / 40 unbound**. **29 B03 whole-record and 49 conservative page-guard holds** retained; **262 B03 source selectors** checked, no mismatch. **141 QC11/QC12 review-only patches remain unapplied**; source bodies not silently patched.
- The **14** closed manual parent IDs and their approved projected-text SHA-256 values exactly match the *previous closed manual application archive*; **0/14** overlap with these 2,038 candidates. No review of their words or decisions was repeated.
- **7** number-only source cases remain unchanged with both `number.in_book=null` and `number.canonical=null`; unknown source digits were not guessed. The eighth **HI-MSB-V1-P0583-N0705 / QC06-B-U0012** retains its word/dot hold and is excluded. A number/metadata component exclusion did not discharge that body hold.
- **812** previously reconciled Hindi annotation-span controls independently rehashed against actual current parent reviewed_draft/source coordinate ranges; 812/812 matched, including 728 marked unchanged-source-subset. The earlier **4,152 embedded annotations** are separate editorial/component classifications, not registered hadith; the QC10 standalone `reviewed_annotation_anchors.jsonl` has **2,388 different source rows**, which must not be conflated with the 812 coordinate witnesses. Neither group increases the 2,038 count.

## Material/adapter real-caller verification

- `jsonschema` Draft202012Validator: **2,038/2,038 records** and **3/3 material manifests** pass schema validation. **6/6** material support files match exact declared hashes and sizes. Original private document metadata for 3 volumes remains under `private-audit`, excluded from material registration and record projections.
- Real extracted `material_registry.load_public_materials` loads **2,038** Hindi records, three volumes, no duplicates. The current display classification is **Human** for 2,038; original `translation_provenance.origin=unknown` and `ai_translation=unknown` remain separately preserved for all 2,038. Credit source is **ऐजाज़ ख़ान**, with its original `targeted_visual_self_review` / not-independently-certified flags retained; credit/glyph certification is explicitly NOT claimed here. **Counterparts disabled** for all 2,038; verified canonical fields null.
- Real `build_reader` builds one self-contained **2,038-reading** private HTML reader, with unchanged quoted texts; **90 `.md` pages plus one JSON reader manifest** (91 output files). Real `build_discovery` creates **2,038 static record pages**; every static Hindi quoted-body text was independently parsed and compared byte-for-text against canonical source (**2,038/2,038**). No Arabic/commentary appeared in those static readings.
- Selected original JavaScript tests: discovery engine **22 PASS**, lazy store **48 PASS**, source-scoped panel **PASS**. Actual Chromium source-reader: **12 IDs x 3 widths (1365/390/320)=36/36** match exact Hindi body, translator credit, Human label, absent Arabic/counterparts and no horizontal overflow. Normal-length scratch heading `Global Hadith Library` was used to avoid an artificially long test-only title; source/record bytes were never altered. Browser used `page.set_content` because sandbox denied `file://`. Tested HTML input SHA-256: `c9dd7315d468f0eae32e20a9e6e6ff7e5145785a73ee8bad6300d72a86f7d833`.
- The unchanged 2,038 bodies have no pending source glyph notes and are **not blanket-marked** with `(OCR wasn’t clear)`. The separate note-rendering repair and the closed manual16 application are explicitly outside scope.

## Reproduced adapter HOLD: abridgment-local numbers falsely become collection reference pairs

**Exact affected set: 2,031 IDs**, enumerated in `canonical-reference-index-mismatches-2031.jsonl`. All 2,031 original records carry an abridgment-local `number.in_book` but none has `numbering_system`, a noncanonical `numbering_scope` / `numbering_scheme`, or `sequence_is_hadith_number=false`. `number.canonical` is null. Actual Python `scripts/citation_search.py` (`has_noncanonical_numbering`, `record_citation_pairs`) therefore adds `('bukhari', number.in_book)` for **2,031/2,031**, incorrectly treating local abridgment numbering as a standard collection reference. The original JavaScript reader `reader/template.html` has analogous `hasNoncanonicalNumbering` / `recordCitationPairs` logic. `scripts/bank_discovery.py` turns these citation pairs into `Sahih al-Bukhari <number>` display references.

**Actual browser witness:** In the unmodified production-style reader (private scratch fixture), Reference query **`Bukhari 1`** returns **1 of 1** results, the Hindi Mukhtasar source entry **`HI-MSB-V1-P0040-N0001-HI`**, with title **`Sahih al-Bukhari 1`**. See `private-reader-canonical-local-number-mislabel-desktop.png`. This is a displayed/indexed canonical-looking **misattribution risk**; it is *not* evidence that this fixture actually merged with a different edition, since that full context was not present.

The **seven null-number additions** do not form these pairs, so 7/7 are safe on this specific test. No new digits were invented, all bodies and source hashes remain unchanged, and counterparts remain disabled. **The absence of counterpart matching does NOT prevent the citation/reference indexing defect.**

**Minimum separate-owner correction for later integration (NOT applied here):** Explicitly mark the 2,031 source edition numbers as `abridgment`/edition-local with a recognized noncanonical numbering scope (or equivalent verified adapter-level protection) while preserving their literal existing printed numbers and all source/history; then rerun Python and real browser reference-index negative tests and ensure `Bukhari 1` no longer identifies a Hindi abridgment record as canonical. No unapproved canonical ID matching, numeral changes or forced narration-family merges.

## Release and limits

- **DATA/CONTROL/record schema/isolated actual build/selected body-browser routes: PASS. Citation/reference adapter: HOLD. Overall: HOLD for integration/public eligibility.** The scoped QC does not establish semantic fidelity, full PDF ink/whole-corpus certification, rights approval, live reader verification, correct cross-edition parallel-narration mappings, or authorization to publish.
- The private fixture's manifest carries `publication.authorized=true` as a *future owner intent*; its loader marks `published_pending_review` internally. The 2,038 candidate record reviews nevertheless have `release_eligible=false` and rights `not_assessed_for_publication`. **No live/public write was made; these fixture flags do not authorize publication.**
- No source, repo, hold, manual decision, French/notes software file, or production corpus was modified. The outer packet with its three original source PDFs is **not bundled again** in this compact evidence result. The output manifest and every included artifact hash are verified independently.
'''
(R/'QC-REPORT.md').write_text(report,encoding='utf8')
files=['QC-REPORT.md','QC-STATUS.json','packet-integrity.json','control-recomputation.json','control-recomputation.log','adapter-real-caller-results.json','adapter-real-caller-execution.log','static-independent-dom-check.json','actual-javascript-reader-12x3.json','browser-12-actual.log','selected-real-javascript-tests.log','citation-reference-hold.json','citation-reference-hold.log','canonical-reference-index-mismatches-2031.jsonl','exact-browser-input-hashes.json','overflow-diagnostic-short-title.log','real-search-probe.log']
files+=sorted(x.name for x in R.glob('*.png'))
scripts=['verify_extract.py','run_control_qc.py','run_adapters.py','verify_static_dom.py','browser_12_actual.py','probe_citation_holds.py','package_results.py']
manifest={'taskId':status['taskId'],'input_outer_zip':{'bytes':packet['packet_bytes'],'sha256':packet['packet_sha256'],'payloads_verified':packet['verified_payloads']},'result_payloads':[],'input_replicated':False,'status':status['overall']}
for file in files:
 p=R/file
 assert p.is_file(),file
 manifest['result_payloads'].append({'path':'results/'+file,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
for file in scripts:
 p=ROOT/file
 assert p.is_file(),file
 manifest['result_payloads'].append({'path':'repro/'+file,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
manifest['result_count']=len(manifest['result_payloads'])
manifb=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
(R/'ARTIFACT-MANIFEST.json').write_bytes(manifb)
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7,allowZip64=True) as z:
 for file in files:z.write(R/file,arcname='results/'+file)
 for file in scripts:z.write(ROOT/file,arcname='repro/'+file)
 z.writestr('ARTIFACT-MANIFEST.json',manifb)
with zipfile.ZipFile(OUT) as z:
 assert z.testzip() is None
 members={a.filename for a in z.infolist()}
 assert len(members)==len(z.infolist())
 assert members=={x['path'] for x in manifest['result_payloads']}|{'ARTIFACT-MANIFEST.json'}
 assert z.read('ARTIFACT-MANIFEST.json')==manifb
 for x in manifest['result_payloads']:
  b=z.read(x['path']);assert len(b)==x['bytes'] and sha(b)==x['sha256'],x['path']
print('PACKAGE',OUT,'bytes',OUT.stat().st_size,'sha256',sha(OUT.read_bytes()),'members',len(members),'manifest_payloads',manifest['result_count'],'ZIP CRC+SHA verified','STATUS',status['overall'])
