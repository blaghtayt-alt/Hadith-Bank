# PT-BUKHARI-SIX-FINAL-ADAPTER-QC-001 — Independent v002 final adapter review

**Verdict:** Six v002 records **PASS** bounded source-body preservation, metadata/manifest, exact one-field translator delta, canonical projection parity, and independently executed offline reader JavaScript (desktop/mobile). **HOLD** final combined production adapter acceptance because the original repository Python registry/static/Markdown entrypoints were *not independently executed* in this environment; publication, whole-bank CI, and live site are separate out-of-scope gates.

## Exact immutable review target

- Final `records.json`: `a4c590a2ba99b4e08372d94c4d6f9b17173a820c45d65bd21a9d76c36ca24c2b` (32,298 bytes).
- Final material `manifest.json`: `4da89c7b7fb764d2c615280feb67d303c24b2a430d34d99a67440de2c2dcf666` (4,260 bytes).
- Original `source.pdf`: `1b5ef269f948b88d897755cfeb4af64ee085d009f7b4ff389691b9c0f6a7e347` (6,321,982 bytes; 830 physical PDF pages, metadata check only).
- Outer original handoff ZIP: `fa04e4715432c151ff9033ed3af75ce0ec483c33d60afab85a46e0708b6e1ca3` (7,043,691 bytes).
- Registered supplement v002 ZIP: `228dc675836abfc3d0f805b90aaecb7462e143cfc7a26f319b0a836050c5e814` (604,552 bytes).
- Nested original private stage ZIP: `94d43fdf23e20e8ec44134b5daff0a37348f5ce736028bdd2fe3fc3dd5c6cde7` (7,039,559 bytes).

## Scope / row verdicts

| Occurrence | Printed global ref | Livro / Hadith | PDF page | Body SHA prefix | Result |
|---|---|---|---:|---|---|
| `pt_bukhari_v3_0456` | `5441a` | `70` / `69` | 148 | `ee3c2436e92b5d52` | PASS |
| `pt_bukhari_v3_0457` | `5441a` | `70` / `70` | 148 | `45896384969728d2` | PASS |
| `pt_bukhari_v3_0496` | `5480` | `72` / `05` | 161 | `b520c0ea6cec126d` | PASS |
| `pt_bukhari_v3_0497` | `5480` | `72` / `06` | 161 | `c57fafb48f7fcb3d` | PASS |
| `pt_bukhari_v3_0502` | `5486` | `72` / `11` | 163 | `61bb5833933d54d8` | PASS |
| `pt_bukhari_v3_0503` | `5486` | `72` / `12` | 163 | `7b758da1dea178fc` | PASS |


All six remain separate source occurrences, including duplicate as-printed global tokens `5441a`, `5480`, `5486`; Livro 72 Hadith `05`/`06` leading zeroes are preserved. Source book and source in-book numbering remain separate from any unverified canonical mapping.

## Evidence-backed checks

- Both outer archives pass size, SHA-256, ZIP CRC and all manifest entries (original 3 payloads; supplement 15 payloads). The nested stage ZIP passes CRC and ten v001 manifest payloads.
- Reconstruction copied **only** the original `materials/<slug>` subtree into the isolated fixture and overlaid the supplement. V001 root staging scope/manifest remain unmodified in a separate `historical-v001` folder. Source PDF, source QC ZIP, span-map, raw source records and old canonical records hashes are unchanged.
- Exact v001-v002 JSON deep comparison: the only change in each row is `translation_provenance.translator`, copied byte-for-byte as a JSON value from the already present top-level translator object. All six unchanged body SHA-256 hashes also match original-source prefix span and the supplied span map.
- Exactly three component roles exist: narrator attribution + source line breaks + Portuguese translation in body; original terminal compilation citation outside body. No Arabic body added; `text.arabic=null`, commentary `{arabic:null,translation:null}`, footnotes empty, no inferred linked counterpart.
- Material/source/supporting-file manifest checks, path boundaries, basic real-repo schema constraints (source code read-only inspected), owner Human current-display policy separate from preserved historical `unknown` AI/process flags, release and rights flags not silently changed.
- Embedded standalone reader is bound to the exact candidate SHA. Independently recomputed per-record canonical SHA using the production `canonical(value)` specification from `scripts/build_bank_views.py`. Actual 46,030-byte production CSS block SHA-256 independently located in the standalone artifact.
- Chromium executed the supplied real inline reader JavaScript from the exact HTML via `page.set_content` (not the public site). For each of six IDs on desktop 1365 px and mobile 390 px, verified literal DOM Portuguese body SHA, source citation outside quote, visible translator and Human tag, source page metadata, absence of Arabic/English and comments, and no document horizontal overflow. Printed reference queries 5441a / 5480 / 5486 each returned two **distinct** source occurrences in both viewports. No JavaScript exceptions or failed network requests.
- Original producer screenshots/results treated as assertions only. Four newly captured independent Chromium screenshots are included.
- Production Python `material_registry.py`, `current_provenance.py`, `build_reader.py` and schema source were inspected read-only; independent field/Markdown precondition tests passed. **The complete original Python code was not executed**: do not report the producer’s six Python/static/Markdown tests as an independent production-code execution.

## Targeted field/display observations (no source rewrite)

1. **UI-REFERENCE-LABEL-001 — advisory copy HOLD for public presentation.** The main title says “Collection number not supplied” because `number.canonical` and `number.in_book` are deliberately null. The original printed reference is correctly visible under citations. To avoid ambiguity, UI copy could say “No verified canonical number”, without promoting duplicate printed tokens into canonical identity.
2. **UI-NARRATOR-LABEL-002 — advisory copy HOLD for public presentation.** `narrator.name` is null, but `narrator.intro_as_printed` contains a narrator attribution. The detail fallback “Not named in the supplied source” can mislead. Prefer “Narrator not separately indexed” without inferring a canonical narrator or altering source wording.
3. **INTEGRATION-PYTHON-001 — explicit untested gate.** Exact pinned production Python material registry/static/Markdown execution in a complete suitable test environment, and normal production CI, remain outside this verified run. Source code inspection and candidate-field parity do not replace this.
4. **PUBLICATION-GATE-001 — explicit external gate.** `publication.authorized=true` in the isolated fixture encodes owner intent; it does **not** assert release eligibility, certified QC, rights clearance or a live deployment. `review.release_eligible=false`, `certified_release_eligible=false`, current fixture snapshot `input_files_verified=false`. No link-target availability was certified.

## Limits and no-write guarantee

This is a private read-only six-record QC. Closed 44-line/3-page source review was not reopened; no new OCR, semantic, source glyph, translator attribution, Arabic, English, canonical numbering or license work was performed. No GitHub/shared repository writes, publication, new workers or external messages. Original input archives remain unmodified. All output payload hashes are bound by `OUTPUT-MANIFEST.json`.
