# Hadith Bank — readable records

[Browse books online](https://blaghtayt-alt.github.io/Hadith-Bank/browse/) · [Book and source-edition directory](../catalog/BOOKS.md)

6 source occurrences, organized by language, book and source edition.

Open a language, then a book and edition. Every page shows up to 25 narrations with their source, translator, translation origin and OCR review where applicable. Arabic, commentary and audit details are expandable. Repeated narrations and source versions are retained.

- [Português — Portuguese](pt/README.md) — 6 source occurrences

Source stream SHA-256: `a3924a30f8ecc0a0cc911259081ab3da8748e9e7e632b555f60f265c7d107a8a`.

These reading views do not change the source review status or certify narration authenticity.
