# PT-BUKHARI-SIX — executable Python adapter successor (same reviewer)

**Result: PASS, for the exact isolated six-record fixture and the pinned supplied code.** This is the missing actual-Python execution review only; the preceding 44-line source review, static/data QC and offline-browser reviews remain closed.

## Input integrity

- Source ZIP: 8,199,910 bytes; SHA-256 `6507a00235aeda4f9ef286c39b66581bdb9d643f6486d6b70db1e869b02252b6` (PASS).
- `MANIFEST.json`: 241/241 payload hashes and byte lengths verified, ZIP CRC test passed for 242 entries, no unsafe or duplicated archive paths.
- Six v002 records SHA-256: `a4c590a2ba99b4e08372d94c4d6f9b17173a820c45d65bd21a9d76c36ca24c2b` (PASS).
- Final material manifest SHA-256: `4da89c7b7fb764d2c615280feb67d303c24b2a430d34d99a67440de2c2dcf666` (PASS).
- Preserved original PDF SHA-256: `1b5ef269f948b88d897755cfeb4af64ee085d009f7b4ff389691b9c0f6a7e347` (PASS, hash only; no source re-review).
- All manifest supporting evidence paths, hashes and byte lengths verified.
- All 241 extracted input files rehashed after execution: identical to original ZIP.

## Commands run, exit status 0

```sh
cd /mnt/data/PT6_Executable_Python_Scope_Review
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 python -B run_actual_adapters.py --output execution-independent > entrypoint.log 2>&1
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 python -B independent_assertions.py > independent_assertions.log 2>&1
```

## Production routes actually executed

| Route | Finding | Concrete evidence |
|---|---|---|
| `material_registry.load_public_materials` | PASS | 1 manifest, source + evidence SHA checks, 6 distinct projected records |
| `build_reader.load_records` | PASS | `search/records.jsonl` round trip exact, 6 records identical to registry projection |
| `build_reader.build` | PASS | 388,094-byte self-contained standalone HTML with 6 full exact gzip/base64-embedded projected records |
| `build_discovery.build` | PASS | 6 individually identified occurrence HTML pages; 15 static files; all 6 rendered quote text values equal source |
| Markdown builder | PASS | 1 reading page + 4 README/index files; 6 separate sections; all 6 full body texts recovered exactly |
| Record/manifest JSON Schemas | PASS | 6 canonical rows + 1 manifest validated against supplied draft-2020-12 schemas |

The independently authored audit passed **491/491 assertions**, including re-verifying the production artifacts rather than relying solely on the supplied harness, and all module/input hashes after execution. See `evidence/independent-evidence.json`, `evidence/independent_assertions.py`, and both logs.

## Tested source/data/display invariants

| Printed reference | Source book / Hadith | Stable distinct IDs | PDF page | Result |
|---|---|---|---:|---|
| `5441a` | `70/69`, `70/70` | `_0456`, `_0457` | 148 | PASS — two occurrences |
| `5480` | `72/05`, `72/06` | `_0496`, `_0497` | 161 | PASS — leading zeroes kept |
| `5486` | `72/11`, `72/12` | `_0502`, `_0503` | 163 | PASS — two occurrences |

`number.canonical` and `number.in_book` remain `null`. The separately preserved printed reference, source book and within-book numbering are unchanged, and there is no canonical inference or counterpart matching. Full Portuguese body strings (including inline Arabic honorific Unicode) were compared exactly after projection, embedded-reader decompression, static HTML extraction and Markdown decoding. Source Arabic matn is `null`, there are no Arabic/commentary reading panels, and `counterpart_policy.mode` remains `disabled`. The six bodies, IDs, pages, narrators, source PDF binding, citation details and holds remain unchanged; v001-to-v002 difference is limited to copying the already credited translator into `translation_provenance.translator` on each row.

The reader shows **Juma Momade Anli**. Current `Human` classification is owner policy and coexists with the historical `unknown` AI/process flags, which remain intact in the output data. No source meaning/glyph/transcription review was repeated.

## Actual code hashes (SHA-256)

- `material_registry.py` — `0aafebef031e952e45d4a426692976a184cd362babd63e63fbcfb0d1595001d0`
- `build_reader.py` — `3be859ea6b7ce807b750a07969cdd19c3d4f3581f49f0cc3afe5e972728e9d44`
- `build_discovery.py` — `42474d02cd14526e6d1bedd0823044a2306254550895006b1b818bfb29503069`
- `current_provenance.py` — `ab2e4a45eba6a5cb3b580da2a2e9c3b6ec84c8d1a07d5355a2e4c0bab4220243`
- `language_display.py` — `909279a48e0521167a3ff1f7022e8159b1737eba20395202378dd966792bd18f`
- `build_bank_views.py` — `2b81548c3cd8e7ebc8dda5f6c8e4fb1b891d8f3e7a1f4c1b6bd8bfd2db1f21c6`
- `source_glyphs.py` — `2ff2e42a56946b2778bce80357668674a0a64882e93df4f4a55183cd32fa02a1`

- Code tree canonical path/size/hash list (all 222 supplied `actual-code/*` files): `69e74d6b65d713d7c479063c823bcd5ab15216a6cc7281c7e3739eb8a0433a15`

## Limits / remaining holds

**No actual defect was found in the five bounded Python routes in this offline fixture.** This is not final acceptance of the combined French/Hindi code, fresh shared HEAD, all-source/full-corpus CI or deployed site. The offline generated static pages include canonical/public PDF links based on the template, **but these links were not fetched or published**. Existing wording cautions about absent normalized collection numbering and `narrator.name` remain integration recommendations only. No release/semantic/canonical clearance is granted. SOURCE/BOOK QC and original license questions were not reopened. No code, source PDF, canonical records or input manifests were modified; no network, repository write, deployment or new worker was used.

The code lineage in `TARGET.json` is a claim from the packet; this review independently verifies the specific supplied bytes, not a separate upstream-source packet.

## Package manifest

Every ZIP payload is recorded in `MANIFEST.json` with SHA-256 and byte length. The ZIP excludes the 6.3 MB original source PDF and includes the generated standalone reader, six static occurrence pages, Markdown, reproducible assertions and execution logs. The original runnable supplement remains the source for the exact production modules and fixture.
