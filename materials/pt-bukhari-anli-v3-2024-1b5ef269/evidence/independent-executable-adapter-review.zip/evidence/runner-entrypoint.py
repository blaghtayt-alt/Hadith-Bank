from pathlib import Path
import argparse,collections,hashlib,json,shutil,sys
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--output',default='execution-independent');args=parser.parse_args()
OUT=(P/args.output).resolve();assert P in OUT.parents and not OUT.exists(),'Choose a new output folder inside this extracted packet.'
CODE=P/'actual-code';DATA=P/'registered-private-fixture';CONFIG=json.loads((P/'TARGET.json').read_text(encoding='utf-8'))
sys.path.insert(0,str(CODE/'scripts'))
import material_registry,build_reader,build_discovery
from current_provenance import classification
from language_display import language_readings
H=lambda b:hashlib.sha256(b).hexdigest()
raw=[]
for spec in CONFIG['recordFiles']:
 p=DATA/spec['path'];assert H(p.read_bytes())==spec['sha256'];raw+=json.loads(p.read_text(encoding='utf-8'))
assert len(raw)==CONFIG['records']
reg=material_registry.load_public_materials(DATA);records=[r for group in reg['groups'] for r in group];assert len(records)==len(raw)
byid={r['id']:r for r in raw};assert len(byid)==len(raw) and {r['id'] for r in records}==set(byid)
checks=[]
for r in records:
 original=byid[r['id']];assert r['text_translation']==original['text']['translation'] and r['text_arabic'] is None
 assert r['number']==original['number'] and classification(r)=='human'
 assert r['ai_translation']=='unknown' and r['translation_provenance']['origin']=='unknown'
 assert r['counterpart_policy']['mode']=='disabled'
 readings=language_readings(r);assert len(readings)==1 and readings[0]['language']==CONFIG['language'] and not readings[0]['comments']
 checks.append({'id':r['id'],'bodySHA256':H(r['text_translation'].encode()),'number':r['number'],'readingLanguage':CONFIG['language'],'currentHumanDisplay':True,'historicalUnknownFlagsPreserved':True,'counterpartsDisabled':True})
OUT.mkdir();ROOT=OUT/'fixture'
for kind in ['materials','catalog']:shutil.copytree(DATA/kind,ROOT/kind)
stream=ROOT/'search/records.jsonl';stream.parent.mkdir()
stream.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in records),encoding='utf-8',newline='\n')
catalog={'title':'PRIVATE bounded adapter execution proof','record_count':len(records),'scope':'offline_private_adapter_execution','materials':reg['materials'],'by_language':{CONFIG['language']:len(records)},'search':{'records_path':'search/records.jsonl','records_sha256':H(stream.read_bytes()),'count':len(records)},'publication':{'claim':'NOT_PUBLISHED_PROOF'}}
(ROOT/'catalog/materials.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
loaded,cat,info=build_reader.load_records(ROOT);assert loaded==records
reader=build_reader.build(ROOT,OUT/'private-reader.html',markdown_output=OUT/'markdown',compress=True)
static=build_discovery.build(ROOT,OUT/'static')
assert static['record_pages']==len(records)
mdfiles=list((OUT/'markdown').rglob('*.md'));assert mdfiles
result={'scope':'Actual bounded Python registry/load_records/full-reader/static/Markdown execution, not full corpus or live publication.','target':CONFIG,'codeModulePaths':{n:sys.modules[n].__file__ for n in ['material_registry','build_reader','build_discovery']},'records':len(records),'registryMaterials':len(reg['materials']),'roundTripExact':True,'recordChecks':checks,'reader':reader,'static':static,'markdownFiles':len(mdfiles),'currentHumanDisplay':len(records),'oldUnknownFlagsPreserved':len(records),'publicWrite':False,'sourceReviewRepeated':False}
(OUT/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'records':len(records),'registry':'PASS','roundTrip':'PASS','actualReaderBuild':'PASS','staticRecordPages':static['record_pages'],'markdownFiles':len(mdfiles),'result':str(OUT/'RESULT.json'),'publication':False}))
