#!/usr/bin/env python3
"""Independent, offline, bounded PT6 execution audit; no supplied inputs are altered."""
from __future__ import annotations
import base64, collections, copy, gzip, hashlib, html, json, re, sys, zipfile
from pathlib import Path
from bs4 import BeautifulSoup
from jsonschema import Draft202012Validator, FormatChecker

HERE=Path(__file__).resolve().parent
FIX=HERE/'registered-private-fixture'
EXEC=HERE/'execution-independent'
SLUG='pt-bukhari-anli-v3-2024-1b5ef269'
MAT=FIX/'materials'/SLUG
CODE=HERE/'actual-code'
REPORT=HERE/'independent-evidence.json'
MANIFEST_SHA='4da89c7b7fb764d2c615280feb67d303c24b2a430d34d99a67440de2c2dcf666'
RECORD_SHA='a4c590a2ba99b4e08372d94c4d6f9b17173a820c45d65bd21a9d76c36ca24c2b'
SRC_SHA='1b5ef269f948b88d897755cfeb4af64ee085d009f7b4ff389691b9c0f6a7e347'
ARCH_SHA='6507a00235aeda4f9ef286c39b66581bdb9d643f6486d6b70db1e869b02252b6'
EXPECTED=[('0456','5441a','70','69',148,'144'),('0457','5441a','70','70',148,'144'),
          ('0496','5480','72','05',161,'157'),('0497','5480','72','06',161,'157'),
          ('0502','5486','72','11',163,'159'),('0503','5486','72','12',163,'159')]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
raw=json.loads((MAT/'records.json').read_text(encoding='utf-8'))
baseline=json.loads((MAT/'evidence/records-before-attributed-reading-credit-v001.json').read_text(encoding='utf-8'))
manifest=json.loads((MAT/'manifest.json').read_text(encoding='utf-8'))
assert sha(MAT/'records.json')==RECORD_SHA
assert sha(MAT/'manifest.json')==MANIFEST_SHA
assert sha(MAT/'source.pdf')==SRC_SHA
assert sha('/mnt/data/PT6-EXACT-RUNNABLE-ADAPTER-SUPPLEMENT-001.zip')==ARCH_SHA
assert len(raw)==len(baseline)==6

counts=collections.Counter()
checks=[]
def check(test,label):
    counts['PASS' if bool(test) else 'FAIL']+=1
    if not test:raise AssertionError('Independent assertion failed: '+label)
    checks.append(label)

check(len({r['id'] for r in raw})==6,'six unique records')
check(manifest['records']['sha256']==RECORD_SHA and manifest['records']['count']==6,'registration records descriptor')
check(manifest['source']['sha256']==SRC_SHA and manifest['source']['format']=='pdf','source descriptor bound to verified PDF')
check(manifest['counterpart_policy']['mode']=='disabled','registration counterpart disabled')
check(manifest['publication']['authorized'] is True and manifest['publication']['independent_whole_book_qc_asserted'] is False,'authorization separate from independent book QC')
for e in manifest['supporting_files']:
    p=FIX/e['path']
    check(p.is_file() and sha(p)==e['sha256'] and p.stat().st_size==e.get('size_bytes',p.stat().st_size),'supporting file '+p.name)

# Validate existing full schemas without changing them or invoking any publication operation.
for name,data in [('material-record.schema.json',r) for r in raw]+[('material-manifest.schema.json',manifest)]:
    schema=json.loads((CODE/'schemas'/name).read_text())
    errors=list(Draft202012Validator(schema,format_checker=FormatChecker()).iter_errors(data))
    check(not errors,'schema '+name + (': '+str(errors[0]) if errors else ''))

for a,b,x in zip(raw,baseline,EXPECTED):
    rid,num,book,local,page,printed=x
    check(a['id']==b['id']==f'pt_bukhari_v3_{rid}',rid+' ID unchanged')
    n=a['number'];r=a['references']['items'][0]
    check(n['source_global_reference_as_printed']==num and n['source_book_as_printed']==book and n['source_in_book_hadith_as_printed']==local,rid+' printed number/book/local (zeroes preserved)')
    check(n['canonical'] is None and n['in_book'] is None, rid+' no invented normalized number')
    check(a['page']['pdf']==[page] and a['page']['printed']==[printed],rid+' pdf/print page binding')
    check(r['number']==num and r['source_book_number_as_printed']==book and r['source_in_book_hadith_as_printed']==local and 'unverified' in r['canonical_mapping_status'],rid+' reference identities unverified')
    check(a['text']['arabic'] is None and a['commentary']['arabic'] is None and a['commentary']['translation'] is None,rid+' null Arabic and commentary')
    check(a['ai_translation']=='unknown' and a['translation_provenance']['ai_translation']=='unknown' and a['translation_provenance']['origin']=='unknown',rid+' historical unknown flags')
    check(a['translator']==a['translation_provenance']['translator'] and a['translator']['name']=='Juma Momade Anli',rid+' exact translator credit')
    check(a['references'].get('counterpart_verified') is False, rid+' counterpart verification false')
    # Attribute is the ONLY v001 -> v002 difference, including bodies, IDs and all other metadata.
    copy_a=copy.deepcopy(a);copy_a['translation_provenance'].pop('translator')
    check(copy_a==b,rid+' v001/v002 only attribution delta')

# Actual production modules (same code invoked by the supplied entrypoint).
sys.path.insert(0,str(CODE/'scripts'))
import material_registry,build_reader,build_discovery
from current_provenance import classification
from language_display import language_readings
reg=material_registry.load_public_materials(FIX)
projected=[x for group in reg['groups'] for x in group]
check(len(projected)==len(raw)==6 and len(reg['materials'])==1,'actual registry loads one exact six-record material')
load,cat,info=build_reader.load_records(EXEC/'fixture')
check(load==projected, 'actual load_records exact projected record JSON equality')
stream=(EXEC/'fixture/search/records.jsonl').read_text(encoding='utf-8').splitlines()
check(len(stream)==6 and [json.loads(x) for x in stream]==projected,'fixture JSONL byte content roundtrips projected records')
res=json.loads((EXEC/'RESULT.json').read_text())
check(res['records']==6 and res['reader']['record_count']==6 and res['static']['record_pages']==6 and res['static']['static_record_pages_dom_verified']==6,'production entrypoint result counts')
check(res['reader']['records_sha256']==sha(EXEC/'fixture/search/records.jsonl')==res['static']['source_records_sha256'],'Python reader/static use exact same source stream')
check(res['reader']['self_contained'] is True and res['reader']['network_dependencies']==[],'reader self-contained with no network dependencies')
check(res['publicWrite'] is False and res['sourceReviewRepeated'] is False,'supplied entrypoint reports no public write/no repeat source QC')

# Complete standalone HTML: decode actual embedded gzip/base64 and assert exact full projection.
htmlfile=(EXEC/'private-reader.html').read_text(encoding='utf-8')
soup=BeautifulSoup(htmlfile,'html.parser')
el=soup.find('script',id='hadith-records')
check(el is not None and el.get('data-encoding')=='gzip-base64','actual reader has gzip/base64 embedded data')
reader_records=json.loads(gzip.decompress(base64.b64decode(el.string)))
check(reader_records==projected,'standalone reader embedded JSON exactly equals actual projected six records')
check(len(reader_records)==6 and len({x['id'] for x in reader_records})==6,'standalone reader occurrences not merged')

for i,(r,row,x) in enumerate(zip(projected,raw,EXPECTED)):
    rid,num,book,local,page,printed=x
    check(r['id']==row['id'] and r['text_translation']==row['text']['translation'] and r['text_arabic'] is None,rid+' actual Python projection body exact and Arabic null')
    check(r['number']==row['number'] and r['page']==row['page'] and r['narrator']==row['narrator'] and r['references']==row['references'],rid+' projected number/page/narrator/references exact')
    check(r['source']['original_file']==manifest['source']['path'] and r['source']['sha256']==SRC_SHA and r['source']['record_locator']['json_pointer']==f'/{i}',rid+' source PDF/path/JSON-pointer exact')
    expected_canonical=hashlib.sha256(json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    check(r['canonical_record_sha256']==expected_canonical,rid+' canonical row hash exact')
    check(r['ai_translation']=='unknown' and r['translation_provenance']['origin']=='unknown' and r['translation_provenance']['ai_translation']=='unknown',rid+' projected unknown origin intact')
    check(r['translation_provenance']['current_policy']['classification']=='human' and classification(r)=='human',rid+' current Human policy separate')
    check(r['translation_provenance']['translator']==row['translator'] and r['translator']['name']=='Juma Momade Anli',rid+' translator actual projected provenance')
    check(r['counterpart_policy']['mode']=='disabled' and r['related_versions']==[],rid+' no approved counterparts')
    readings=language_readings(r)
    check(len(readings)==1 and readings[0]['language']=='pt' and readings[0]['text']==row['text']['translation'] and not readings[0]['comments'],rid+' only full Portuguese reading, no Arabic or commentary reading')
    check(r['review']['certified_release_eligible'] is False and r['review']['release_eligible'] is False,rid+' preserves release hold')

# Real static pages: inspect all output HTML instead of relying on producer counters.
staticfiles=sorted((EXEC/'static/hadith/pt/bukhari/anli-volume3-first-2024-1445h').glob('*.html'))
check(len(staticfiles)==6,'six generated static occurrence HTML files')
static_byid={}
for f in staticfiles:
    bs=BeautifulSoup(f.read_text(encoding='utf-8'),'html.parser')
    script=bs.find('script',type='application/ld+json')
    check(script is not None,'static structured data in '+f.name)
    schema=json.loads(script.string);record_id=schema['mainEntity']['identifier']['value']
    check(record_id not in static_byid,'unique static page identity '+record_id)
    static_byid[record_id]=(f,bs)
check(set(static_byid)=={r['id'] for r in raw},'static pages exactly cover six record identities')
for row in raw:
    rid=row['id']; f,bs=static_byid[rid]; num=row['number']['source_global_reference_as_printed'];book=row['number']['source_book_as_printed'];local=row['number']['source_in_book_hadith_as_printed']
    quote=bs.select_one('.language-reading .text.quotation')
    check(quote is not None and quote.get_text()==row['text']['translation'],rid+' static DOM full quote equals byte-exact source Unicode')
    check(len(bs.select('details.language-reading'))==1 and bs.select_one('details.language-reading div[lang]')['lang']=='pt',rid+' static only pt reading')
    check('Translator: Juma Momade Anli' in bs.select_one('.reading-source').get_text(' ',strip=True),rid+' static reading source translator visible')
    check('Human' in bs.select_one('.reading-source').get_text() and 'Human' in bs.get_text(' ',strip=True),rid+' static current Human visible')
    check(num in bs.select_one('.reading-citation').get_text(),rid+' printed reference in reading citation')
    whole=bs.get_text(' ',strip=True)
    check(book in whole and local in whole and 'source_in_book_hadith_as_printed' in whole,rid+' complete source numbering in static source details')
    check('unknown' in whole and 'current_policy' in whole, rid+' static provenance history preserved as details')
    page_html=f.read_text(encoding='utf-8')
    check('Canonical source record' in whole and 'source.pdf' in page_html and SRC_SHA in page_html,rid+' exact canonical/source locator and original SHA visible')

# Real Markdown generated reading: exact passage roundtrip, credit, separate source locator.
mdfiles=list((EXEC/'markdown').rglob('page-*.md'))
check(len(mdfiles)==1,'one generated six-record Markdown reading page')
md=mdfiles[0].read_text(encoding='utf-8')
blocks=re.split(r'(?m)^## Narration \d+\n',md)[1:]
check(len(blocks)==6,'six separate Markdown narration blocks')
for row,block in zip(raw,blocks):
    rid=row['id'];m=re.search(r'<p dir="auto">(.*?)</p>',block,re.S)
    decoded=html.unescape(m.group(1).replace('<br>\n','\n').replace('<br>','\n')) if m else None
    check(decoded==row['text']['translation'],rid+' Markdown exact quote including inline honorifics')
    check(f'<code>{rid}</code>' in block,rid+' Markdown unique occurrence source locator')
    check('<strong>Translator:</strong> Juma Momade Anli' in block,rid+' Markdown translator credit')
    check('Translation origin:</strong> Human' in block and 'Preserved source AI-translation flag: unknown' in block,rid+' Markdown current policy/historical separation')
    check(f'PDF page {row["page"]["pdf"][0]}' in block and row['number']['source_in_book_hadith_as_printed'] in block,rid+' Markdown source page/number')

# Explicit independent pair non-merging assertion in every adapter projection.
all_pair=collections.defaultdict(list)
for r in projected:all_pair[r['number']['source_global_reference_as_printed']].append(r)
check(set(all_pair)=={'5441a','5480','5486'} and all(len(v)==2 for v in all_pair.values()),'three duplicate printed tokens each have two distinct occurrences')
check(all(x[0]['id']!=x[1]['id'] and x[0]['text_translation']!=x[1]['text_translation'] for x in all_pair.values()),'same printed reference not conflated in project')
check({r['number']['source_in_book_hadith_as_printed'] for r in all_pair['5480']}=={'05','06'},'pair 5480 leading zeroes retained')

# Post-run actual-code/main fixture still matches the untouched signed archive; no new code input files.
with zipfile.ZipFile('/mnt/data/PT6-EXACT-RUNNABLE-ADAPTER-SUPPLEMENT-001.zip') as z:
    signed=json.loads(z.read('MANIFEST.json'))
    check(len(signed['payloads'])==241,'241 signed input payloads')
    for e in signed['payloads']:
        p=HERE/e['path'];check(p.is_file() and sha(p)==e['sha256'] and p.stat().st_size==e['bytes'],'untouched archive payload '+e['path'])

core={n:{'bytes':(CODE/'scripts'/n).stat().st_size,'sha256':sha(CODE/'scripts'/n)} for n in ['material_registry.py','build_reader.py','build_discovery.py','current_provenance.py','language_display.py','build_bank_views.py','source_glyphs.py']}
result={
 'tag':'PT-BUKHARI-SIX-FINAL-ADAPTER-QC-001-executable-Python-successor',
 'verdict':'PASS_BOUNDED_ACTUAL_PYTHON_ONLY',
 'checks':dict(counts),'checkLabels':checks,
 'inputs':{'zipSha256':ARCH_SHA,'zipBytes':8199910,'manifestPayloadCount':241,'recordsSha256':RECORD_SHA,'materialManifestSha256':MANIFEST_SHA,'sourcePdfSha256':SRC_SHA},
 'coreCode':core,
 'outputs':{'standaloneHtmlSha256':sha(EXEC/'private-reader.html'),'markdownPageSha256':sha(mdfiles[0]),'generatedSearchJsonlSha256':sha(EXEC/'fixture/search/records.jsonl'),'staticPages':{f.name:{'recordId':k,'sha256':sha(f),'bytes':f.stat().st_size} for k,(f,_) in static_byid.items()},'recordBodySha256':{x['id']:hashlib.sha256(x['text']['translation'].encode('utf-8')).hexdigest() for x in raw}},
 'limits':['No full corpus/current shared HEAD/combined FR-HI code CI','No live PDF/download link/hosted deployment check','No new source, meaning, glyph or licensing review','No input code/source edits, no new workers, no public writes'],
 'expectedNumberingNote':'number.in_book and number.canonical remain null by design. Printed source_global_reference/source_book/source_in_book retained including 05/06.',
}
REPORT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS','independentChecks':counts['PASS'],'generatedStaticPages':len(staticfiles),'markdownExactPassageMatches':len(blocks),'standaloneReaderExactMatches':len(reader_records),'evidence':str(REPORT),'coreCodeHashes':{k:v['sha256'] for k,v in core.items()}},ensure_ascii=False,indent=2))
