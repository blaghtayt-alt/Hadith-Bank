# Portuguese Bukhari v3 targeted QC001 — independent evidence report

**Scope:** only supplied records pt_bukhari_v3_0456, 0457, 0496, 0497, 0502 and 0503; duplicate printed references `5441a`, `5480`, `5486` on PDF pages 148, 161, 163 (printed 144, 157, 159). Exact source-page images included. No full-book review, canonical assignment, merge, deletion, repository write or release.

## Integrity and independent verification

- Input ZIP (4,854,051 bytes) SHA-256: `4d8c7127eea1b4bbf05821a2264607285462f02a5dd37911589e3a258d2f4504`; **matches**.
- Source PDF (6,321,982 bytes) SHA-256: `1b5ef269f948b88d897755cfeb4af64ee085d009f7b4ff389691b9c0f6a7e347`; **matches**.
- Six ZIP payload file SHA-256 values and byte sizes match the supplied manifest.
- Independently rendered only target narration pages 148, 161, 163 with Poppler at 200 dpi, plus pair-focus crops.
- The 44/44 page line fragments provided for the six records match independently extracted PyMuPDF line text after *font-qualified* substitution for the special `Abo-thar` honorific glyphs; all six full source strings, record offsets, component boundaries, narrator/translation/reference fields, printed book numbers and printed in-book numbers pass internal checks. The custom-font conversion is a disclosed representation limit.

## Findings by printed reference

1. **5441a** — PDF148/printed144: 0456 `Segundo Abu Othman رحمه الله narra`, Livro70/Hadith69 describes a seven-day stay and seven dates; 0457 `Segundo Abu Hurairah رضي الله عنه narra`, Livro70/Hadith70 describes five dates and difficulty with the dried date. **Two visibly printed instances; narrations differ.** Preserve the source's line-wrap `Hasha-` / `fah`, and the separate `Hashafah` / `Hashafa` forms without editorial correction.
2. **5480** — PDF161/printed157: 0496 `Segundo Abdullah Bin Maghaffal رضي الله عنه narra`, Livro72/Hadith05, concerns throwing stones and potential injury (Capítulo V); 0497 `Segundo Ibn Omar رضي الله عنه narra`, Livro72/Hadith06, concerns keeping a dog and deductions of Qirat (Capítulo VI). **Different narrator, chapter, subject and in-book number; both genuinely print 5480.** Keep `05` and `06` exactly, including leading zeros.
3. **5486** — PDF163/printed159: 0502 and 0503 both display `Segundo Adiy Bin Hatim رضي الله عنه narra`, but 0502 (Livro72/Hadith11) is a concise arrow-and-recovered-prey question; 0503 (Livro72/Hadith12) describes hunting dogs and conditions for a sharp versus broad implement under Capítulo IX. **Same narrator but clearly different source entries, source spans and in-book numbers.** 0502 inherited chapter heading is on PDF162, outside the specified review, so it was not independently rechecked.

## Conservative decisions

- `printed_global_reference_verbatim`: source values accurate; **hold any uniqueness assumption or identity linkage** for the three repeated tokens.
- `canonical_hadith_reference_mapping`: **unresolved/held**; no external mapping invented.
- `cross_record_duplicate_merge`: **prohibited**; six entries remain distinct with their original IDs and source text; no deletions or edits.
- `arabic_hadith_verbatim`: **null is correct** because Arabic matn is not printed in this Portuguese translation volume; do not label a missing extraction or synthesize Arabic.
- `narrator_attribution_verbatim`, Portuguese translation, exact terminal references and source offsets: **no new field hold from this targeted audit**, subject to the disclosed custom-font representation limitation.
- Document translator credit **“Traduzido por: Juma Momade Anli”** directly confirmed by targeted frontmatter text checks at PDF pages 1 and 3 (not counted as narration QC). The precise printed name is preserved.

**Release disposition:** targeted duplicate/reference-fidelity check complete, three canonical-identity holds remain. This is NOT full-book coverage or release authorization.
